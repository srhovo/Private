package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.UserManager

class WorkProfileManager(private val context: Context) {
    private val dpm: DevicePolicyManager = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    data class Compatibility(
        val supportsManagedUsers: Boolean,
        val provisioningAllowed: Boolean,
        val isProfileOwner: Boolean,
        val sdk: Int,
        val manufacturer: String,
        val model: String,
        val isDeviceOwner: Boolean,
        val userProfileCount: Int
    ) {
        val canCreateProfile: Boolean get() = supportsManagedUsers && provisioningAllowed && !isProfileOwner && !isDeviceOwner
        val hasRelatedProfile: Boolean get() = userProfileCount > 1

        /**
         * 给出当前最可能阻止创建工作资料的具体原因，而不是笼统列出所有可能性。
         * 返回 null 表示已经是 Profile Owner，不存在阻塞。
         */
        fun likelyBlockReason(): String? {
            if (isProfileOwner) return null
            return when {
                !supportsManagedUsers ->
                    "这台设备或当前系统没有开放工作资料能力，通常无法通过第三方 App 解决。"
                !provisioningAllowed && userProfileCount > 1 ->
                    "最可能原因：手机上已经有一个工作资料/分身空间占用了名额（Android 每台设备只允许一个工作资料）。很可能是之前测试过原版 Shelter 或旧版本本 App 时创建、还没清理干净。\n\n" +
                        "解决办法：先到系统设置里找到并移除已有的工作资料/工作空间/分身资料，重启手机，再回来重新创建。"
                !provisioningAllowed ->
                    "系统当前拒绝创建工作资料，常见原因是设备被企业/学校/家长控制器占用，或厂商 ROM 关闭了此入口。"
                isDeviceOwner ->
                    "当前 App 已经是设备管理者（Device Owner），这与工作资料模式互斥，无法再创建工作资料。"
                else -> null
            }
        }
    }

    fun adminComponent(): ComponentName = admin

    fun isProfileOwner(): Boolean {
        return runCatching { dpm.isProfileOwnerApp(context.packageName) }.getOrDefault(false)
    }

    fun compatibility(): Compatibility {
        val supports = context.packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)
        val allowed = runCatching {
            dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
        }.getOrDefault(false)
        val owner = isProfileOwner()
        val deviceOwner = runCatching { dpm.isDeviceOwnerApp(context.packageName) }.getOrDefault(false)
        val profileCount = runCatching {
            context.getSystemService(UserManager::class.java).userProfiles.size
        }.getOrDefault(1)
        return Compatibility(
            supportsManagedUsers = supports,
            provisioningAllowed = allowed,
            isProfileOwner = owner,
            sdk = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER ?: "unknown",
            model = Build.MODEL ?: "unknown",
            isDeviceOwner = deviceOwner,
            userProfileCount = profileCount
        )
    }

    fun createProvisioningIntent(): Intent {
        return Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true)
        }
    }

    fun requestCreateManagedProfile(activity: Activity) {
        val compat = compatibility()
        if (compat.isProfileOwner) {
            throw IllegalStateException("当前已经位于工作资料管理空间，不需要重复创建。")
        }
        if (!compat.supportsManagedUsers) {
            throw IllegalStateException("这台设备或当前系统没有开放工作资料能力。")
        }
        if (!compat.provisioningAllowed) {
            throw IllegalStateException("系统当前不允许创建工作资料。常见原因：已有工作资料、系统被企业/家长管理占用、厂商 ROM 禁用了此能力，或当前不是主用户。")
        }
        activity.startActivity(createProvisioningIntent())
    }

    fun cloneExistingPackageToThisProfile(packageName: String): Result<Boolean> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法执行安装/克隆管理。请在隔离空间里的本 App 中操作，或从主空间把克隆请求发送到隔离空间。"))
        }
        return runCatching {
            if (isInstalledInCurrentProfile(pkg)) return@runCatching true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.installExistingPackage(admin, pkg)
            } else {
                throw UnsupportedOperationException("installExistingPackage 需要 Android 9 或更高版本。")
            }
        }.onSuccess {
            ProvisioningDiagnostics.record(context, "克隆请求完成：$pkg result=$it")
        }.onFailure {
            ProvisioningDiagnostics.record(context, "克隆请求失败：$pkg", it)
        }
    }

    fun setPackageHidden(packageName: String, hidden: Boolean): Result<Boolean> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法冻结/恢复应用。请在隔离空间里的本 App 中操作。"))
        }
        return runCatching {
            dpm.setApplicationHidden(admin, pkg, hidden)
        }.onSuccess {
            ProvisioningDiagnostics.record(context, "隐藏状态修改：$pkg hidden=$hidden result=$it")
        }.onFailure {
            ProvisioningDiagnostics.record(context, "隐藏状态修改失败：$pkg hidden=$hidden", it)
        }
    }

    fun isInstalledInCurrentProfile(packageName: String): Boolean {
        return runCatching { context.packageManager.getPackageInfo(packageName, 0) }.isSuccess
    }

    fun openCloneRequestChooser(activity: Activity, packageName: String, label: String): Result<Unit> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        val request = Intent(ProvisioningContract.ACTION_CLONE_PACKAGE).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            putExtra(ProvisioningContract.EXTRA_PACKAGE_NAME, pkg)
            putExtra(ProvisioningContract.EXTRA_APP_LABEL, label)
        }
        return runCatching {
            // 这里必须使用隐式跨资料 Intent。主空间本地接收入口会被禁用，系统只能解析到隔离空间接收端。
            activity.startActivity(request)
        }.recoverCatching { error ->
            if (error is ActivityNotFoundException) {
                throw IllegalStateException("没有找到隔离空间接收入口。请先进入隔离空间打开一次本 App，或重建工作资料后再试。")
            }
            throw error
        }
    }
}
