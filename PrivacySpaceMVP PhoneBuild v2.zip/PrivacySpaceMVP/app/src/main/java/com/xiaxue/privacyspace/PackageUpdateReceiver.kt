package com.xiaxue.privacyspace

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PackageUpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED || intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ProfileSetup.configureCloneReceiverForCurrentProfile(context)
            if (WorkProfileManager(context).isProfileOwner()) {
                ProfileSetup.complete(context)
            }
        }
    }
}
