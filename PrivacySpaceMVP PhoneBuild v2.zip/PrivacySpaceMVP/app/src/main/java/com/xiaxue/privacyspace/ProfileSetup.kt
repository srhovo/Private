package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager

internal object ProfileSetup {
    fun complete(context: Context): Boolean {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

        val isOwner = runCatching { dpm.isProfileOwnerApp(context.packageName) }
            .onFailure { ProvisioningDiagnostics.record(context, "检查 Profile Owner 失败", it) }
            .getOrDefault(false)

        if (!isOwner) {
            ProvisioningDiagnostics.record(context, "收尾跳过：当前用户不是 Profile Owner")
            return false
        }

        runCatching { dpm.setProfileName(admin, context.getString(R.string.work_profile_name)) }
            .onFailure { ProvisioningDiagnostics.record(context, "设置工作资料名称失败", it) }

        configureCloneReceiverForCurrentProfile(context, true)
        configureCrossProfileCommands(context, dpm, admin)

        val enabled = runCatching {
            dpm.setProfileEnabled(admin)
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "启用工作资料失败", it)
        }.getOrDefault(false)

        ProvisioningDiagnostics.record(context, "工作资料收尾完成：enabled=$enabled")
        return enabled
    }

    private fun configureCrossProfileCommands(context: Context, dpm: DevicePolicyManager, admin: ComponentName) {
        runCatching { dpm.clearCrossProfileIntentFilters(admin) }
            .onFailure { ProvisioningDiagnostics.record(context, "清理跨资料指令过滤器失败", it) }

        listOf(
            ProvisioningContract.ACTION_CLONE_PACKAGE,
            ProvisioningContract.ACTION_LAUNCH_PACKAGE,
            ProvisioningContract.ACTION_START_SERVICE
        ).forEach { action ->
            val filter = IntentFilter(action).apply { addCategory(Intent.CATEGORY_DEFAULT) }
            // 从主空间发起请求，目标解析到工作资料。只使用单向 flag，避免部分 ROM 对双向合并 flag 解析失败。
            runCatching {
                dpm.addCrossProfileIntentFilter(admin, filter, DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT)
            }
                .onFailure { ProvisioningDiagnostics.record(context, "配置主空间到隔离空间指令失败：$action", it) }
                .onSuccess { ProvisioningDiagnostics.record(context, "已配置主空间到隔离空间指令：$action") }
        }
    }

    fun configureCloneReceiverForCurrentProfile(context: Context, enabled: Boolean? = null) {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val shouldEnable = enabled ?: runCatching { dpm.isProfileOwnerApp(context.packageName) }.getOrDefault(false)
        runCatching {
            context.packageManager.setComponentEnabledSetting(
                ComponentName(context, CloneRequestActivity::class.java),
                if (shouldEnable) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            ProvisioningDiagnostics.record(context, "克隆接收入口状态：enabled=$shouldEnable")
        }.onFailure { ProvisioningDiagnostics.record(context, "配置克隆接收入口失败", it) }
    }

    fun finishProvisioningActivity(activity: Activity, openMain: Boolean) {
        complete(activity)
        activity.setResult(Activity.RESULT_OK)
        if (openMain) {
            runCatching {
                activity.startActivity(
                    Intent(activity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }.onFailure { ProvisioningDiagnostics.record(activity, "打开首页失败", it) }
        }
        activity.finish()
    }
}
