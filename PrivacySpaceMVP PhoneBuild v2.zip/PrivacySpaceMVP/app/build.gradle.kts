plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiaxue.privacyspace"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xiaxue.privacyspace"
        minSdk = 24
        targetSdk = 33
        versionCode = 15
        versionName = "0.6.5-shelter-routing-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
