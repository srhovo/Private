package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class AppsActivity : Activity() {
    private lateinit var manager: WorkProfileManager
    private lateinit var listView: ListView
    private lateinit var hintView: TextView
    private var apps: List<ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = WorkProfileManager(this)

        hintView = TextView(this).apply {
            textSize = 15f
            setPadding(24, 24, 24, 16)
        }
        listView = ListView(this)

        val refresh = Button(this).apply {
            text = "刷新应用列表"
            setOnClickListener { loadApps() }
        }

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val info = apps[position]
            val packageName = info.activityInfo.packageName
            showAppAction(packageName)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(hintView)
            addView(refresh)
            addView(listView, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
        }
        setContentView(root)
        loadApps()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(intent, 0)
            .sortedBy { it.loadLabel(packageManager).toString() }

        val labels = apps.map { info ->
            "${info.loadLabel(packageManager)}\n${info.activityInfo.packageName}"
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        hintView.text = if (manager.isProfileOwner()) {
            "当前为工作资料管理者。点击应用可执行冻结/恢复测试。"
        } else {
            "当前不是工作资料管理者。这里只能查看当前空间应用；冻结/恢复需要在工作资料内执行。"
        }
    }

    private fun showAppAction(packageName: String) {
        val actions = arrayOf("冻结/隐藏", "恢复/显示", "尝试安装到当前工作资料")
        android.app.AlertDialog.Builder(this)
            .setTitle(packageName)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> manager.setPackageHidden(packageName, true).report("已请求冻结/隐藏")
                    1 -> manager.setPackageHidden(packageName, false).report("已请求恢复/显示")
                    2 -> manager.cloneExistingPackageToThisProfile(packageName).report("已请求安装到当前工作资料")
                }
            }
            .show()
    }

    private fun <T> Result<T>.report(successText: String) {
        fold(
            onSuccess = { Toast.makeText(this@AppsActivity, successText, Toast.LENGTH_LONG).show() },
            onFailure = { Toast.makeText(this@AppsActivity, it.message ?: it.javaClass.simpleName, Toast.LENGTH_LONG).show() }
        )
    }
}
