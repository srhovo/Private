package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build

class WorkProfileManager(private val context: Context) {
    private val dpm: DevicePolicyManager = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    fun adminComponent(): ComponentName = admin

    fun isProfileOwner(): Boolean {
        return dpm.isProfileOwnerApp(context.packageName)
    }

    fun requestCreateManagedProfile(activity: Activity) {
        val intent = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, false)
        }
        activity.startActivity(intent)
    }

    fun cloneExistingPackageToThisProfile(packageName: String): Result<Boolean> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法执行安装/克隆管理。"))
        }
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.installExistingPackage(admin, packageName)
            } else {
                throw UnsupportedOperationException("installExistingPackage 需要 Android 9 或更高版本。")
            }
        }
    }

    fun setPackageHidden(packageName: String, hidden: Boolean): Result<Unit> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法冻结/恢复应用。"))
        }
        return runCatching {
            dpm.setApplicationHidden(admin, packageName, hidden)
        }
    }
}
