package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var manager: WorkProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = WorkProfileManager(this)

        statusView = TextView(this).apply {
            textSize = 16f
            setPadding(24, 24, 24, 24)
        }

        val createProfileButton = Button(this).apply {
            text = "创建独立工作资料空间"
            setOnClickListener {
                runCatching { manager.requestCreateManagedProfile(this@MainActivity) }
                    .onFailure { showError(it) }
            }
        }

        val appListButton = Button(this).apply {
            text = "管理当前空间应用"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, AppsActivity::class.java))
            }
        }

        val refreshButton = Button(this).apply {
            text = "刷新状态"
            setOnClickListener { refreshStatus() }
        }

        val description = TextView(this).apply {
            text = "定位：隐私隔离 / 工作生活分离 / 应用测试隔离。\n\n" +
                "说明：创建工作资料后，系统会在独立空间内生成一个受管理的应用环境。" +
                "本工具只做合法的资料隔离和应用管理，不包含设备伪装、检测规避或绕过第三方平台规则的能力。"
            textSize = 15f
            setPadding(24, 16, 24, 24)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            addView(statusView)
            addView(createProfileButton)
            addView(appListButton)
            addView(refreshButton)
            addView(description)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refreshStatus()
    }

    private fun refreshStatus() {
        val isOwner = manager.isProfileOwner()
        statusView.text = buildString {
            appendLine("应用包名：$packageName")
            appendLine("当前实例是否为工作资料管理者：${if (isOwner) "是" else "否"}")
            appendLine()
            appendLine(if (isOwner) {
                "你现在大概率位于工作资料空间内，可管理该空间中的应用。"
            } else {
                "你现在大概率位于主空间内，可先创建工作资料。创建完成后，系统会在工作资料中安装/启用本管理器。"
            })
        }
    }

    private fun showError(t: Throwable) {
        Toast.makeText(this, t.message ?: t.javaClass.simpleName, Toast.LENGTH_LONG).show()
    }
}
