package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView

class FinalizeProvisionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "工作资料创建完成，正在进入隐私空间助手……"
            textSize = 18f
            setPadding(32, 32, 32, 32)
        })
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
