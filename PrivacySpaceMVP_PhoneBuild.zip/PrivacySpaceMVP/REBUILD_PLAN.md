# 重建工程规划

## 一、产品名建议

- 隐私空间助手
- 应用隔离盒
- 工作空间助手
- 双空间管理器

不建议使用“防检测”“防封”“过检测”等名称。

## 二、保留模块

| 模块 | 是否保留 | 说明 |
|---|---:|---|
| 工作资料创建 | 保留 | 核心能力 |
| 应用克隆/安装 | 保留 | 用于把应用放进工作资料空间 |
| 冻结/恢复 | 保留 | 用于减少后台运行和隐私暴露 |
| 工作资料开关 | 后续加入 | 一键暂停工作资料 |
| 文件穿梭 | 暂缓 | 容易增加权限和复杂度 |
| 相机代理 | 删除 | MVP 不需要 |
| 设备伪装 | 不做 | 不属于合法隐私隔离工具 |
| 检测规避 | 不做 | 不属于合法隐私隔离工具 |

## 三、推荐架构

```text
MainActivity
 ├─ SetupGuide：工作资料创建引导
 ├─ ProfileStatus：当前空间状态
 └─ AppsActivity：当前空间应用管理

WorkProfileManager
 ├─ requestCreateManagedProfile()
 ├─ isProfileOwner()
 ├─ cloneExistingPackageToThisProfile()
 └─ setPackageHidden()

PrivacyDeviceAdminReceiver
 └─ 接收设备管理启用/停用事件

FinalizeProvisionActivity
 └─ 接收工作资料创建成功事件
```

## 四、MVP 验收标准

1. App 可以安装到 Android 设备。
2. 主空间内点击“创建独立工作资料空间”，系统弹出工作资料创建流程。
3. 用户确认后，工作资料内出现本 App。
4. 工作资料内打开本 App，状态显示为 Profile Owner。
5. 在工作资料内可以对工作资料内应用执行冻结/恢复测试。

## 五、后续真正要补的难点

1. 主空间与工作资料之间的通信。
2. 主空间选择 App，工作资料执行安装/克隆。
3. 厂商 ROM 差异兼容。
4. 权限最小化与隐私提示。
5. UI 产品化。
