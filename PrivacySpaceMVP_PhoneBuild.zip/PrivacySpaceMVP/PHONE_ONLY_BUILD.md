# 手机为主的云端打包流程

适用情况：电脑配置一般或无法访问 GitHub，但手机可以访问 GitHub。

## 核心思路

电脑只负责解压、查看和简单改文件；手机负责上传 GitHub、触发 Actions、下载 APK；GitHub Actions 负责云端编译。

## 步骤

1. 用手机浏览器登录 GitHub。
2. 创建一个新仓库，例如 `PrivacySpaceMVP`。
3. 把本工程里的所有文件上传到仓库根目录。
4. 确认仓库里存在 `.github/workflows/android-build.yml`。
5. 进入仓库的 `Actions` 页面。
6. 选择 `Android Debug APK` 工作流。
7. 点击 `Run workflow`，或者上传代码后等待自动运行。
8. 构建完成后，打开本次 workflow run。
9. 在 `Artifacts` 区域下载 `PrivacySpaceMVP-debug-apk`。
10. 解压下载到手机的 artifact 压缩包，安装里面的 debug APK。

## 注意

- 第一次构建可能比较慢，因为云端需要下载 Gradle 和 Android 依赖。
- debug APK 适合测试，不适合正式分发。
- 后续正式分发时，需要改成 release 签名包。
- Work Profile / Device Admin 功能必须用安卓真机测试，模拟器和部分国产系统可能表现不同。
