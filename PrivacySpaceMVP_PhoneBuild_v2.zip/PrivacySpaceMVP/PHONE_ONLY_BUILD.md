# 手机上传 GitHub 云打包说明

手机网页上传文件夹不方便，建议仓库只上传两个内容：

1. `PrivacySpaceMVP_PhoneBuild_v2.zip`
2. `.github/workflows/build-from-zip.yml`

workflow 里需要把旧文件名替换成：

```yaml
PrivacySpaceMVP_PhoneBuild_v2.zip
```

常见需要替换两处：

```yaml
- 'PrivacySpaceMVP_PhoneBuild_v2.zip'
```

```yaml
unzip -q PrivacySpaceMVP_PhoneBuild_v2.zip
```

构建成功后，在 Actions 详情页底部下载 Artifacts。
