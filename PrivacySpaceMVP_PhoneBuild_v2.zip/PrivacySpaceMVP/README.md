# 下雪应用隔离 v0.7.5-lifecycle-state-public-sdk-fix

这是一个基于 Android 工作资料（Managed Profile）的隐私隔离与应用测试工程。

## 系统边界

- 最低系统：Android 11（API 30）
- 重点适配：Android 13–16
- compileSdk / targetSdk：35
- Java / Kotlin：JDK 17

## 当前完成范围

- 阶段 1：工作资料创建基线、安全配对、HMAC 指令认证、防重放、核心组件保护。
- 阶段 2：主空间真实应用清单、base/split APK 来源、版本/签名/大小/SHA-256 校验和受控 URI 传输。
- 阶段 3：`PackageInstaller.Session` 正式安装、用户确认、安装状态回调、失败分类和回调恢复。
- 阶段 4：真实主空间/隔离空间双侧列表，跨资料启动、冻结、恢复、卸载及远端状态/诊断同步。
- 阶段 5（构建热修）：修复 Android 系统服务可空类型导致的 Kotlin 编译阻断；CI 增加阶段 5 发布门禁、唯一 APK 校验、非空校验与 SHA-256 产物。

## 尚需真机完成

- Android 13–16 以及 vivo/OriginOS 等厂商 ROM 的跨资料 URI、安装确认、启动、冻结、恢复、卸载回归。
- GitHub Actions 完整 Gradle 构建和 APK 安装烟测。
- 阶段 5 发布收尾、签名和回退验证。

旧版本创建的工作资料没有新版共享密钥。若首页显示“安全配对：未建立”且设备已有工作资料，请先备份必要数据，移除旧工作资料后重新创建。

## 本地门禁

```bash
python3 tools/phase1_static_regression.py
python3 tools/phase2_static_regression.py
python3 tools/phase3_static_regression.py
python3 tools/phase4_static_regression.py
python3 tools/phase5_release_regression.py
```

GitHub Actions 在以上门禁通过后运行：

```bash
gradle :app:assembleDebug --stacktrace
```

固定交付文件名：`PrivacySpaceMVP_PhoneBuild_v2.zip`

本工具用于隐私隔离、工作/个人应用数据分离和应用测试环境隔离；不包含设备伪装、反作弊绕过或第三方平台检测规避能力。
