# 第一阶段推进说明：工作资料创建链路

本包文件名仍保持 `PrivacySpaceMVP_PhoneBuild_v2.zip`，你的 GitHub workflow 不需要改文件名。

本阶段只解决第一优先级：让系统工作资料空间成功创建。

## 本次处理

1. 新增 `SetupWizardActivity`：不再从首页直接丢 provisioning Intent，而是进入单独设置向导页后再启动系统创建流程。
2. 新增 `DummyActivity` 与 `ProvisioningContract`：恢复 Shelter 类似的极简收尾入口。
3. 调整 `FinalizeProvisionActivity`：收到 `android.app.action.PROVISIONING_SUCCESSFUL` 后转到 `DummyActivity` 完成 `setProfileEnabled()`。
4. 简化 `ProfileSetup`：第一阶段只做稳定必要动作：确认 Profile Owner、设置资料名称、调用 `setProfileEnabled()`。
5. Manifest 对齐原 Shelter APK 的关键结构：`MainActivity`、`SetupWizardActivity`、`DummyActivity`、`FinalizeProvisionActivity`、`DeviceAdminReceiver`。
6. 移除上一版中额外猜测的 `GET_PROVISIONING_MODE` / `ADMIN_POLICY_COMPLIANCE` Manifest 入口，减少部分 ROM 的 ManagedProvisioning 兼容变量。

## 验收标准

- 点击首页“创建独立工作资料空间”。
- 进入“创建独立工作资料空间”向导页。
- 点击“开始创建”。
- 系统进入设置设备流程。
- 不再提示“无法设置设备”。
- 创建完成后，系统出现工作资料 / 工作空间。
- 工作资料中出现“下雪应用隔离”。

## 测试前必须清理

如果刚才用 Shelter 原 APK 创建过空间，需要先删除那个工作资料；不同包名不能接管同一个 Profile Owner。

推荐流程：

1. 删除原 APK 创建的工作资料 / 工作空间。
2. 卸载旧版“下雪应用隔离”。
3. 重启手机。
4. 上传本 ZIP 到 GitHub，覆盖原来的 v2 ZIP。
5. 重新构建并安装 APK。
6. 再测试创建。

如果仍失败，下一步需要抓系统日志：

```bash
adb logcat -d | grep -i -E "ManagedProvisioning|DevicePolicyManager|XiaXueProvisioning|XiaXueProfileSetup"
```
