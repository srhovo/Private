# 第一阶段链路 / 风险 / 验收

## 链路
MainActivity -> SetupWizardActivity -> ACTION_PROVISION_MANAGED_PROFILE -> DeviceAdminReceiver / PROVISIONING_SUCCESSFUL -> ProfileSetup.setProfileEnabled()

## 本轮风险处理
- FinalizeActivity 先立即执行 ProfileSetup，降低 ROM 跳转 DummyActivity 前判失败的风险。
- Receiver 增加 PROFILE_PROVISIONING_COMPLETE action，兼容按官方回调 action 派发的系统。
- 增加 IsolationService 占位，先对齐 Shelter 的核心组件存在性，第二阶段再接跨空间通信。

## 验收
- 系统创建工作资料不再提示“无法设置设备”。
- 设置中显示“下雪应用隔离”为工作资料管理器。
- 首页复制诊断能看到 Profile Owner=true。
