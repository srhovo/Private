plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiaxue.privacyspace"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xiaxue.privacyspace"
        minSdk = 30
        targetSdk = 35
        versionCode = 20
        versionName = "0.7.4-lifecycle-state-build-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
