package com.xiaxue.privacyspace

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

internal data class ProfilePackageState(
    val packageName: String,
    val label: String,
    val installed: Boolean,
    val hidden: Boolean,
    val launchable: Boolean,
    val system: Boolean,
    val versionName: String,
    val versionCode: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("packageName", packageName)
        .put("label", label)
        .put("installed", installed)
        .put("hidden", hidden)
        .put("launchable", launchable)
        .put("system", system)
        .put("versionName", versionName)
        .put("versionCode", versionCode)

    companion object {
        fun fromJson(root: JSONObject): ProfilePackageState = ProfilePackageState(
            packageName = root.getString("packageName"),
            label = root.optString("label", root.getString("packageName")),
            installed = root.optBoolean("installed", true),
            hidden = root.optBoolean("hidden", false),
            launchable = root.optBoolean("launchable", false),
            system = root.optBoolean("system", false),
            versionName = root.optString("versionName", ""),
            versionCode = root.optLong("versionCode", 0L)
        )
    }
}

internal data class ProfileStateSnapshot(
    val requestId: String,
    val generatedAt: Long,
    val profileOwner: Boolean,
    val profileLabel: String,
    val fullInventory: Boolean,
    val packages: List<ProfilePackageState>,
    val diagnostics: List<String>
) {
    fun toJson(): String {
        val packageArray = JSONArray().apply {
            packages.sortedBy { it.packageName }.forEach { put(it.toJson()) }
        }
        val diagnosticArray = JSONArray().apply {
            diagnostics.takeLast(MAX_DIAGNOSTICS).forEach { put(it.take(MAX_DIAGNOSTIC_LENGTH)) }
        }
        return JSONObject()
            .put("schemaVersion", SCHEMA_VERSION)
            .put("requestId", requestId)
            .put("generatedAt", generatedAt)
            .put("profileOwner", profileOwner)
            .put("profileLabel", profileLabel.take(MAX_LABEL_LENGTH))
            .put("fullInventory", fullInventory)
            .put("packages", packageArray)
            .put("diagnostics", diagnosticArray)
            .toString()
    }

    fun validationError(): String? {
        if (requestId.isBlank() || requestId.length > 80) return "状态请求 ID 无效。"
        if (generatedAt <= 0L) return "状态生成时间无效。"
        if (profileLabel.isBlank()) return "状态来源空间缺少名称。"
        if (packages.size > MAX_PACKAGES) return "状态列表超过上限。"
        if (diagnostics.size > MAX_DIAGNOSTICS) return "诊断记录超过上限。"
        val seen = HashSet<String>()
        packages.forEach { state ->
            if (!PACKAGE_PATTERN.matches(state.packageName)) return "状态列表包含无效包名。"
            if (!seen.add(state.packageName)) return "状态列表包含重复包名。"
            if (state.label.length > MAX_LABEL_LENGTH) return "应用名称过长。"
            if (state.versionName.length > MAX_VERSION_LENGTH) return "版本名称过长。"
            if (!state.installed && (state.hidden || state.launchable)) return "未安装应用不能标记为隐藏或可启动。"
        }
        return null
    }

    fun stateFor(packageName: String): ProfilePackageState? = packages.firstOrNull { it.packageName == packageName }

    companion object {
        const val SCHEMA_VERSION = 1
        const val MAX_PACKAGES = 500
        private const val MAX_DIAGNOSTICS = 12
        private const val MAX_DIAGNOSTIC_LENGTH = 600
        private const val MAX_LABEL_LENGTH = 160
        private const val MAX_VERSION_LENGTH = 160
        private val PACKAGE_PATTERN = Regex("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+")

        fun fromJson(raw: String): ProfileStateSnapshot = runCatching {
            require(raw.length <= 700_000) { "状态数据超过大小上限。" }
            val root = JSONObject(raw)
            require(root.getInt("schemaVersion") == SCHEMA_VERSION) { "状态数据版本不受支持。" }
            val packageArray = root.getJSONArray("packages")
            require(packageArray.length() <= MAX_PACKAGES) { "状态列表超过上限。" }
            val packages = buildList {
                for (index in 0 until packageArray.length()) {
                    add(ProfilePackageState.fromJson(packageArray.getJSONObject(index)))
                }
            }
            val diagnosticArray = root.optJSONArray("diagnostics") ?: JSONArray()
            val diagnostics = buildList {
                val count = minOf(diagnosticArray.length(), MAX_DIAGNOSTICS)
                for (index in 0 until count) add(diagnosticArray.optString(index).take(MAX_DIAGNOSTIC_LENGTH))
            }
            ProfileStateSnapshot(
                requestId = root.getString("requestId"),
                generatedAt = root.getLong("generatedAt"),
                profileOwner = root.getBoolean("profileOwner"),
                profileLabel = root.getString("profileLabel"),
                fullInventory = root.optBoolean("fullInventory", true),
                packages = packages,
                diagnostics = diagnostics
            ).also { snapshot ->
                snapshot.validationError()?.let { throw IllegalArgumentException(it) }
            }
        }.getOrElse { throw IllegalArgumentException(it.message ?: "状态数据无法解析。", it) }

        fun sha256Text(text: String): String = MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
