package com.xiaxue.privacyspace

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

internal object ApkSourceSessionStore {
    const val SESSION_TTL_MS = 15 * 60 * 1000L
    private const val PREF = "xiaxue_apk_source_sessions"
    private const val KEY_PREFIX = "session_"
    private const val MAX_SESSIONS = 8

    data class StoredFile(
        val index: Int,
        val displayName: String,
        val canonicalPath: String,
        val sizeBytes: Long,
        val lastModified: Long,
        val sha256: String
    )

    data class StoredSession(
        val sessionId: String,
        val packageName: String,
        val versionCode: Long,
        val expiresAt: Long,
        val files: List<StoredFile>
    )

    fun save(context: Context, session: StoredSession): Boolean {
        purgeExpired(context)
        val json = JSONObject()
            .put("sessionId", session.sessionId)
            .put("packageName", session.packageName)
            .put("versionCode", session.versionCode)
            .put("expiresAt", session.expiresAt)
            .put("files", JSONArray().apply {
                session.files.sortedBy { it.index }.forEach { file ->
                    put(
                        JSONObject()
                            .put("index", file.index)
                            .put("displayName", file.displayName)
                            .put("canonicalPath", file.canonicalPath)
                            .put("sizeBytes", file.sizeBytes)
                            .put("lastModified", file.lastModified)
                            .put("sha256", file.sha256)
                    )
                }
            })
            .toString()
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val saved = prefs.edit().putString(KEY_PREFIX + session.sessionId, json).commit()
        trimOldest(context)
        return saved
    }

    fun read(context: Context, sessionId: String): StoredSession? {
        purgeExpired(context)
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_PREFIX + sessionId, null)
            ?: return null
        return parse(raw)?.takeIf { it.sessionId == sessionId && it.expiresAt > System.currentTimeMillis() }
    }

    fun remove(context: Context, sessionId: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_PREFIX + sessionId)
            .apply()
    }

    fun fileForRead(context: Context, sessionId: String, index: Int): Result<Pair<StoredSession, StoredFile>> {
        return runCatching {
            val session = read(context, sessionId) ?: throw SecurityException("APK 来源会话不存在或已过期。")
            val stored = session.files.firstOrNull { it.index == index }
                ?: throw SecurityException("APK 来源文件不存在。")
            val file = File(stored.canonicalPath)
            require(file.isFile && file.canRead()) { "APK 来源文件不可读。" }
            require(file.length() == stored.sizeBytes) { "APK 来源文件大小已变化。" }
            require(file.lastModified() == stored.lastModified) { "APK 来源文件已更新，请重新发起克隆。" }
            require(ApkSourceRepository.currentVersionCode(context, session.packageName) == session.versionCode) {
                "应用版本已变化，请重新发起克隆。"
            }
            require(ApkSourceRepository.currentSourcePaths(context, session.packageName).contains(file.canonicalPath)) {
                "APK 来源路径已不属于当前安装包。"
            }
            session to stored
        }
    }

    private fun parse(raw: String): StoredSession? = runCatching {
        val root = JSONObject(raw)
        val filesJson = root.getJSONArray("files")
        val files = buildList {
            for (i in 0 until filesJson.length()) {
                val item = filesJson.getJSONObject(i)
                add(
                    StoredFile(
                        index = item.getInt("index"),
                        displayName = item.getString("displayName"),
                        canonicalPath = item.getString("canonicalPath"),
                        sizeBytes = item.getLong("sizeBytes"),
                        lastModified = item.getLong("lastModified"),
                        sha256 = item.getString("sha256")
                    )
                )
            }
        }
        StoredSession(
            sessionId = root.getString("sessionId"),
            packageName = root.getString("packageName"),
            versionCode = root.getLong("versionCode"),
            expiresAt = root.getLong("expiresAt"),
            files = files.sortedBy { it.index }
        )
    }.getOrNull()

    private fun purgeExpired(context: Context) {
        val now = System.currentTimeMillis()
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val remove = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            val expires = (value as? String)?.let(::parse)?.expiresAt ?: 0L
            key.takeIf { expires <= now }
        }
        if (remove.isNotEmpty()) {
            val editor = prefs.edit()
            remove.forEach(editor::remove)
            editor.apply()
        }
    }

    private fun trimOldest(context: Context) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val sessions = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            val session = (value as? String)?.let(::parse) ?: return@mapNotNull key to Long.MIN_VALUE
            key to session.expiresAt
        }.sortedByDescending { it.second }
        if (sessions.size <= MAX_SESSIONS) return
        val editor = prefs.edit()
        sessions.drop(MAX_SESSIONS).forEach { editor.remove(it.first) }
        editor.apply()
    }
}
