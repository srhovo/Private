package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

internal object AppUi {
    // 视觉方向来自用户提供的 HTML：浅灰背景、白色卡片、黑色主按钮、低饱和文本。
    const val BG = 0xFFF8F9FA.toInt()
    const val CARD = 0xFFFFFFFF.toInt()
    const val CARD_SOFT = 0xFFFCFCFD.toInt()
    const val TEXT = 0xFF1A1A1A.toInt()
    const val SUBTLE = 0xFF6E6E73.toInt()
    const val MUTED_2 = 0xFF86868B.toInt()
    const val PRIMARY = 0xFF1A1A1A.toInt()
    const val PRIMARY_DARK = 0xFF000000.toInt()
    const val FILL = 0xFFF2F2F7.toInt()
    const val FILL_2 = 0xFFFCFCFD.toInt()
    const val GREEN = 0xFF0A7D45.toInt()
    const val ORANGE = 0xFFB27B00.toInt()
    const val RED = 0xFFC2410C.toInt()
    const val BLUE = 0xFF0066CC.toInt()
    const val LINE = 0x14000000
    const val LINE_STRONG = 0x22000000

    fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    fun applySystemBars(activity: Activity) {
        activity.window.statusBarColor = BG
        activity.window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    fun card(context: Context, padding: Int = 22): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(padding), context.dp(padding), context.dp(padding), context.dp(padding))
            background = rounded(CARD, context.dp(24), LINE)
            elevation = context.dp(2).toFloat()
        }
    }

    fun softBox(context: Context, padding: Int = 14): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(padding), context.dp(padding), context.dp(padding), context.dp(padding))
            background = rounded(FILL_2, context.dp(16), LINE)
        }
    }

    fun title(context: Context, text: String, size: Float = 24f): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = size
            setTextColor(TEXT)
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = true
        }
    }

    fun body(context: Context, text: String, size: Float = 15f): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = size
            setTextColor(SUBTLE)
            setLineSpacing(context.dp(3).toFloat(), 1f)
            includeFontPadding = true
        }
    }

    fun small(context: Context, text: String): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 12f
            setTextColor(MUTED_2)
            setLineSpacing(context.dp(2).toFloat(), 1f)
        }
    }

    fun chip(context: Context, text: String, color: Int): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 12f
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(context.dp(10), context.dp(5), context.dp(10), context.dp(5))
            background = rounded(withAlpha(color, 0.12f), context.dp(999))
        }
    }

    fun eyebrow(context: Context, text: String): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 13f
            setTextColor(SUBTLE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(context.dp(14), context.dp(6), context.dp(14), context.dp(6))
            background = rounded(CARD, context.dp(999), LINE)
            elevation = context.dp(1).toFloat()
        }
    }

    fun button(context: Context, text: String, primary: Boolean = true, enabled: Boolean = true, onClick: () -> Unit): TextView {
        val bg = when {
            !enabled -> 0xFFE0E0E5.toInt()
            primary -> PRIMARY
            else -> FILL
        }
        val stroke = if (primary || !enabled) null else LINE_STRONG
        val textColor = when {
            !enabled -> MUTED_2
            primary -> Color.WHITE
            else -> TEXT
        }
        return TextView(context).apply {
            this.text = text
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            gravity = Gravity.CENTER
            setPadding(context.dp(16), context.dp(14), context.dp(16), context.dp(14))
            background = rounded(bg, context.dp(14), stroke)
            isClickable = enabled
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.65f
            setOnClickListener { if (enabled) onClick() }
        }
    }

    fun row(context: Context): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    fun spacer(context: Context, h: Int): View = View(context).apply {
        layoutParams = LinearLayout.LayoutParams(1, context.dp(h))
    }

    fun lp(width: Int = LinearLayout.LayoutParams.MATCH_PARENT, height: Int = LinearLayout.LayoutParams.WRAP_CONTENT): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(width, height)
    }

    fun rounded(color: Int, radius: Int, strokeColor: Int? = null): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != null) setStroke(1, strokeColor)
        }
    }

    private fun withAlpha(color: Int, alpha: Float): Int {
        return Color.argb((255 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
    }
}
