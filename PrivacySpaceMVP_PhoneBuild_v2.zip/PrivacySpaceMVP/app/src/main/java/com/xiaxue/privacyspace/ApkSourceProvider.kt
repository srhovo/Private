package com.xiaxue.privacyspace

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

class ApkSourceProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun getType(uri: Uri): String? {
        return parse(uri)?.let { "application/vnd.android.package-archive" }
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val (sessionId, index) = parse(uri) ?: return null
        val ctx = context ?: return null
        val stored = ApkSourceSessionStore.fileForRead(ctx, sessionId, index).getOrNull()?.second ?: return null
        val columns = projection?.toList().orEmpty().ifEmpty {
            listOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        }
        return MatrixCursor(columns.toTypedArray(), 1).apply {
            addRow(columns.map { column ->
                when (column) {
                    OpenableColumns.DISPLAY_NAME -> stored.displayName
                    OpenableColumns.SIZE -> stored.sizeBytes
                    else -> null
                }
            })
        }
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw SecurityException("APK 来源只允许只读访问。")
        val (sessionId, index) = parse(uri) ?: throw SecurityException("APK 来源 URI 无效。")
        val ctx = context ?: throw IllegalStateException("Provider 尚未初始化。")
        val (_, stored) = ApkSourceSessionStore.fileForRead(ctx, sessionId, index).getOrThrow()
        ProvisioningDiagnostics.record(ctx, "APK 来源文件读取：session=$sessionId index=$index name=${stored.displayName}")
        return ParcelFileDescriptor.open(File(stored.canonicalPath), ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()

    private fun parse(uri: Uri): Pair<String, Int>? {
        val expectedAuthority = context?.packageName?.plus(".apk_source") ?: return null
        val actualAuthority = uri.authority.orEmpty().substringAfter('@')
        if (uri.scheme != "content" || actualAuthority != expectedAuthority) return null
        val segments = uri.pathSegments
        if (segments.size != 5 || segments[0] != "session" || segments[2] != "file") return null
        val sessionId = segments[1]
        val index = segments[3].toIntOrNull() ?: return null
        if (!Regex("[a-f0-9]{32}").matches(sessionId) || index < 0) return null
        return sessionId to index
    }
}
