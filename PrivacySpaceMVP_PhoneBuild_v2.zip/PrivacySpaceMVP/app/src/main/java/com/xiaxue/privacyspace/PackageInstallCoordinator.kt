package com.xiaxue.privacyspace

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.security.MessageDigest
import java.security.SecureRandom

internal object PackageInstallCoordinator {
    const val ACTION_INSTALL_STATUS = "com.xiaxue.privacyspace.action.PACKAGE_INSTALL_STATUS"
    const val EXTRA_INSTALL_REQUEST_ID = "com.xiaxue.privacyspace.extra.INSTALL_REQUEST_ID"
    private const val STALE_INSTALL_MS = 30 * 60 * 1000L

    data class Progress(
        val fileIndex: Int,
        val fileCount: Int,
        val fileName: String,
        val completedBytes: Long,
        val totalBytes: Long
    )

    data class Submission(val requestId: String, val installerSessionId: Int)

    fun install(
        context: Context,
        sourceIntent: Intent,
        onProgress: (Progress) -> Unit = {}
    ): Result<Submission> = runCatching {
        require(WorkProfileManager(context).isProfileOwner()) { "正式克隆必须由隔离空间 Profile Owner 执行。" }
        val descriptor = ApkSourceVerifier.descriptorFromIntent(sourceIntent).getOrThrow()
        descriptor.validationError()?.let { throw IllegalArgumentException(it) }

        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(descriptor.packageName)
            setSize(descriptor.totalBytes)
            setInstallReason(PackageManager.INSTALL_REASON_POLICY)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
                setInstallScenario(PackageManager.INSTALL_SCENARIO_FAST)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                setPackageSource(PackageInstaller.PACKAGE_SOURCE_OTHER)
            }
        }

        var installerSessionId = -1
        var requestId = ""
        var committed = false
        try {
            installerSessionId = installer.createSession(params)
            requestId = randomRequestId()
            val now = System.currentTimeMillis()
            val record = InstallRequestStore.Record(
                requestId = requestId,
                installerSessionId = installerSessionId,
                sourceSessionId = descriptor.sessionId,
                packageName = descriptor.packageName,
                label = descriptor.label,
                versionCode = descriptor.versionCode,
                versionName = descriptor.versionName,
                signingSha256 = descriptor.signingSha256,
                fileCount = descriptor.files.size,
                totalBytes = descriptor.totalBytes,
                createdAt = now,
                updatedAt = now,
                state = InstallRequestStore.STATE_PREPARING,
                status = null,
                legacyStatus = null,
                message = null
            )
            check(InstallRequestStore.create(context, record)) { "无法保存安装请求状态。" }
            InstallRequestStore.updateState(context, requestId, InstallRequestStore.STATE_WRITING)

            var completedBytes = 0L
            installer.openSession(installerSessionId).use { session ->
                descriptor.files.sortedBy { it.index }.forEachIndexed { position, source ->
                    val installName = installName(source, position)
                    val digest = MessageDigest.getInstance("SHA-256")
                    var fileBytes = 0L
                    context.contentResolver.openInputStream(source.uri).use { input ->
                        requireNotNull(input) { "无法打开 ${source.displayName}。" }
                        session.openWrite(installName, 0L, source.sizeBytes).use { output ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 8)
                            var lastReported = 0L
                            while (true) {
                                val read = input.read(buffer)
                                if (read < 0) break
                                if (read == 0) continue
                                output.write(buffer, 0, read)
                                digest.update(buffer, 0, read)
                                fileBytes += read
                                completedBytes += read
                                if (fileBytes - lastReported >= REPORT_STEP_BYTES || completedBytes == descriptor.totalBytes) {
                                    lastReported = fileBytes
                                    onProgress(
                                        Progress(
                                            fileIndex = position + 1,
                                            fileCount = descriptor.files.size,
                                            fileName = source.displayName,
                                            completedBytes = completedBytes,
                                            totalBytes = descriptor.totalBytes
                                        )
                                    )
                                }
                            }
                            session.fsync(output)
                        }
                    }
                    require(fileBytes == source.sizeBytes) { "${source.displayName} 写入大小校验失败。" }
                    val actualDigest = digest.digest().joinToString("") { "%02x".format(it) }
                    require(actualDigest == source.sha256) { "${source.displayName} 写入哈希校验失败。" }
                    onProgress(
                        Progress(
                            fileIndex = position + 1,
                            fileCount = descriptor.files.size,
                            fileName = source.displayName,
                            completedBytes = completedBytes,
                            totalBytes = descriptor.totalBytes
                        )
                    )
                }
                require(completedBytes == descriptor.totalBytes) { "APK 安装 Session 总大小校验失败。" }

                val callback = Intent(context, InstallResultActivity::class.java).apply {
                    action = ACTION_INSTALL_STATUS
                    data = Uri.Builder()
                        .scheme("xiaxue-install")
                        .authority("result")
                        .appendPath(requestId)
                        .build()
                    putExtra(EXTRA_INSTALL_REQUEST_ID, requestId)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
                val statusIntent = PendingIntent.getActivity(
                    context,
                    installerSessionId,
                    callback,
                    pendingIntentFlags
                )
                InstallRequestStore.updateState(context, requestId, InstallRequestStore.STATE_COMMITTED)
                session.commit(statusIntent.intentSender)
                committed = true
            }
            ProvisioningDiagnostics.record(
                context,
                "PackageInstaller 已提交：${descriptor.packageName} session=$installerSessionId request=$requestId files=${descriptor.files.size} bytes=$completedBytes"
            )
            Submission(requestId, installerSessionId)
        } catch (error: Throwable) {
            if (installerSessionId >= 0 && !committed) {
                runCatching { installer.abandonSession(installerSessionId) }
                    .onFailure { ProvisioningDiagnostics.record(context, "废弃失败的安装 Session 失败：$installerSessionId", it) }
            }
            if (requestId.isNotBlank()) {
                InstallRequestStore.updateState(
                    context,
                    requestId,
                    InstallRequestStore.STATE_FAILURE,
                    message = error.message ?: error.javaClass.simpleName
                )
            }
            throw error
        }
    }.onFailure {
        ProvisioningDiagnostics.record(context, "PackageInstaller 正式克隆提交失败", it)
    }

    fun reconcilePackage(context: Context, packageName: String) {
        if (!WorkProfileManager(context).isProfileOwner() || packageName.isBlank()) return
        InstallRequestStore.pending(context)
            .filter { it.packageName == packageName }
            .forEach { record ->
                InstalledPackageVerifier.verify(context, record).onSuccess {
                    InstallRequestStore.updateState(
                        context,
                        record.requestId,
                        InstallRequestStore.STATE_SUCCESS,
                        status = PackageInstaller.STATUS_SUCCESS,
                        message = "安装结果已通过包变更广播恢复确认。"
                    )
                    ProvisioningDiagnostics.record(
                        context,
                        "通过包变更广播确认安装：${record.packageName} session=${record.installerSessionId}"
                    )
                }
            }
    }

    fun reconcileStale(context: Context) {
        if (!WorkProfileManager(context).isProfileOwner()) return
        val now = System.currentTimeMillis()
        val installer = context.packageManager.packageInstaller
        InstallRequestStore.pending(context).forEach { record ->
            if (now - record.updatedAt < STALE_INSTALL_MS) return@forEach
            val installed = InstalledPackageVerifier.verify(context, record).isSuccess
            if (installed) {
                InstallRequestStore.updateState(
                    context,
                    record.requestId,
                    InstallRequestStore.STATE_SUCCESS,
                    status = PackageInstaller.STATUS_SUCCESS,
                    message = "安装结果已通过本地状态恢复确认。"
                )
                return@forEach
            }
            val sessionExists = runCatching { installer.getSessionInfo(record.installerSessionId) != null }.getOrDefault(false)
            if (sessionExists) runCatching { installer.abandonSession(record.installerSessionId) }
            InstallRequestStore.updateState(
                context,
                record.requestId,
                InstallRequestStore.STATE_FAILURE,
                status = PackageInstaller.STATUS_FAILURE,
                message = "安装超过 30 分钟仍未完成，已清理残留 Session。"
            )
            ProvisioningDiagnostics.record(context, "清理超时安装：${record.packageName} session=${record.installerSessionId}")
        }
    }

    private fun installName(source: ApkSourceFile, position: Int): String {
        if (position == 0) return "base.apk"
        val cleaned = source.displayName.removeSuffix(".apk")
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .take(96)
            .ifBlank { "split" }
        return "split_${position}_$cleaned.apk"
    }

    private fun randomRequestId(): String {
        val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private const val REPORT_STEP_BYTES = 4L * 1024L * 1024L
}
