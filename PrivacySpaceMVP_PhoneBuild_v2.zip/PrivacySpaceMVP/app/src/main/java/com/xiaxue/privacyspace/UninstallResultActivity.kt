package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import java.security.MessageDigest

class UninstallResultActivity : Activity() {
    @Volatile private var completing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && !completing) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(source: Intent) {
        if (source.action != PackageUninstallCoordinator.ACTION_UNINSTALL_STATUS) {
            finish()
            return
        }
        val operationId = source.getStringExtra(PackageUninstallCoordinator.EXTRA_OPERATION_ID)?.trim().orEmpty()
        val token = source.getStringExtra(PackageUninstallCoordinator.EXTRA_CALLBACK_TOKEN)?.trim().orEmpty()
        val record = LifecycleRequestStore.read(this, operationId)
        if (record == null || !MessageDigest.isEqual(
                record.callbackToken.toByteArray(Charsets.UTF_8),
                token.toByteArray(Charsets.UTF_8)
            )
        ) {
            ProvisioningDiagnostics.record(this, "拒绝未知卸载回调：operation=$operationId")
            finish()
            return
        }
        val callbackPackage = source.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)?.trim().orEmpty()
        if (callbackPackage.isNotBlank() && callbackPackage != record.packageName) {
            ProvisioningDiagnostics.record(this, "拒绝包名不匹配的卸载回调：$callbackPackage")
            finish()
            return
        }
        val status = source.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = source.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)?.trim().orEmpty()
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> handleUserAction(source, record)
            PackageInstaller.STATUS_SUCCESS -> handleSuccess(record)
            else -> handleFailure(record, status, message)
        }
    }

    private fun handleUserAction(source: Intent, record: LifecycleRequestStore.Record) {
        LifecycleRequestStore.updateState(this, record.operationId, "awaiting_user")
        val confirmation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            source.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            source.getParcelableExtra(Intent.EXTRA_INTENT)
        }
        if (confirmation == null) {
            handleFailure(record, PackageInstaller.STATUS_FAILURE, "系统要求确认卸载，但没有返回确认页面。")
            return
        }
        runCatching { startActivity(confirmation) }.onFailure {
            handleFailure(record, PackageInstaller.STATUS_FAILURE, "无法打开系统卸载确认页面：${it.message}")
        }
    }

    private fun handleSuccess(record: LifecycleRequestStore.Record) {
        if (completing) return
        completing = true
        LifecycleRequestStore.updateState(this, record.operationId, "success")
        ProvisioningDiagnostics.record(this, "隔离应用卸载成功：${record.packageName}")
        finishAfterRemoteState(record) {
            Toast.makeText(this, "已卸载 ${record.label}", Toast.LENGTH_LONG).show()
            LifecycleRequestStore.remove(this, record.operationId)
            finish()
        }
    }

    private fun handleFailure(record: LifecycleRequestStore.Record, status: Int, message: String) {
        if (completing) return
        completing = true
        LifecycleRequestStore.updateState(this, record.operationId, "failure")
        val reason = when (status) {
            PackageInstaller.STATUS_FAILURE_ABORTED -> "卸载已被用户或系统取消。"
            PackageInstaller.STATUS_FAILURE_BLOCKED -> "系统或设备策略阻止了卸载。"
            PackageInstaller.STATUS_FAILURE_CONFLICT -> "应用当前状态与卸载请求冲突。"
            else -> "卸载失败，状态码：$status。"
        }
        val details = if (message.isBlank() || message == reason) reason else "$reason\n\n系统信息：$message"
        ProvisioningDiagnostics.record(this, "隔离应用卸载失败：${record.packageName} status=$status message=$details")
        finishAfterRemoteState(record) {
            AlertDialog.Builder(this)
                .setTitle("卸载失败")
                .setMessage("${record.label}\n${record.packageName}\n\n$details")
                .setPositiveButton("知道了") { _, _ ->
                    LifecycleRequestStore.remove(this, record.operationId)
                    finish()
                }
                .setOnCancelListener {
                    LifecycleRequestStore.remove(this, record.operationId)
                    finish()
                }
                .show()
        }
    }

    private fun finishAfterRemoteState(record: LifecycleRequestStore.Record, continuation: () -> Unit) {
        val requestId = record.remoteStateRequestId
        if (requestId == null) {
            continuation()
            return
        }
        Thread {
            runCatching {
                val snapshot = ProfileStateRepository(this).capture(requestId, setOf(record.packageName))
                WorkProfileManager(this).sendProfileStateResult(this, snapshot).getOrThrow()
            }.onFailure {
                ProvisioningDiagnostics.record(this, "卸载后状态回传失败", it)
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) continuation()
            }
        }.start()
    }
}
