package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class CloneRequestActivity : Activity() {
    private lateinit var manager: WorkProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = WorkProfileManager(this)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handle(intent)
    }

    private fun handle(source: Intent) {
        val packageName = source.getStringExtra(ProvisioningContract.EXTRA_PACKAGE_NAME)?.trim().orEmpty()
        val label = source.getStringExtra(ProvisioningContract.EXTRA_APP_LABEL)?.trim().orEmpty().ifBlank { packageName }

        if (packageName.isBlank()) {
            Toast.makeText(this, "克隆失败：缺少包名", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        if (!manager.isProfileOwner()) {
            AlertDialog.Builder(this)
                .setTitle("需要选择隔离空间")
                .setMessage(
                    "当前打开的是主空间里的本 App，不能直接执行克隆。\n\n" +
                        "请在选择器里点带工作资料角标的“下雪应用隔离”；如果选择器没有出现隔离空间入口，请到隔离空间里打开本 App，再搜索包名克隆：\n\n$label\n$packageName"
                )
                .setPositiveButton("知道了") { _, _ -> finish() }
                .setOnCancelListener { finish() }
                .show()
            return
        }

        val result = manager.cloneExistingPackageToThisProfile(packageName)
        result.fold(
            onSuccess = { installed ->
                if (installed || manager.isInstalledInCurrentProfile(packageName)) {
                    showSuccess(label, packageName)
                } else {
                    showFailure(label, packageName, "系统返回未完成安装。请确认主空间已安装该 App，且包名正确。")
                }
            },
            onFailure = { error -> showFailure(label, packageName, error.message ?: error.javaClass.simpleName) }
        )
    }

    private fun showSuccess(label: String, packageName: String) {
        AlertDialog.Builder(this)
            .setTitle("已创建隔离分身")
            .setMessage("$label\n$packageName\n\n已安装/启用到隔离空间。")
            .setPositiveButton("打开") { _, _ ->
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                if (launchIntent == null) {
                    Toast.makeText(this, "已克隆，但当前空间没有找到可启动入口。", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    startActivity(launchIntent)
                    finish()
                }
            }
            .setNegativeButton("完成") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showFailure(label: String, packageName: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle("克隆失败")
            .setMessage("$label\n$packageName\n\n$message")
            .setPositiveButton("知道了") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }
}
