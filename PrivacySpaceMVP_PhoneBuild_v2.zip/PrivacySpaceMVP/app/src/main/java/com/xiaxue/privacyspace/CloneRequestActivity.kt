package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast

class CloneRequestActivity : Activity() {
    private lateinit var manager: WorkProfileManager
    @Volatile private var installRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        if (intent.action != ProvisioningContract.ACTION_CLONE_PACKAGE) {
            setTheme(R.style.TransparentActivityTheme)
        }
        super.onCreate(savedInstanceState)
        manager = WorkProfileManager(this)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && !installRunning) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(source: Intent) {
        if (!manager.isProfileOwner()) {
            ProfileSetup.configureCrossProfileReceiversForCurrentProfile(this)
            ProvisioningDiagnostics.record(this, "跨资料入口在非工作资料环境被触发：${source.action}")
            finishQuietly()
            return
        }

        val verification = CrossProfileAuth.verify(this, source)
        if (!verification.accepted) {
            ProvisioningDiagnostics.record(this, "拒绝跨资料请求：${source.action} · ${verification.reason}")
            Toast.makeText(this, verification.reason ?: "已拒绝未经认证的请求", Toast.LENGTH_LONG).show()
            finishQuietly()
            return
        }

        val requestId = source.getStringExtra(ProvisioningContract.EXTRA_STATE_REQUEST_ID)?.trim().orEmpty()
        if (source.action == ProvisioningContract.ACTION_QUERY_WORK_PROFILE) {
            if (requestId.isBlank()) finishQuietly() else sendStateResult(requestId, null)
            return
        }

        val packageName = source.getStringExtra(ProvisioningContract.EXTRA_PACKAGE_NAME)?.trim().orEmpty()
        val label = source.getStringExtra(ProvisioningContract.EXTRA_APP_LABEL)
            ?.trim()
            .orEmpty()
            .ifBlank { packageName }
        if (packageName.isBlank()) {
            Toast.makeText(this, "请求失败：缺少包名", Toast.LENGTH_LONG).show()
            finishQuietly()
            return
        }

        when (source.action) {
            ProvisioningContract.ACTION_CLONE_PACKAGE -> handleClone(source, packageName, label)
            ProvisioningContract.ACTION_LAUNCH_PACKAGE -> handleLaunch(packageName, requestId)
            ProvisioningContract.ACTION_SET_PACKAGE_HIDDEN -> handleHidden(source, packageName, label, requestId)
            ProvisioningContract.ACTION_UNINSTALL_PACKAGE -> handleUninstall(packageName, label, requestId)
            else -> {
                ProvisioningDiagnostics.record(this, "拒绝未知跨资料动作：${source.action}")
                finishQuietly()
            }
        }
    }

    private fun handleClone(source: Intent, packageName: String, label: String) {
        if (installRunning) return
        installRunning = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val progress = AlertDialog.Builder(this)
            .setTitle("正在克隆应用")
            .setMessage("正在校验并写入 base APK 与 split APK，请勿关闭页面。")
            .setCancelable(false)
            .create()
        progress.show()

        Thread {
            val result = PackageInstallCoordinator.install(this, source) { state ->
                runOnUiThread {
                    if (!progress.isShowing || isFinishing || isDestroyed) return@runOnUiThread
                    val percent = if (state.totalBytes > 0L) {
                        ((state.completedBytes * 100L) / state.totalBytes).coerceIn(0L, 100L)
                    } else 0L
                    progress.setMessage(
                        "正在写入 ${state.fileIndex}/${state.fileCount}：${state.fileName}\n" +
                            "进度：$percent%（${formatBytes(state.completedBytes)} / ${formatBytes(state.totalBytes)}）"
                    )
                }
            }
            runOnUiThread {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (progress.isShowing) progress.dismiss()
                if (isFinishing || isDestroyed) return@runOnUiThread
                result.fold(
                    onSuccess = { submission ->
                        ProvisioningDiagnostics.record(
                            this,
                            "正式克隆安装已提交：$packageName request=${submission.requestId} session=${submission.installerSessionId}"
                        )
                        Toast.makeText(this, "安装已提交，请按系统提示完成确认。", Toast.LENGTH_LONG).show()
                        finish()
                    },
                    onFailure = { error ->
                        installRunning = false
                        showFailure(label, packageName, error.message ?: error.javaClass.simpleName)
                    }
                )
            }
        }.start()
    }

    private fun handleLaunch(packageName: String, requestId: String) {
        manager.prepareLaunchIntentInThisProfile(packageName).fold(
            onSuccess = { launchIntent ->
                if (requestId.isBlank()) {
                    startActivity(launchIntent)
                    finish()
                } else {
                    sendStateResult(requestId, setOf(packageName)) {
                        startActivity(launchIntent)
                        finish()
                    }
                }
            },
            onFailure = { error ->
                Toast.makeText(this, error.message ?: "无法启动应用", Toast.LENGTH_LONG).show()
                if (requestId.isBlank()) finishQuietly()
                else sendStateResult(requestId, setOf(packageName))
            }
        )
    }

    private fun handleHidden(source: Intent, packageName: String, label: String, requestId: String) {
        if (requestId.isBlank() || !source.hasExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN)) {
            Toast.makeText(this, "冻结请求缺少状态参数", Toast.LENGTH_LONG).show()
            finishQuietly()
            return
        }
        val hidden = source.getBooleanExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN, false)
        manager.setPackageHidden(packageName, hidden).fold(
            onSuccess = { changed ->
                val message = when {
                    changed && hidden -> "已冻结 $label"
                    changed -> "已恢复 $label"
                    else -> "系统未完成状态修改"
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                sendStateResult(requestId, setOf(packageName))
            },
            onFailure = { error ->
                Toast.makeText(this, error.message ?: "状态修改失败", Toast.LENGTH_LONG).show()
                sendStateResult(requestId, setOf(packageName))
            }
        )
    }

    private fun handleUninstall(packageName: String, label: String, requestId: String) {
        if (requestId.isBlank()) {
            Toast.makeText(this, "卸载请求缺少状态请求 ID", Toast.LENGTH_LONG).show()
            finishQuietly()
            return
        }
        PackageUninstallCoordinator.submit(this, packageName, label, requestId).fold(
            onSuccess = {
                Toast.makeText(this, "已提交卸载，请按系统提示确认。", Toast.LENGTH_LONG).show()
                finish()
            },
            onFailure = { error ->
                Toast.makeText(this, error.message ?: "无法提交卸载", Toast.LENGTH_LONG).show()
                sendStateResult(requestId, setOf(packageName))
            }
        )
    }

    private fun sendStateResult(
        requestId: String,
        packageNames: Set<String>?,
        afterSend: (() -> Unit)? = null
    ) {
        Thread {
            val result = runCatching { ProfileStateRepository(this).capture(requestId, packageNames) }
                .fold(
                    onSuccess = { manager.sendProfileStateResult(this, it) },
                    onFailure = { Result.failure(it) }
                )
            runOnUiThread {
                result.onFailure { ProvisioningDiagnostics.record(this, "隔离空间状态回传失败", it) }
                if (afterSend == null) finishQuietly() else afterSend()
            }
        }.start()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return "%.1f MB".format(mb)
        return "%.2f GB".format(mb / 1024.0)
    }

    private fun showFailure(label: String, packageName: String, message: String) {
        val target = if (label == packageName) label else "$label\n$packageName"
        AlertDialog.Builder(this)
            .setTitle("克隆提交失败")
            .setMessage("$target\n\n$message")
            .setPositiveButton("知道了") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun finishQuietly() {
        finish()
        overridePendingTransition(0, 0)
    }
}
