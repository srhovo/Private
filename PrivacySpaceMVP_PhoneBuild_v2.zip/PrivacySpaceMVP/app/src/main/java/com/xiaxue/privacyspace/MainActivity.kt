package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.xiaxue.privacyspace.AppUi.BG
import com.xiaxue.privacyspace.AppUi.BLUE
import com.xiaxue.privacyspace.AppUi.FILL_2
import com.xiaxue.privacyspace.AppUi.GREEN
import com.xiaxue.privacyspace.AppUi.ORANGE
import com.xiaxue.privacyspace.AppUi.RED
import com.xiaxue.privacyspace.AppUi.SUBTLE
import com.xiaxue.privacyspace.AppUi.TEXT
import com.xiaxue.privacyspace.AppUi.applySystemBars
import com.xiaxue.privacyspace.AppUi.body
import com.xiaxue.privacyspace.AppUi.button
import com.xiaxue.privacyspace.AppUi.card
import com.xiaxue.privacyspace.AppUi.chip
import com.xiaxue.privacyspace.AppUi.dp
import com.xiaxue.privacyspace.AppUi.eyebrow
import com.xiaxue.privacyspace.AppUi.lp
import com.xiaxue.privacyspace.AppUi.row
import com.xiaxue.privacyspace.AppUi.small
import com.xiaxue.privacyspace.AppUi.softBox
import com.xiaxue.privacyspace.AppUi.spacer
import com.xiaxue.privacyspace.AppUi.title

class MainActivity : Activity() {
    private lateinit var manager: WorkProfileManager
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars(this)
        manager = WorkProfileManager(this)
        ProfileSetup.configureCloneReceiverForCurrentProfile(this)
        buildPage()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) buildPage()
    }

    private fun buildPage() {
        val compat = manager.compatibility()
        if (compat.isProfileOwner) ProfileSetup.complete(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(32), dp(20), dp(34))
            setBackgroundColor(BG)
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(eyebrow(this@MainActivity, "❄️ XiaXue Space"))
            addView(spacer(this@MainActivity, 18))
            addView(title(this@MainActivity, "下雪应用隔离", 34f).apply {
                gravity = Gravity.CENTER
            })
            addView(body(this@MainActivity, "独立空间 · 应用分身 · 隐私管理", 15f).apply {
                gravity = Gravity.CENTER
            })
        }
        root.addView(hero, lp())
        root.addView(spacer(this, 26))

        val statusCard = card(this).apply {
            val topRow = row(this@MainActivity)
            val titleBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(title(this@MainActivity, "当前状态", 20f))
                addView(body(this@MainActivity, if (compat.isProfileOwner) "正在管理隔离空间" else "当前位于主空间", 14f))
            }
            topRow.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            topRow.addView(chip(this@MainActivity, if (compat.isProfileOwner) "隔离空间" else "主空间", if (compat.isProfileOwner) GREEN else ORANGE))
            addView(topRow)
            addView(spacer(this@MainActivity, 16))
            addView(statusLine("工作资料管理者", if (compat.isProfileOwner) "是" else "否", if (compat.isProfileOwner) GREEN else ORANGE))
            addView(statusLine("系统支持工作资料", if (compat.supportsManagedUsers) "是" else "否", if (compat.supportsManagedUsers) GREEN else RED))
            addView(statusLine("系统允许创建", if (compat.provisioningAllowed) "是" else "否", if (compat.provisioningAllowed) GREEN else RED))
            addView(statusLine("设备管理者", if (compat.isDeviceOwner) "是" else "否", if (compat.isDeviceOwner) ORANGE else GREEN))
            addView(statusLine("关联用户数", compat.userProfileCount.toString(), if (compat.userProfileCount > 1) ORANGE else BLUE))
            addView(statusLine("最近创建记录", ProvisioningDiagnostics.lastEvent(this@MainActivity), BLUE))
            addView(statusLine("设备", "${compat.manufacturer} ${compat.model} / Android ${compat.sdk}", BLUE))
        }
        root.addView(statusCard, lp())
        root.addView(spacer(this, 16))

        val actionCard = card(this).apply {
            addView(title(this@MainActivity, "空间管理", 20f))
            addView(spacer(this@MainActivity, 6))
            addView(body(this@MainActivity, "创建系统工作资料后，可搜索主空间 App，并安装/启用到隔离空间。", 14f))
            addView(spacer(this@MainActivity, 16))
            addView(button(this@MainActivity, "创建独立工作资料空间", true, compat.canCreateProfile) {
                startActivity(Intent(this@MainActivity, SetupWizardActivity::class.java))
            }, lp())
            addView(spacer(this@MainActivity, 10))
            addView(button(this@MainActivity, "管理当前空间应用", false, true) {
                startActivity(Intent(this@MainActivity, AppsActivity::class.java))
            }, lp())
            addView(spacer(this@MainActivity, 10))
            addView(button(this@MainActivity, "重置隔离资料说明", false, true) { showResetGuide() }, lp())
            addView(spacer(this@MainActivity, 10))
            addView(button(this@MainActivity, "复制创建诊断", false, true) { copyDiagnostics() }, lp())
        }
        root.addView(actionCard, lp())
        root.addView(spacer(this, 16))

        val guideCard = card(this).apply {
            addView(title(this@MainActivity, "使用说明", 20f))
            addView(spacer(this@MainActivity, 12))
            addView(guideItem("1", "创建隔离空间", "通过 Android 系统工作资料能力创建独立空间。"))
            addView(spacer(this@MainActivity, 10))
            addView(guideItem("2", "搜索并克隆", "在应用管理中搜索 App，选择安装/克隆到隔离空间。"))
            addView(spacer(this@MainActivity, 10))
            addView(guideItem("3", "按需重置资料", "需要清空隔离资料时，到系统设置中手动移除工作资料/分身资料。"))
        }
        root.addView(guideCard, lp())
        root.addView(spacer(this, 16))

        val limitCard = card(this).apply {
            addView(title(this@MainActivity, "功能限制", 20f))
            addView(spacer(this@MainActivity, 10))
            addView(body(this@MainActivity,
                "如果系统提示“无法设置设备”，第一阶段会优先检查 DPC 创建链路。常见外部原因包括：已有工作资料、企业/家长管理状态、厂商 ROM 禁用，或当前不是主用户。", 14f))
            addView(spacer(this@MainActivity, 14))
            addView(button(this@MainActivity, "查看限制原因", false, true) { showProvisionHelp(null) }, lp())
        }
        root.addView(limitCard, lp())
        root.addView(spacer(this, 14))
        root.addView(small(this, "本工具定位为隐私隔离、工作生活分离与应用测试隔离。"), lp())

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }

    private fun statusLine(label: String, value: String, color: Int): TextView {
        return TextView(this).apply {
            text = "$label：$value"
            textSize = 14f
            setTextColor(color)
            setPadding(0, dp(4), 0, dp(4))
        }
    }

    private fun guideItem(num: String, heading: String, text: String): LinearLayout {
        val box = softBox(this, 14).apply { orientation = LinearLayout.HORIZONTAL }
        val badge = TextView(this).apply {
            this.text = num
            textSize = 12f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            background = AppUi.rounded(TEXT, dp(13))
        }
        box.addView(badge, LinearLayout.LayoutParams(dp(26), dp(26)))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            addView(TextView(this@MainActivity).apply {
                this.text = heading
                textSize = 14f
                setTextColor(TEXT)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            })
            addView(body(this@MainActivity, text, 13f))
        }
        box.addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return box
    }

    private fun copyDiagnostics() {
        val ok = ProvisioningDiagnostics.copySnapshot(this, manager)
        Toast.makeText(this, if (ok) "已复制创建诊断" else "复制失败", Toast.LENGTH_LONG).show()
    }

    private fun showResetGuide() {
        AlertDialog.Builder(this)
            .setTitle("重置隔离资料")
            .setMessage(
                "重置分身资料需要在手机系统设置里手动移除工作资料/分身资料。\n\n" +
                    "推荐路径：\n" +
                    "手机设置 → 用户与账号 / 账号与同步 / 多用户 → 工作资料 / 工作空间 / 分身资料 → 移除工作资料或移除分身资料。\n\n" +
                    "不同手机品牌的名称可能不完全一样。移除后，隔离空间里的应用和数据会被清空；需要重新回到本 App 创建独立工作资料空间。"
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("打开系统设置") { _, _ -> openSystemSettings() }
            .show()
    }

    private fun showProvisionHelp(error: String?) {
        AlertDialog.Builder(this)
            .setTitle("为什么功能受限")
            .setMessage(
                (if (error.isNullOrBlank()) "" else "当前错误：$error\n\n") +
                    "Android 工作资料创建由系统控制。常见限制包括：\n\n" +
                    "1. 手机已经存在工作资料或分身资料。\n" +
                    "2. 当前设备被企业、学校、家长控制或其他管理器占用。\n" +
                    "3. 厂商系统关闭了工作资料创建入口。\n" +
                    "4. 当前不是主用户，或系统版本/ROM 不完整。\n\n" +
                    "可尝试：先在系统设置中移除已有工作资料，再重启手机后重新创建。"
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("打开系统设置") { _, _ -> openSystemSettings() }
            .show()
    }

    private fun openSystemSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开系统设置", Toast.LENGTH_LONG).show() }
    }
}
