package com.xiaxue.privacyspace

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal object CrossProfileAuth {
    private const val PREF = "xiaxue_cross_profile_auth"
    private const val KEY_SECRET = "command_secret"
    private const val KEY_REPLAY_CACHE = "replay_cache"
    private const val EXTRA_SECRET = "com.xiaxue.privacyspace.extra.PROFILE_COMMAND_SECRET"

    const val EXTRA_TIMESTAMP = "com.xiaxue.privacyspace.extra.COMMAND_TIMESTAMP"
    const val EXTRA_NONCE = "com.xiaxue.privacyspace.extra.COMMAND_NONCE"
    const val EXTRA_SIGNATURE = "com.xiaxue.privacyspace.extra.COMMAND_SIGNATURE"

    private const val MAX_AGE_MS = 2 * 60 * 1000L
    private const val REPLAY_RETENTION_MS = 5 * 60 * 1000L
    private const val MAX_REPLAY_ENTRIES = 32

    fun hasKey(context: Context): Boolean = readKey(context) != null

    fun ensureKey(context: Context): String {
        readKey(context)?.let { return it }
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SECRET, encoded)
            .commit()
        return encoded
    }

    fun provisioningExtras(context: Context): PersistableBundle {
        return PersistableBundle().apply {
            putString(EXTRA_SECRET, ensureKey(context))
        }
    }

    fun importProvisioningExtras(context: Context, intent: Intent?): Boolean {
        @Suppress("DEPRECATION")
        val extras = intent?.getParcelableExtra<PersistableBundle>(
            DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE
        ) ?: return false
        val incoming = extras.getString(EXTRA_SECRET)?.trim().orEmpty()
        if (!isValidEncodedKey(incoming)) return false

        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_SECRET, null)
        if (existing != null && existing != incoming) {
            ProvisioningDiagnostics.record(context, "拒绝覆盖已存在的跨资料命令密钥")
            return false
        }
        return prefs.edit().putString(KEY_SECRET, incoming).commit()
    }

    fun sign(context: Context, intent: Intent): Intent {
        val secret = ensureKey(context)
        val timestamp = System.currentTimeMillis()
        val nonce = UUID.randomUUID().toString()
        intent.putExtra(EXTRA_TIMESTAMP, timestamp)
        intent.putExtra(EXTRA_NONCE, nonce)
        intent.putExtra(EXTRA_SIGNATURE, calculateSignature(secret, intent, timestamp, nonce))
        return intent
    }

    fun verify(context: Context, intent: Intent): VerificationResult {
        val secret = readKey(context)
            ?: return VerificationResult(false, "当前隔离资料未建立安全配对，请移除旧工作资料并用新版重新创建。")
        val timestamp = intent.getLongExtra(EXTRA_TIMESTAMP, Long.MIN_VALUE)
        val nonce = intent.getStringExtra(EXTRA_NONCE)?.trim().orEmpty()
        val signature = intent.getStringExtra(EXTRA_SIGNATURE)?.trim().orEmpty()
        if (timestamp == Long.MIN_VALUE || nonce.isBlank() || signature.isBlank()) {
            return VerificationResult(false, "请求缺少安全签名。")
        }

        val now = System.currentTimeMillis()
        if (kotlin.math.abs(now - timestamp) > MAX_AGE_MS) {
            return VerificationResult(false, "请求已过期。")
        }

        val expected = calculateSignature(secret, intent, timestamp, nonce)
        val expectedBytes = expected.toByteArray(Charsets.UTF_8)
        val actualBytes = signature.toByteArray(Charsets.UTF_8)
        if (!MessageDigest.isEqual(expectedBytes, actualBytes)) {
            return VerificationResult(false, "请求签名无效。")
        }

        if (!consumeNonce(context, nonce, now)) {
            return VerificationResult(false, "请求已被处理或发生重放。")
        }
        return VerificationResult(true, null)
    }

    private fun calculateSignature(secret: String, intent: Intent, timestamp: Long, nonce: String): String {
        val payload = listOf(
            intent.action.orEmpty(),
            intent.getStringExtra(ProvisioningContract.EXTRA_PACKAGE_NAME).orEmpty(),
            intent.getStringExtra(ProvisioningContract.EXTRA_APP_LABEL).orEmpty(),
            intent.getStringExtra(ProvisioningContract.EXTRA_APK_SOURCE_SESSION_ID).orEmpty(),
            intent.getStringExtra(ProvisioningContract.EXTRA_APK_SOURCE_MANIFEST_SHA256).orEmpty(),
            intent.getStringExtra(ProvisioningContract.EXTRA_STATE_REQUEST_ID).orEmpty(),
            if (intent.hasExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN)) {
                intent.getBooleanExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN, false).toString()
            } else "",
            intent.getStringExtra(ProvisioningContract.EXTRA_PROFILE_STATE_SHA256).orEmpty(),
            timestamp.toString(),
            nonce
        ).joinToString("\u0000")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(Base64.decode(secret, Base64.NO_WRAP), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(payload.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun consumeNonce(context: Context, nonce: String, now: Long): Boolean {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val retained = prefs.getString(KEY_REPLAY_CACHE, "").orEmpty()
            .split('|')
            .mapNotNull { item ->
                val separator = item.lastIndexOf(':')
                if (separator <= 0) return@mapNotNull null
                val storedNonce = item.substring(0, separator)
                val storedAt = item.substring(separator + 1).toLongOrNull() ?: return@mapNotNull null
                if (now - storedAt <= REPLAY_RETENTION_MS) storedNonce to storedAt else null
            }
            .toMutableList()
        if (retained.any { it.first == nonce }) return false
        retained += nonce to now
        val serialized = retained.takeLast(MAX_REPLAY_ENTRIES)
            .joinToString("|") { "${it.first}:${it.second}" }
        return prefs.edit().putString(KEY_REPLAY_CACHE, serialized).commit()
    }

    private fun readKey(context: Context): String? {
        val value = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_SECRET, null)
            ?.trim()
        return value?.takeIf(::isValidEncodedKey)
    }

    private fun isValidEncodedKey(value: String): Boolean {
        return runCatching { Base64.decode(value, Base64.NO_WRAP).size == 32 }.getOrDefault(false)
    }

    data class VerificationResult(val accepted: Boolean, val reason: String?)
}
