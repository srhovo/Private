package com.xiaxue.privacyspace

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

internal data class ApkSourceFile(
    val index: Int,
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val uri: Uri
)

internal data class ApkSourceDescriptor(
    val sessionId: String,
    val packageName: String,
    val label: String,
    val versionCode: Long,
    val versionName: String,
    val signingSha256: List<String>,
    val expiresAt: Long,
    val files: List<ApkSourceFile>
) {
    val totalBytes: Long get() = files.sumOf { it.sizeBytes }
    val splitCount: Int get() = (files.size - 1).coerceAtLeast(0)

    fun toJson(): String {
        val fileArray = JSONArray()
        files.sortedBy { it.index }.forEach { file ->
            fileArray.put(
                JSONObject()
                    .put("index", file.index)
                    .put("displayName", file.displayName)
                    .put("sizeBytes", file.sizeBytes)
                    .put("sha256", file.sha256)
                    .put("uri", file.uri.toString())
            )
        }
        val signerArray = JSONArray()
        signingSha256.sorted().forEach { signerArray.put(it) }
        return JSONObject()
            .put("schema", SCHEMA_VERSION)
            .put("sessionId", sessionId)
            .put("packageName", packageName)
            .put("label", label)
            .put("versionCode", versionCode)
            .put("versionName", versionName)
            .put("signingSha256", signerArray)
            .put("expiresAt", expiresAt)
            .put("files", fileArray)
            .toString()
    }

    fun validationError(now: Long = System.currentTimeMillis()): String? {
        if (!PACKAGE_PATTERN.matches(packageName)) return "来源包名格式无效。"
        if (!SESSION_PATTERN.matches(sessionId)) return "来源会话编号无效。"
        if (expiresAt <= now) return "APK 来源会话已过期，请从主空间重新发起。"
        if (expiresAt - now > ApkSourceSessionStore.SESSION_TTL_MS + CLOCK_TOLERANCE_MS) {
            return "APK 来源会话有效期异常。"
        }
        if (files.isEmpty()) return "APK 来源不包含 base APK。"
        if (files.size > MAX_FILES) return "APK split 数量异常。"
        if (files.firstOrNull()?.index != 0) return "APK 来源缺少 base APK。"
        if (files.firstOrNull()?.displayName != "base.apk") return "base APK 文件名无效。"
        if (files.map { it.index } != files.indices.toList()) return "APK 文件序号不连续。"
        if (files.any { !APK_NAME_PATTERN.matches(it.displayName) }) return "APK 文件名格式无效。"
        if (files.map { it.displayName.lowercase() }.distinct().size != files.size) return "APK 文件名重复。"
        if (files.any { it.sizeBytes <= 0L }) return "APK 来源包含空文件。"
        if (files.any { !SHA256_PATTERN.matches(it.sha256) }) return "APK 文件摘要格式无效。"
        if (files.map { it.uri }.distinct().size != files.size) return "APK 来源包含重复 URI。"
        if (signingSha256.isEmpty() || signingSha256.any { !SHA256_PATTERN.matches(it) }) {
            return "应用签名摘要无效。"
        }
        if (totalBytes <= 0L || totalBytes > MAX_TOTAL_BYTES) return "APK 来源总大小异常。"
        return null
    }

    companion object {
        private const val SCHEMA_VERSION = 1
        private const val MAX_FILES = 256
        private const val MAX_TOTAL_BYTES = 20L * 1024L * 1024L * 1024L
        private const val CLOCK_TOLERANCE_MS = 30_000L
        private val PACKAGE_PATTERN = Regex("[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+")
        private val SESSION_PATTERN = Regex("[a-f0-9]{32}")
        private val SHA256_PATTERN = Regex("[a-f0-9]{64}")
        private val APK_NAME_PATTERN = Regex("[A-Za-z0-9._-]{1,128}\\.apk", RegexOption.IGNORE_CASE)

        fun fromJson(raw: String): Result<ApkSourceDescriptor> = runCatching {
            val root = JSONObject(raw)
            require(root.getInt("schema") == SCHEMA_VERSION) { "不支持的 APK 来源协议版本。" }
            val signersJson = root.getJSONArray("signingSha256")
            val signers = buildList {
                for (i in 0 until signersJson.length()) add(signersJson.getString(i))
            }
            val filesJson = root.getJSONArray("files")
            val files = buildList {
                for (i in 0 until filesJson.length()) {
                    val item = filesJson.getJSONObject(i)
                    add(
                        ApkSourceFile(
                            index = item.getInt("index"),
                            displayName = item.getString("displayName"),
                            sizeBytes = item.getLong("sizeBytes"),
                            sha256 = item.getString("sha256"),
                            uri = Uri.parse(item.getString("uri"))
                        )
                    )
                }
            }.sortedBy { it.index }
            ApkSourceDescriptor(
                sessionId = root.getString("sessionId"),
                packageName = root.getString("packageName"),
                label = root.optString("label", root.getString("packageName")),
                versionCode = root.getLong("versionCode"),
                versionName = root.optString("versionName", ""),
                signingSha256 = signers.sorted(),
                expiresAt = root.getLong("expiresAt"),
                files = files
            ).also { descriptor ->
                descriptor.validationError()?.let { error -> throw IllegalArgumentException(error) }
            }
        }

        fun sha256Text(value: String): String {
            return MessageDigest.getInstance("SHA-256")
                .digest(value.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        }
    }
}
