package com.xiaxue.privacyspace

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal object InstallRequestStore {
    private const val PREF = "xiaxue_install_requests"
    private const val KEY_PREFIX = "request_"
    private const val MAX_RECORDS = 12
    private const val RETENTION_MS = 24 * 60 * 60 * 1000L

    const val STATE_PREPARING = "preparing"
    const val STATE_WRITING = "writing"
    const val STATE_COMMITTED = "committed"
    const val STATE_AWAITING_USER = "awaiting_user"
    const val STATE_SUCCESS = "success"
    const val STATE_FAILURE = "failure"

    data class Record(
        val requestId: String,
        val installerSessionId: Int,
        val sourceSessionId: String,
        val packageName: String,
        val label: String,
        val versionCode: Long,
        val versionName: String,
        val signingSha256: List<String>,
        val fileCount: Int,
        val totalBytes: Long,
        val createdAt: Long,
        val updatedAt: Long,
        val state: String,
        val status: Int?,
        val legacyStatus: Int?,
        val message: String?
    ) {
        val isFinal: Boolean get() = state == STATE_SUCCESS || state == STATE_FAILURE
    }

    fun create(context: Context, record: Record): Boolean {
        purge(context)
        val saved = preferences(context).edit()
            .putString(KEY_PREFIX + record.requestId, toJson(record))
            .commit()
        trim(context)
        return saved
    }

    fun read(context: Context, requestId: String): Record? {
        purge(context)
        val raw = preferences(context).getString(KEY_PREFIX + requestId, null) ?: return null
        return parse(raw)?.takeIf { it.requestId == requestId }
    }

    fun updateState(
        context: Context,
        requestId: String,
        state: String,
        status: Int? = null,
        legacyStatus: Int? = null,
        message: String? = null
    ): Record? {
        val current = read(context, requestId) ?: return null
        val updated = current.copy(
            updatedAt = System.currentTimeMillis(),
            state = state,
            status = status ?: current.status,
            legacyStatus = legacyStatus ?: current.legacyStatus,
            message = message ?: current.message
        )
        return updated.takeIf {
            preferences(context).edit().putString(KEY_PREFIX + requestId, toJson(updated)).commit()
        }
    }

    fun pending(context: Context): List<Record> {
        purge(context)
        return preferences(context).all.values.mapNotNull { value ->
            (value as? String)?.let(::parse)
        }.filterNot { it.isFinal }.sortedBy { it.createdAt }
    }

    private fun preferences(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun toJson(record: Record): String {
        val signers = JSONArray().apply { record.signingSha256.sorted().forEach(::put) }
        return JSONObject()
            .put("requestId", record.requestId)
            .put("installerSessionId", record.installerSessionId)
            .put("sourceSessionId", record.sourceSessionId)
            .put("packageName", record.packageName)
            .put("label", record.label)
            .put("versionCode", record.versionCode)
            .put("versionName", record.versionName)
            .put("signingSha256", signers)
            .put("fileCount", record.fileCount)
            .put("totalBytes", record.totalBytes)
            .put("createdAt", record.createdAt)
            .put("updatedAt", record.updatedAt)
            .put("state", record.state)
            .put("status", record.status ?: JSONObject.NULL)
            .put("legacyStatus", record.legacyStatus ?: JSONObject.NULL)
            .put("message", record.message ?: JSONObject.NULL)
            .toString()
    }

    private fun parse(raw: String): Record? = runCatching {
        val root = JSONObject(raw)
        val signerArray = root.getJSONArray("signingSha256")
        val signers = buildList {
            for (index in 0 until signerArray.length()) add(signerArray.getString(index))
        }.sorted()
        Record(
            requestId = root.getString("requestId"),
            installerSessionId = root.getInt("installerSessionId"),
            sourceSessionId = root.getString("sourceSessionId"),
            packageName = root.getString("packageName"),
            label = root.optString("label", root.getString("packageName")),
            versionCode = root.getLong("versionCode"),
            versionName = root.optString("versionName", ""),
            signingSha256 = signers,
            fileCount = root.getInt("fileCount"),
            totalBytes = root.getLong("totalBytes"),
            createdAt = root.getLong("createdAt"),
            updatedAt = root.getLong("updatedAt"),
            state = root.getString("state"),
            status = root.optIntOrNull("status"),
            legacyStatus = root.optIntOrNull("legacyStatus"),
            message = root.optStringOrNull("message")
        )
    }.getOrNull()

    private fun JSONObject.optIntOrNull(name: String): Int? {
        return if (!has(name) || isNull(name)) null else getInt(name)
    }

    private fun JSONObject.optStringOrNull(name: String): String? {
        return if (!has(name) || isNull(name)) null else getString(name)
    }

    private fun purge(context: Context) {
        val cutoff = System.currentTimeMillis() - RETENTION_MS
        val prefs = preferences(context)
        val expired = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            val record = (value as? String)?.let(::parse)
            key.takeIf { record == null || record.updatedAt < cutoff }
        }
        if (expired.isNotEmpty()) {
            val editor = prefs.edit()
            expired.forEach(editor::remove)
            editor.apply()
        }
    }

    private fun trim(context: Context) {
        val prefs = preferences(context)
        val records = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            key to ((value as? String)?.let(::parse)?.updatedAt ?: Long.MIN_VALUE)
        }.sortedByDescending { it.second }
        if (records.size <= MAX_RECORDS) return
        val editor = prefs.edit()
        records.drop(MAX_RECORDS).forEach { editor.remove(it.first) }
        editor.apply()
    }
}
