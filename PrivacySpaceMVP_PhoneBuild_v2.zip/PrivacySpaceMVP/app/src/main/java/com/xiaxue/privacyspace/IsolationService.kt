package com.xiaxue.privacyspace

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder

/**
 * 第一阶段先放置与 Shelter 类似的可绑定服务入口。
 * 现在只做安全占位：不执行克隆/冻结逻辑，避免创建阶段因为缺少服务组件而中断。
 * 第二阶段再把跨空间 Binder 指令接入这里。
 */
class IsolationService : Service() {
    private val binder = LocalBinder()

    override fun onCreate() {
        super.onCreate()
        ProvisioningDiagnostics.record(this, "IsolationService 已创建")
    }

    override fun onBind(intent: Intent?): IBinder {
        ProvisioningDiagnostics.record(this, "IsolationService onBind：${intent?.action ?: "no_action"}")
        return binder
    }

    class LocalBinder : Binder()
}
