package com.xiaxue.privacyspace

import android.content.Context
import android.content.pm.PackageManager
import java.security.MessageDigest

internal object InstalledPackageVerifier {
    data class Summary(
        val packageName: String,
        val versionCode: Long,
        val versionName: String,
        val canLaunch: Boolean
    )

    fun verify(context: Context, request: InstallRequestStore.Record): Result<Summary> = runCatching {
        val flags = PackageManager.GET_SIGNING_CERTIFICATES or
            PackageManager.MATCH_DISABLED_COMPONENTS or
            PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        @Suppress("DEPRECATION")
        val info = context.packageManager.getPackageInfo(request.packageName, flags)
        require(info.longVersionCode == request.versionCode) {
            "安装后的版本号不一致：期望 ${request.versionCode}，实际 ${info.longVersionCode}。"
        }
        val signing = info.signingInfo ?: throw IllegalStateException("安装后无法读取应用签名。")
        val signatures = if (signing.hasMultipleSigners()) {
            signing.apkContentsSigners
        } else {
            signing.signingCertificateHistory ?: signing.apkContentsSigners
        }
        val actualSigners = signatures.map { signature ->
            MessageDigest.getInstance("SHA-256")
                .digest(signature.toByteArray())
                .joinToString("") { "%02x".format(it) }
        }.distinct().sorted()
        require(actualSigners == request.signingSha256.sorted()) { "安装后的签名证书与主空间来源不一致。" }
        Summary(
            packageName = request.packageName,
            versionCode = info.longVersionCode,
            versionName = info.versionName.orEmpty(),
            canLaunch = context.packageManager.getLaunchIntentForPackage(request.packageName) != null
        )
    }
}
