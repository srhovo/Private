package com.xiaxue.privacyspace

import android.content.Context
import java.util.UUID

internal object ProfileStateStore {
    private const val PREF = "xiaxue_remote_profile_state"
    private const val KEY_SNAPSHOT = "snapshot"
    private const val KEY_RECEIVED_AT = "received_at"
    private const val KEY_PENDING_PREFIX = "pending_"
    private const val PENDING_TTL_MS = 3 * 60 * 1000L
    private const val SNAPSHOT_FRESH_MS = 30 * 1000L

    fun beginRequest(context: Context, expectedProfileOwner: Boolean): String {
        purgePending(context)
        val requestId = UUID.randomUUID().toString()
        val saved = preferences(context).edit()
            .putString(KEY_PENDING_PREFIX + requestId, "${System.currentTimeMillis()}|$expectedProfileOwner")
            .commit()
        check(saved) { "无法保存跨资料状态请求。" }
        return requestId
    }

    fun cancelRequest(context: Context, requestId: String) {
        preferences(context).edit().remove(KEY_PENDING_PREFIX + requestId).apply()
    }

    fun accept(context: Context, snapshot: ProfileStateSnapshot): Boolean {
        purgePending(context)
        val prefs = preferences(context)
        val pendingRaw = prefs.getString(KEY_PENDING_PREFIX + snapshot.requestId, null) ?: return false
        val pendingParts = pendingRaw.split('|', limit = 2)
        val pendingAt = pendingParts.getOrNull(0)?.toLongOrNull() ?: return false
        val expectedProfileOwner = pendingParts.getOrNull(1)?.toBooleanStrictOrNull() ?: return false
        if (System.currentTimeMillis() - pendingAt > PENDING_TTL_MS || snapshot.profileOwner != expectedProfileOwner) return false

        val merged = if (snapshot.fullInventory) {
            snapshot
        } else {
            val previous = read(context)
            if (previous == null || previous.profileOwner != snapshot.profileOwner) {
                snapshot
            } else {
                val updates = snapshot.packages.associateBy { it.packageName }
                val retained = previous.packages.filterNot { it.packageName in updates }
                snapshot.copy(
                    fullInventory = previous.fullInventory,
                    packages = (retained + snapshot.packages)
                        .distinctBy { it.packageName }
                        .take(ProfileStateSnapshot.MAX_PACKAGES)
                )
            }
        }
        val raw = merged.toJson()
        return prefs.edit()
            .putString(KEY_SNAPSHOT, raw)
            .putLong(KEY_RECEIVED_AT, System.currentTimeMillis())
            .remove(KEY_PENDING_PREFIX + snapshot.requestId)
            .commit()
    }

    fun read(context: Context): ProfileStateSnapshot? {
        val raw = preferences(context).getString(KEY_SNAPSHOT, null) ?: return null
        return runCatching { ProfileStateSnapshot.fromJson(raw) }.getOrNull()
    }

    fun receivedAt(context: Context): Long = preferences(context).getLong(KEY_RECEIVED_AT, 0L)

    fun isFresh(context: Context): Boolean {
        val receivedAt = receivedAt(context)
        return receivedAt > 0L && System.currentTimeMillis() - receivedAt <= SNAPSHOT_FRESH_MS
    }

    fun clear(context: Context) {
        preferences(context).edit().clear().apply()
    }

    private fun preferences(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun purgePending(context: Context) {
        val now = System.currentTimeMillis()
        val prefs = preferences(context)
        val expired = prefs.all.keys.filter { key ->
            if (!key.startsWith(KEY_PENDING_PREFIX)) return@filter false
            val timestamp = prefs.getString(key, null)?.substringBefore('|')?.toLongOrNull() ?: 0L
            now - timestamp > PENDING_TTL_MS
        }
        if (expired.isNotEmpty()) {
            val editor = prefs.edit()
            expired.forEach(editor::remove)
            editor.apply()
        }
    }
}
