package com.xiaxue.privacyspace

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.security.MessageDigest

internal object ApkSourceVerifier {
    data class VerificationSummary(
        val descriptor: ApkSourceDescriptor,
        val verifiedBytes: Long
    )

    fun descriptorFromIntent(intent: Intent): Result<ApkSourceDescriptor> = runCatching {
        val raw = intent.getStringExtra(ProvisioningContract.EXTRA_APK_SOURCE_MANIFEST)
            ?: throw IllegalArgumentException("请求缺少 APK 来源清单。")
        val expectedDigest = intent.getStringExtra(ProvisioningContract.EXTRA_APK_SOURCE_MANIFEST_SHA256)
            ?.trim()
            .orEmpty()
        require(expectedDigest == ApkSourceDescriptor.sha256Text(raw)) { "APK 来源清单摘要不匹配。" }
        val descriptor = ApkSourceDescriptor.fromJson(raw).getOrThrow()
        require(descriptor.packageName == intent.getStringExtra(ProvisioningContract.EXTRA_PACKAGE_NAME)) {
            "APK 来源包名与请求不一致。"
        }
        require(descriptor.sessionId == intent.getStringExtra(ProvisioningContract.EXTRA_APK_SOURCE_SESSION_ID)) {
            "APK 来源会话与请求不一致。"
        }
        val clipUris = clipUris(intent)
        require(clipUris.size == descriptor.files.size) { "APK 来源 URI 授权数量不完整。" }
        descriptor.files.forEachIndexed { index, file ->
            require(sameTransferredUri(file.uri, clipUris[index])) {
                "APK 来源 URI 与签名清单不一致。"
            }
        }
        descriptor.copy(
            files = descriptor.files.mapIndexed { index, file -> file.copy(uri = clipUris[index]) }
        )
    }

    fun verifyReadable(context: Context, intent: Intent): Result<VerificationSummary> = runCatching {
        val descriptor = descriptorFromIntent(intent).getOrThrow()
        var total = 0L
        descriptor.files.forEach { source ->
            val digest = MessageDigest.getInstance("SHA-256")
            var count = 0L
            context.contentResolver.openInputStream(source.uri).use { input ->
                requireNotNull(input) { "无法打开 ${source.displayName}。" }
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 4)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read > 0) {
                        digest.update(buffer, 0, read)
                        count += read
                    }
                }
            }
            require(count == source.sizeBytes) { "${source.displayName} 大小校验失败。" }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            require(actual == source.sha256) { "${source.displayName} 哈希校验失败。" }
            total += count
        }
        require(total == descriptor.totalBytes) { "APK 来源总大小校验失败。" }
        VerificationSummary(descriptor, total)
    }


    private fun sameTransferredUri(expected: Uri, actual: Uri): Boolean {
        fun normalizedAuthority(uri: Uri): String = uri.authority.orEmpty().substringAfter('@')
        return expected.scheme == actual.scheme &&
            normalizedAuthority(expected) == normalizedAuthority(actual) &&
            expected.pathSegments == actual.pathSegments
    }

    private fun clipUris(intent: Intent): List<Uri> {
        val data = intent.clipData ?: return emptyList()
        return buildList {
            for (i in 0 until data.itemCount) data.getItemAt(i).uri?.let(::add)
        }
    }
}
