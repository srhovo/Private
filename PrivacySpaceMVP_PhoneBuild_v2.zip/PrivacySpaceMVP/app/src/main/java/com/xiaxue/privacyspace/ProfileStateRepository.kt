package com.xiaxue.privacyspace

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

internal class ProfileStateRepository(private val context: Context) {
    private val manager = WorkProfileManager(context)
    private val packageManager = context.packageManager
    private val dpm = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    fun capture(requestId: String, packageNames: Set<String>? = null): ProfileStateSnapshot {
        val isOwner = manager.isProfileOwner()
        val selected = packageNames?.map(String::trim)?.filter(String::isNotBlank)?.toSet()
        val packages = if (selected == null) {
            loadAll(isOwner)
        } else {
            selected.take(ProfileStateSnapshot.MAX_PACKAGES).map { packageName ->
                readOne(packageName, isOwner) ?: ProfilePackageState(
                    packageName = packageName,
                    label = packageName,
                    installed = false,
                    hidden = false,
                    launchable = false,
                    system = false,
                    versionName = "",
                    versionCode = 0L
                )
            }
        }
        return ProfileStateSnapshot(
            requestId = requestId,
            generatedAt = System.currentTimeMillis(),
            profileOwner = isOwner,
            profileLabel = if (isOwner) "隔离空间" else "主空间",
            fullInventory = selected == null,
            packages = packages.sortedWith(compareBy<ProfilePackageState> { it.label.lowercase() }.thenBy { it.packageName }),
            diagnostics = ProvisioningDiagnostics.history(context)
        ).also { snapshot ->
            snapshot.validationError()?.let { throw IllegalStateException(it) }
        }
    }

    private fun loadAll(isOwner: Boolean): List<ProfilePackageState> {
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS or PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        @Suppress("DEPRECATION")
        return packageManager.getInstalledApplications(flags)
            .asSequence()
            .filter { (it.flags and ApplicationInfo.FLAG_INSTALLED) != 0 }
            .filterNot { it.packageName == context.packageName }
            .distinctBy { it.packageName }
            .take(ProfileStateSnapshot.MAX_PACKAGES)
            .mapNotNull { readOne(it.packageName, isOwner, it) }
            .toList()
    }

    private fun readOne(
        packageName: String,
        isOwner: Boolean,
        knownInfo: ApplicationInfo? = null
    ): ProfilePackageState? {
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS or PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        val appInfo = knownInfo ?: runCatching {
            @Suppress("DEPRECATION")
            packageManager.getApplicationInfo(packageName, flags)
        }.getOrNull() ?: return null
        if ((appInfo.flags and ApplicationInfo.FLAG_INSTALLED) == 0) return null
        val packageInfo = runCatching {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, flags)
        }.getOrNull() ?: return null
        val hidden = if (isOwner) {
            runCatching { dpm?.isApplicationHidden(admin, packageName) == true }.getOrDefault(false)
        } else false
        return ProfilePackageState(
            packageName = packageName,
            label = runCatching { appInfo.loadLabel(packageManager).toString() }
                .getOrDefault(packageName)
                .ifBlank { packageName }
                .take(160),
            installed = true,
            hidden = hidden,
            launchable = !hidden && packageManager.getLaunchIntentForPackage(packageName) != null,
            system = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
            versionName = packageInfo.versionName.orEmpty().take(160),
            versionCode = packageInfo.longVersionCode
        )
    }
}
