package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class ParentRequestActivity : Activity() {
    private lateinit var manager: WorkProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = WorkProfileManager(this)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(source: Intent) {
        if (manager.isProfileOwner()) {
            ProfileSetup.configureCrossProfileReceiversForCurrentProfile(this)
            ProvisioningDiagnostics.record(this, "主空间命令入口在工作资料中被触发：${source.action}")
            finishQuietly()
            return
        }
        val verification = CrossProfileAuth.verify(this, source)
        if (!verification.accepted) {
            ProvisioningDiagnostics.record(this, "拒绝工作资料到主空间请求：${verification.reason}")
            finishQuietly()
            return
        }
        val requestId = source.getStringExtra(ProvisioningContract.EXTRA_STATE_REQUEST_ID)?.trim().orEmpty()
        when (source.action) {
            ProvisioningContract.ACTION_QUERY_PARENT_PROFILE -> {
                if (requestId.isBlank()) {
                    finishQuietly()
                } else {
                    sendSnapshot(requestId, null)
                }
            }
            ProvisioningContract.ACTION_LAUNCH_PARENT_PACKAGE -> {
                val packageName = source.getStringExtra(ProvisioningContract.EXTRA_PACKAGE_NAME)?.trim().orEmpty()
                if (packageName.isBlank()) {
                    finishQuietly()
                    return
                }
                manager.prepareLaunchIntentInThisProfile(packageName).fold(
                    onSuccess = { launchIntent ->
                        if (requestId.isBlank()) {
                            startActivity(launchIntent)
                            finishQuietly()
                        } else {
                            sendSnapshot(requestId, setOf(packageName)) {
                                startActivity(launchIntent)
                                finishQuietly()
                            }
                        }
                    },
                    onFailure = { error ->
                        Toast.makeText(this, error.message ?: "无法启动主空间应用", Toast.LENGTH_LONG).show()
                        if (requestId.isBlank()) finishQuietly()
                        else sendSnapshot(requestId, setOf(packageName))
                    }
                )
            }
            else -> {
                ProvisioningDiagnostics.record(this, "主空间入口拒绝未知动作：${source.action}")
                finishQuietly()
            }
        }
    }

    private fun sendSnapshot(
        requestId: String,
        packageNames: Set<String>?,
        afterSend: (() -> Unit)? = null
    ) {
        Thread {
            val result = runCatching { ProfileStateRepository(this).capture(requestId, packageNames) }
                .fold(
                    onSuccess = { manager.sendProfileStateResult(this, it) },
                    onFailure = { Result.failure(it) }
                )
            runOnUiThread {
                result.onFailure { ProvisioningDiagnostics.record(this, "主空间状态回传失败", it) }
                if (afterSend == null) finishQuietly() else afterSend()
            }
        }.start()
    }

    private fun finishQuietly() {
        finish()
        overridePendingTransition(0, 0)
    }
}
