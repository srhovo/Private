package com.xiaxue.privacyspace

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings

internal object ProtectedPackages {
    private val permissionControllerPrivileges = setOf(
        "android.permission.GRANT_RUNTIME_PERMISSIONS",
        "android.permission.REVOKE_RUNTIME_PERMISSIONS"
    )

    private val knownCriticalPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.managedprovisioning",
        "com.google.android.managedprovisioning",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.documentsui"
    )

    fun reason(context: Context, packageName: String): String? {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return "包名不能为空"
        if (pkg == context.packageName) return "不能操作隔离管理器自身"
        if (pkg in knownCriticalPackages) return "这是工作资料运行所需的核心系统组件"
        if (pkg.startsWith("com.android.systemui")) return "这是系统界面组件"

        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        if (runCatching { dpm?.isProfileOwnerApp(pkg) == true }.getOrDefault(false)) {
            return "这是当前工作资料管理器"
        }
        if (runCatching { dpm?.isDeviceOwnerApp(pkg) == true }.getOrDefault(false)) {
            return "这是设备管理器"
        }

        if (pkg in resolveHomePackages(context)) return "这是当前桌面/启动器组件"
        if (pkg in resolveSettingsPackages(context)) return "这是系统设置组件"
        if (pkg in resolveInstallerPackages(context)) return "这是系统安装器组件"
        if (hasPermissionControllerPrivileges(context.packageManager, pkg)) {
            return "这是系统权限控制器或运行时权限管理组件"
        }

        val appInfo = runCatching { context.packageManager.getApplicationInfo(pkg, 0) }.getOrNull()
        if (appInfo != null && (appInfo.flags and ApplicationInfo.FLAG_PERSISTENT) != 0) {
            return "这是系统常驻核心组件"
        }
        return null
    }

    fun canManage(context: Context, packageName: String): Boolean = reason(context, packageName) == null

    private fun hasPermissionControllerPrivileges(packageManager: PackageManager, packageName: String): Boolean {
        return permissionControllerPrivileges.any { permission ->
            runCatching {
                packageManager.checkPermission(permission, packageName) == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
        }
    }

    private fun resolveHomePackages(context: Context): Set<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .map { it.activityInfo.packageName }
            .toSet()
    }

    private fun resolveSettingsPackages(context: Context): Set<String> {
        return listOf(Settings.ACTION_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS)
            .mapNotNull { action ->
                context.packageManager.resolveActivity(Intent(action), PackageManager.MATCH_DEFAULT_ONLY)
                    ?.activityInfo
                    ?.packageName
            }
            .toSet()
    }

    private fun resolveInstallerPackages(context: Context): Set<String> {
        val packages = mutableSetOf<String>()
        listOf(Intent.ACTION_INSTALL_PACKAGE, Intent.ACTION_UNINSTALL_PACKAGE).forEach { action ->
            context.packageManager.queryIntentActivities(Intent(action), PackageManager.MATCH_DEFAULT_ONLY)
                .mapTo(packages) { it.activityInfo.packageName }
        }
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)
        packages += admin.packageName
        return packages
    }
}
