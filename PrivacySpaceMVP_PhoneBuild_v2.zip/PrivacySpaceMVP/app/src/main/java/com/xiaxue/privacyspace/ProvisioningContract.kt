package com.xiaxue.privacyspace

internal object ProvisioningContract {
    const val ACTION_FINALIZE_PROVISION = "com.xiaxue.privacyspace.action.FINALIZE_PROVISION"
    const val ACTION_START_SERVICE = "com.xiaxue.privacyspace.action.START_SERVICE"
    const val EXTRA_OPEN_MAIN = "com.xiaxue.privacyspace.extra.OPEN_MAIN"
}
