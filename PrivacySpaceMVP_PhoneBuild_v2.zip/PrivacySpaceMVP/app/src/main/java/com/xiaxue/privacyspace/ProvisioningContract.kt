package com.xiaxue.privacyspace

internal object ProvisioningContract {
    const val ACTION_FINALIZE_PROVISION = "com.xiaxue.privacyspace.action.FINALIZE_PROVISION"
    const val ACTION_CLONE_PACKAGE = "com.xiaxue.privacyspace.action.CLONE_PACKAGE"
    const val ACTION_LAUNCH_PACKAGE = "com.xiaxue.privacyspace.action.LAUNCH_PACKAGE"
    const val ACTION_LAUNCH_PARENT_PACKAGE = "com.xiaxue.privacyspace.action.LAUNCH_PARENT_PACKAGE"
    const val ACTION_SET_PACKAGE_HIDDEN = "com.xiaxue.privacyspace.action.SET_PACKAGE_HIDDEN"
    const val ACTION_UNINSTALL_PACKAGE = "com.xiaxue.privacyspace.action.UNINSTALL_PACKAGE"
    const val ACTION_QUERY_WORK_PROFILE = "com.xiaxue.privacyspace.action.QUERY_WORK_PROFILE"
    const val ACTION_QUERY_PARENT_PROFILE = "com.xiaxue.privacyspace.action.QUERY_PARENT_PROFILE"
    const val ACTION_PROFILE_STATE_RESULT = "com.xiaxue.privacyspace.action.PROFILE_STATE_RESULT"

    const val EXTRA_OPEN_MAIN = "com.xiaxue.privacyspace.extra.OPEN_MAIN"
    const val EXTRA_PACKAGE_NAME = "com.xiaxue.privacyspace.extra.PACKAGE_NAME"
    const val EXTRA_APP_LABEL = "com.xiaxue.privacyspace.extra.APP_LABEL"
    const val EXTRA_APK_SOURCE_SESSION_ID = "com.xiaxue.privacyspace.extra.APK_SOURCE_SESSION_ID"
    const val EXTRA_APK_SOURCE_MANIFEST = "com.xiaxue.privacyspace.extra.APK_SOURCE_MANIFEST"
    const val EXTRA_APK_SOURCE_MANIFEST_SHA256 = "com.xiaxue.privacyspace.extra.APK_SOURCE_MANIFEST_SHA256"
    const val EXTRA_STATE_REQUEST_ID = "com.xiaxue.privacyspace.extra.STATE_REQUEST_ID"
    const val EXTRA_REQUESTED_HIDDEN = "com.xiaxue.privacyspace.extra.REQUESTED_HIDDEN"
    const val EXTRA_PROFILE_STATE_JSON = "com.xiaxue.privacyspace.extra.PROFILE_STATE_JSON"
    const val EXTRA_PROFILE_STATE_SHA256 = "com.xiaxue.privacyspace.extra.PROFILE_STATE_SHA256"
}
