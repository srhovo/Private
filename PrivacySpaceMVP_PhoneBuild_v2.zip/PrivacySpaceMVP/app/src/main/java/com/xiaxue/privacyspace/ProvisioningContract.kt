package com.xiaxue.privacyspace

internal object ProvisioningContract {
    const val ACTION_FINALIZE_PROVISION = "com.xiaxue.privacyspace.action.FINALIZE_PROVISION"
    const val ACTION_START_SERVICE = "com.xiaxue.privacyspace.action.START_SERVICE"
    const val ACTION_CLONE_PACKAGE = "com.xiaxue.privacyspace.action.CLONE_PACKAGE"
    const val ACTION_LAUNCH_PACKAGE = "com.xiaxue.privacyspace.action.LAUNCH_PACKAGE"

    const val EXTRA_OPEN_MAIN = "com.xiaxue.privacyspace.extra.OPEN_MAIN"
    const val EXTRA_PACKAGE_NAME = "com.xiaxue.privacyspace.extra.PACKAGE_NAME"
    const val EXTRA_APP_LABEL = "com.xiaxue.privacyspace.extra.APP_LABEL"
}
