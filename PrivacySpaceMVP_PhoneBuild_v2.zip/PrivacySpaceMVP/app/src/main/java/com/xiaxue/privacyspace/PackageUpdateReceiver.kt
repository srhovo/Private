package com.xiaxue.privacyspace

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PackageUpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_BOOT_COMPLETED -> {
                ProfileSetup.configureCrossProfileReceiversForCurrentProfile(context)
                if (WorkProfileManager(context).isProfileOwner()) {
                    ProfileSetup.complete(context, force = intent.action == Intent.ACTION_MY_PACKAGE_REPLACED)
                    val pending = goAsync()
                    Thread {
                        try {
                            PackageInstallCoordinator.reconcileStale(context.applicationContext)
                        } finally {
                            pending.finish()
                        }
                    }.start()
                }
            }

            Intent.ACTION_PACKAGE_ADDED, Intent.ACTION_PACKAGE_CHANGED -> {
                if (!WorkProfileManager(context).isProfileOwner()) return
                val changedPackage = intent.data?.schemeSpecificPart.orEmpty()
                if (changedPackage.isBlank()) return
                val pending = goAsync()
                Thread {
                    try {
                        PackageInstallCoordinator.reconcilePackage(context.applicationContext, changedPackage)
                    } finally {
                        pending.finish()
                    }
                }.start()
            }
        }
    }
}
