package com.xiaxue.privacyspace

import android.content.Context
import org.json.JSONObject
import java.security.SecureRandom
import java.util.UUID

internal object LifecycleRequestStore {
    private const val PREF = "xiaxue_lifecycle_requests"
    private const val KEY_PREFIX = "request_"
    private const val RETENTION_MS = 24 * 60 * 60 * 1000L
    private const val MAX_RECORDS = 16

    data class Record(
        val operationId: String,
        val callbackToken: String,
        val remoteStateRequestId: String?,
        val packageName: String,
        val label: String,
        val createdAt: Long,
        val updatedAt: Long,
        val state: String
    )

    fun create(
        context: Context,
        remoteStateRequestId: String?,
        packageName: String,
        label: String
    ): Record {
        purge(context)
        val tokenBytes = ByteArray(24).also { SecureRandom().nextBytes(it) }
        val record = Record(
            operationId = UUID.randomUUID().toString(),
            callbackToken = tokenBytes.joinToString("") { "%02x".format(it) },
            remoteStateRequestId = remoteStateRequestId,
            packageName = packageName,
            label = label,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            state = "submitted"
        )
        check(preferences(context).edit().putString(KEY_PREFIX + record.operationId, toJson(record)).commit()) {
            "无法保存卸载请求。"
        }
        trim(context)
        return record
    }

    fun read(context: Context, operationId: String): Record? {
        purge(context)
        val raw = preferences(context).getString(KEY_PREFIX + operationId, null) ?: return null
        return parse(raw)?.takeIf { it.operationId == operationId }
    }

    fun updateState(context: Context, operationId: String, state: String): Record? {
        val current = read(context, operationId) ?: return null
        val updated = current.copy(updatedAt = System.currentTimeMillis(), state = state)
        return updated.takeIf {
            preferences(context).edit().putString(KEY_PREFIX + operationId, toJson(updated)).commit()
        }
    }

    fun remove(context: Context, operationId: String) {
        preferences(context).edit().remove(KEY_PREFIX + operationId).apply()
    }

    private fun preferences(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun toJson(record: Record): String = JSONObject()
        .put("operationId", record.operationId)
        .put("callbackToken", record.callbackToken)
        .put("remoteStateRequestId", record.remoteStateRequestId ?: JSONObject.NULL)
        .put("packageName", record.packageName)
        .put("label", record.label)
        .put("createdAt", record.createdAt)
        .put("updatedAt", record.updatedAt)
        .put("state", record.state)
        .toString()

    private fun parse(raw: String): Record? = runCatching {
        val root = JSONObject(raw)
        Record(
            operationId = root.getString("operationId"),
            callbackToken = root.getString("callbackToken"),
            remoteStateRequestId = if (root.isNull("remoteStateRequestId")) null else root.getString("remoteStateRequestId"),
            packageName = root.getString("packageName"),
            label = root.optString("label", root.getString("packageName")),
            createdAt = root.getLong("createdAt"),
            updatedAt = root.getLong("updatedAt"),
            state = root.getString("state")
        )
    }.getOrNull()

    private fun purge(context: Context) {
        val cutoff = System.currentTimeMillis() - RETENTION_MS
        val prefs = preferences(context)
        val expired = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            val record = (value as? String)?.let(::parse)
            key.takeIf { record == null || record.updatedAt < cutoff }
        }
        if (expired.isNotEmpty()) {
            val editor = prefs.edit()
            expired.forEach(editor::remove)
            editor.apply()
        }
    }

    private fun trim(context: Context) {
        val prefs = preferences(context)
        val records = prefs.all.mapNotNull { (key, value) ->
            if (!key.startsWith(KEY_PREFIX)) return@mapNotNull null
            key to ((value as? String)?.let(::parse)?.updatedAt ?: Long.MIN_VALUE)
        }.sortedByDescending { it.second }
        if (records.size <= MAX_RECORDS) return
        val editor = prefs.edit()
        records.drop(MAX_RECORDS).forEach { editor.remove(it.first) }
        editor.apply()
    }
}
