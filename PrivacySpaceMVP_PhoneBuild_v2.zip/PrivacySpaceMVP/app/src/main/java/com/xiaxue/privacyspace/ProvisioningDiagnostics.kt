package com.xiaxue.privacyspace

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.UserManager
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object ProvisioningDiagnostics {
    private const val TAG = "XiaXueProvisioning"
    private const val PREF = "xiaxue_provisioning_diagnostics"
    private const val KEY_LAST_EVENT = "last_event"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_LAST_TIME = "last_time"
    private const val KEY_HISTORY = "event_history"
    private const val HISTORY_SEPARATOR = "\u0001"
    private const val MAX_HISTORY = 12

    fun record(context: Context, event: String, error: Throwable? = null) {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(Date())
        val errorText = error?.let { it.message ?: it.javaClass.simpleName }.orEmpty()
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val line = buildString {
            append(now).append(" · ").append(event)
            if (errorText.isNotBlank()) append(" · ").append(errorText)
        }
        val history = prefs.getString(KEY_HISTORY, "").orEmpty()
            .split(HISTORY_SEPARATOR)
            .filter { it.isNotBlank() }
            .plus(line)
            .takeLast(MAX_HISTORY)
            .joinToString(HISTORY_SEPARATOR)
        prefs.edit()
            .putString(KEY_LAST_EVENT, event)
            .putString(KEY_LAST_ERROR, errorText)
            .putString(KEY_LAST_TIME, now)
            .putString(KEY_HISTORY, history)
            .commit()
        if (error == null) {
            Log.i(TAG, event)
        } else {
            Log.w(TAG, "$event: $errorText", error)
        }
    }

    fun history(context: Context): List<String> {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_HISTORY, "").orEmpty()
            .split(HISTORY_SEPARATOR)
            .filter { it.isNotBlank() }
    }

    fun lastEvent(context: Context): String {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val event = sp.getString(KEY_LAST_EVENT, "暂无创建记录").orEmpty()
        val error = sp.getString(KEY_LAST_ERROR, "").orEmpty()
        val time = sp.getString(KEY_LAST_TIME, "").orEmpty()
        return buildString {
            if (time.isNotBlank()) append(time).append(" · ")
            append(event)
            if (error.isNotBlank()) append(" · ").append(error)
        }
    }

    fun snapshot(context: Context, manager: WorkProfileManager): String {
        val compat = manager.compatibility()
        val userProfiles = runCatching {
            context.getSystemService(UserManager::class.java)?.userProfiles?.size ?: -1
        }.getOrDefault(-1)
        return buildString {
            appendLine("下雪应用隔离 · 创建诊断")
            appendLine("包名：${context.packageName}")
            appendLine("版本：${appVersion(context)}")
            appendLine("设备：${compat.manufacturer} ${compat.model}")
            appendLine("Android：${compat.sdk}")
            appendLine("支持工作资料：${compat.supportsManagedUsers}")
            appendLine("系统允许创建：${compat.provisioningAllowed}")
            appendLine("Profile Owner：${compat.isProfileOwner}")
            appendLine("Device Owner：${compat.isDeviceOwner}")
            appendLine("关联用户数：$userProfiles")
            appendLine("安全配对：${if (CrossProfileAuth.hasKey(context)) "已建立" else "未建立"}")
            appendLine()
            appendLine("最近事件记录（从旧到新）：")
            val events = history(context)
            if (events.isEmpty()) {
                appendLine("暂无记录")
            } else {
                events.forEach { appendLine(it) }
            }
            ProfileStateStore.read(context)?.let { remote ->
                appendLine()
                appendLine("${remote.profileLabel}最近事件（远端同步）：")
                if (remote.diagnostics.isEmpty()) {
                    appendLine("暂无远端记录")
                } else {
                    remote.diagnostics.forEach { appendLine(it) }
                }
            }
            compat.likelyBlockReason()?.let {
                appendLine()
                appendLine("可能原因与建议：")
                appendLine(it)
            }
        }.trim()
    }

    private fun appVersion(context: Context): String {
        return runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            @Suppress("DEPRECATION")
            val legacyCode = info.versionCode.toString()
            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode.toString() else legacyCode
            "${info.versionName ?: "unknown"} ($code)"
        }.getOrDefault("unknown")
    }

    fun copySnapshot(context: Context, manager: WorkProfileManager): Boolean {
        return runCatching {
            val clipboard = context.getSystemService(ClipboardManager::class.java)
                ?: throw IllegalStateException("系统剪贴板服务不可用。")
            clipboard.setPrimaryClip(ClipData.newPlainText("下雪应用隔离诊断", snapshot(context, manager)))
            true
        }.getOrDefault(false)
    }
}
