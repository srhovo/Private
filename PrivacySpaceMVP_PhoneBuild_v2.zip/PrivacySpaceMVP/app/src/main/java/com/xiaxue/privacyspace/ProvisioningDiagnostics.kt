package com.xiaxue.privacyspace

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.UserManager
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object ProvisioningDiagnostics {
    private const val TAG = "XiaXueProvisioning"
    private const val PREF = "xiaxue_provisioning_diagnostics"
    private const val KEY_LAST_EVENT = "last_event"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_LAST_TIME = "last_time"

    fun record(context: Context, event: String, error: Throwable? = null) {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(Date())
        val errorText = error?.let { it.message ?: it.javaClass.simpleName }.orEmpty()
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_EVENT, event)
            .putString(KEY_LAST_ERROR, errorText)
            .putString(KEY_LAST_TIME, now)
            .apply()
        if (error == null) {
            Log.i(TAG, event)
        } else {
            Log.w(TAG, "$event: $errorText", error)
        }
    }

    fun lastEvent(context: Context): String {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val event = sp.getString(KEY_LAST_EVENT, "暂无创建记录").orEmpty()
        val error = sp.getString(KEY_LAST_ERROR, "").orEmpty()
        val time = sp.getString(KEY_LAST_TIME, "").orEmpty()
        return buildString {
            if (time.isNotBlank()) append(time).append(" · ")
            append(event)
            if (error.isNotBlank()) append(" · ").append(error)
        }
    }

    fun snapshot(context: Context, manager: WorkProfileManager): String {
        val compat = manager.compatibility()
        val userProfiles = runCatching {
            context.getSystemService(UserManager::class.java).userProfiles.size
        }.getOrDefault(-1)
        return buildString {
            appendLine("下雪应用隔离 · 创建诊断")
            appendLine("包名：${context.packageName}")
            appendLine("版本：${appVersion(context)}")
            appendLine("设备：${compat.manufacturer} ${compat.model}")
            appendLine("Android：${compat.sdk}")
            appendLine("支持工作资料：${compat.supportsManagedUsers}")
            appendLine("系统允许创建：${compat.provisioningAllowed}")
            appendLine("Profile Owner：${compat.isProfileOwner}")
            appendLine("Device Owner：${compat.isDeviceOwner}")
            appendLine("关联用户数：$userProfiles")
            appendLine("最近事件：${lastEvent(context)}")
        }.trim()
    }

    private fun appVersion(context: Context): String {
        return runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            @Suppress("DEPRECATION")
            val legacyCode = info.versionCode.toString()
            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode.toString() else legacyCode
            "${info.versionName ?: "unknown"} ($code)"
        }.getOrDefault("unknown")
    }

    fun copySnapshot(context: Context, manager: WorkProfileManager): Boolean {
        return runCatching {
            val clipboard = context.getSystemService(ClipboardManager::class.java)
            clipboard.setPrimaryClip(ClipData.newPlainText("下雪应用隔离诊断", snapshot(context, manager)))
            true
        }.getOrDefault(false)
    }
}
