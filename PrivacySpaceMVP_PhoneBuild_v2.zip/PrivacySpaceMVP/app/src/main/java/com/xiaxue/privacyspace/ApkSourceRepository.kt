package com.xiaxue.privacyspace

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.security.SecureRandom

internal class ApkSourceRepository(private val context: Context) {
    data class InventoryItem(
        val packageName: String,
        val label: String,
        val applicationInfo: ApplicationInfo,
        val versionCode: Long,
        val versionName: String,
        val splitCount: Int,
        val sourceBytes: Long,
        val sourceReady: Boolean,
        val sourceIssue: String?
    )

    fun loadInventory(): List<InventoryItem> {
        val flags = PackageManager.GET_SIGNING_CERTIFICATES or
            PackageManager.MATCH_DISABLED_COMPONENTS or
            PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        @Suppress("DEPRECATION")
        val packages = context.packageManager.getInstalledPackages(flags)
        return packages.mapNotNull { info ->
            val app = info.applicationInfo ?: return@mapNotNull null
            val packageName = info.packageName?.trim().orEmpty()
            if (packageName.isBlank()) return@mapNotNull null
            val paths = sourceFiles(app)
            val issue = sourceAvailabilityIssue(paths)
            InventoryItem(
                packageName = packageName,
                label = runCatching { app.loadLabel(context.packageManager).toString() }.getOrDefault(packageName),
                applicationInfo = app,
                versionCode = info.longVersionCode,
                versionName = info.versionName.orEmpty(),
                splitCount = (paths.size - 1).coerceAtLeast(0),
                sourceBytes = paths.sumOf { runCatching { it.length() }.getOrDefault(0L) },
                sourceReady = issue == null,
                sourceIssue = issue
            )
        }
    }

    fun prepare(packageName: String, label: String): Result<ApkSourceDescriptor> = runCatching {
        val pkg = packageName.trim()
        require(pkg.isNotBlank()) { "包名不能为空。" }
        require(pkg != context.packageName) { "隔离管理器会由系统自动安装到工作资料，无需克隆自身。" }
        val packageInfo = packageInfo(pkg)
        val appInfo = packageInfo.applicationInfo ?: throw IllegalStateException("无法读取应用信息。")
        val sources = sourceFiles(appInfo)
        sourceAvailabilityIssue(sources)?.let { throw IllegalStateException(it) }

        val sessionId = randomSessionId()
        require(sources.size <= MAX_SOURCE_FILES) { "APK split 数量超过安全上限。" }
        val totalBeforeHash = sources.sumOf { it.length() }
        require(totalBeforeHash in 1..MAX_SOURCE_BYTES) { "APK 来源总大小超过安全上限。" }
        val storedFiles = sources.mapIndexed { index, file ->
            val canonical = file.canonicalFile
            ApkSourceSessionStore.StoredFile(
                index = index,
                displayName = safeDisplayName(index, canonical.name),
                canonicalPath = canonical.path,
                sizeBytes = canonical.length(),
                lastModified = canonical.lastModified(),
                sha256 = sha256(canonical)
            )
        }
        val expiresAt = System.currentTimeMillis() + ApkSourceSessionStore.SESSION_TTL_MS
        val stored = ApkSourceSessionStore.StoredSession(
            sessionId = sessionId,
            packageName = pkg,
            versionCode = packageInfo.longVersionCode,
            expiresAt = expiresAt,
            files = storedFiles
        )
        check(ApkSourceSessionStore.save(context, stored)) { "无法保存 APK 来源会话。" }

        val authority = "${context.packageName}.apk_source"
        val descriptor = ApkSourceDescriptor(
            sessionId = sessionId,
            packageName = pkg,
            label = label.trim().ifBlank { pkg },
            versionCode = packageInfo.longVersionCode,
            versionName = packageInfo.versionName.orEmpty(),
            signingSha256 = signingDigests(packageInfo),
            expiresAt = expiresAt,
            files = storedFiles.map { file ->
                ApkSourceFile(
                    index = file.index,
                    displayName = file.displayName,
                    sizeBytes = file.sizeBytes,
                    sha256 = file.sha256,
                    uri = Uri.Builder()
                        .scheme("content")
                        .authority(authority)
                        .appendPath("session")
                        .appendPath(sessionId)
                        .appendPath("file")
                        .appendPath(file.index.toString())
                        .appendPath(file.displayName)
                        .build()
                )
            }
        )
        descriptor.validationError()?.let { throw IllegalStateException(it) }
        ProvisioningDiagnostics.record(
            context,
            "APK 来源已准备：$pkg version=${descriptor.versionCode} files=${descriptor.files.size} bytes=${descriptor.totalBytes}"
        )
        descriptor
    }.onFailure {
        ProvisioningDiagnostics.record(context, "准备 APK 来源失败：$packageName", it)
    }

    private fun packageInfo(packageName: String): PackageInfo {
        @Suppress("DEPRECATION")
        return context.packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
    }

    private fun signingDigests(info: PackageInfo): List<String> {
        val signing = info.signingInfo ?: throw IllegalStateException("无法读取应用签名。")
        val signatures = if (signing.hasMultipleSigners()) {
            signing.apkContentsSigners
        } else {
            signing.signingCertificateHistory ?: signing.apkContentsSigners
        }
        val digests = signatures.map { signature ->
            MessageDigest.getInstance("SHA-256")
                .digest(signature.toByteArray())
                .joinToString("") { "%02x".format(it) }
        }.distinct().sorted()
        require(digests.isNotEmpty()) { "应用签名为空。" }
        return digests
    }

    private fun sourceFiles(info: ApplicationInfo): List<File> {
        fun preferred(vararg paths: String?): File? {
            val candidates = paths.filterNotNull().distinct().map(::File)
            return candidates.firstOrNull { it.isFile && it.canRead() } ?: candidates.firstOrNull()
        }

        val base = preferred(info.publicSourceDir, info.sourceDir)
        val publicSplits = info.splitPublicSourceDirs ?: emptyArray()
        val sourceSplits = info.splitSourceDirs ?: emptyArray()
        val splitCount = maxOf(publicSplits.size, sourceSplits.size)
        val splits = (0 until splitCount).mapNotNull { index ->
            preferred(publicSplits.getOrNull(index), sourceSplits.getOrNull(index))
        }
        return listOfNotNull(base) + splits
    }

    private fun sourceAvailabilityIssue(files: List<File>): String? {
        if (files.isEmpty()) return "没有找到 base APK 来源。"
        if (!files.first().isFile || !files.first().canRead()) return "base APK 不可读。"
        if (files.any { !it.isFile || !it.canRead() }) return "部分 split APK 不可读。"
        if (files.any { it.length() <= 0L }) return "APK 来源包含空文件。"
        if (files.map { runCatching { it.canonicalPath }.getOrDefault(it.path) }.distinct().size != files.size) {
            return "APK 来源路径重复。"
        }
        return null
    }

    private fun safeDisplayName(index: Int, original: String): String {
        if (index == 0) return "base.apk"
        val sanitized = original.replace(Regex("[^A-Za-z0-9._-]"), "_")
            .take(96)
            .ifBlank { "split_$index.apk" }
        return when {
            !sanitized.endsWith(".apk", ignoreCase = true) -> "$sanitized.apk"
            sanitized.equals("base.apk", ignoreCase = true) -> "split_$index.apk"
            else -> sanitized
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 4)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun randomSessionId(): String {
        val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val MAX_SOURCE_FILES = 256
        private const val MAX_SOURCE_BYTES = 20L * 1024L * 1024L * 1024L

        fun currentVersionCode(context: Context, packageName: String): Long? {
            return runCatching {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0).longVersionCode
            }.getOrNull()
        }

        fun currentSourcePaths(context: Context, packageName: String): Set<String> {
            return runCatching {
                @Suppress("DEPRECATION")
                val info = context.packageManager.getPackageInfo(packageName, 0).applicationInfo
                    ?: return@runCatching emptySet()

                fun preferred(vararg paths: String?): String? {
                    val candidates = paths.filterNotNull().distinct()
                    return candidates.firstOrNull { File(it).isFile && File(it).canRead() }
                        ?: candidates.firstOrNull()
                }

                val paths = buildList {
                    preferred(info.publicSourceDir, info.sourceDir)?.let(::add)
                    val publicSplits = info.splitPublicSourceDirs ?: emptyArray()
                    val sourceSplits = info.splitSourceDirs ?: emptyArray()
                    val splitCount = maxOf(publicSplits.size, sourceSplits.size)
                    for (index in 0 until splitCount) {
                        preferred(publicSplits.getOrNull(index), sourceSplits.getOrNull(index))?.let(::add)
                    }
                }
                paths.mapNotNull { path -> runCatching { File(path).canonicalPath }.getOrNull() }.toSet()
            }.getOrDefault(emptySet())
        }
    }
}
