package com.xiaxue.privacyspace

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.os.Build

internal object PackageUninstallCoordinator {
    const val ACTION_UNINSTALL_STATUS = "com.xiaxue.privacyspace.action.UNINSTALL_STATUS"
    const val EXTRA_OPERATION_ID = "com.xiaxue.privacyspace.extra.LIFECYCLE_OPERATION_ID"
    const val EXTRA_CALLBACK_TOKEN = "com.xiaxue.privacyspace.extra.LIFECYCLE_CALLBACK_TOKEN"

    fun submit(
        activity: Activity,
        packageName: String,
        label: String,
        remoteStateRequestId: String? = null
    ): Result<Unit> {
        val manager = WorkProfileManager(activity)
        if (!manager.isProfileOwner()) {
            return Result.failure(IllegalStateException("卸载隔离应用必须由工作资料管理器执行。"))
        }
        manager.protectedReason(packageName)?.let {
            return Result.failure(SecurityException("已阻止卸载：$it。"))
        }
        return runCatching {
            val record = LifecycleRequestStore.create(
                activity,
                remoteStateRequestId,
                packageName.trim(),
                label.ifBlank { packageName }
            )
            val callbackIntent = Intent(activity, UninstallResultActivity::class.java).apply {
                action = ACTION_UNINSTALL_STATUS
                putExtra(EXTRA_OPERATION_ID, record.operationId)
                putExtra(EXTRA_CALLBACK_TOKEN, record.callbackToken)
            }
            val requestCode = record.operationId.hashCode() and 0x7fffffff
            val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE
            } else 0
            val callback = PendingIntent.getActivity(
                activity,
                requestCode,
                callbackIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
            )
            activity.packageManager.packageInstaller.uninstall(packageName, callback.intentSender)
            ProvisioningDiagnostics.record(activity, "已提交隔离应用卸载：$packageName")
        }.onFailure {
            ProvisioningDiagnostics.record(activity, "提交隔离应用卸载失败：$packageName", it)
        }
    }
}
