package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import android.os.Process
import android.os.UserManager

internal class WorkProfileManager(private val context: Context) {
    private val dpm: DevicePolicyManager = requireNotNull(
        context.getSystemService(DevicePolicyManager::class.java)
    ) { "系统缺少设备策略服务。" }
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    data class Compatibility(
        val supportsManagedUsers: Boolean,
        val provisioningAllowed: Boolean,
        val isProfileOwner: Boolean,
        val sdk: Int,
        val manufacturer: String,
        val model: String,
        val isDeviceOwner: Boolean,
        val userProfileCount: Int
    ) {
        val canCreateProfile: Boolean get() = supportsManagedUsers && provisioningAllowed && !isProfileOwner && !isDeviceOwner
        val hasRelatedProfile: Boolean get() = userProfileCount > 1

        fun likelyBlockReason(): String? {
            if (isProfileOwner) return null
            return when {
                !supportsManagedUsers ->
                    "这台设备或当前系统没有开放工作资料能力，通常无法通过第三方 App 解决。"
                !provisioningAllowed && userProfileCount > 1 ->
                    "最可能原因：手机上已经有一个工作资料/分身空间占用了名额（Android 每台设备只允许一个工作资料）。很可能是之前测试过原版 Shelter 或旧版本本 App 时创建、还没清理干净。\n\n" +
                        "解决办法：先到系统设置里找到并移除已有的工作资料/工作空间/分身资料，重启手机，再回来重新创建。"
                !provisioningAllowed ->
                    "系统当前拒绝创建工作资料，常见原因是设备被企业/学校/家长控制器占用，或厂商 ROM 关闭了此入口。"
                isDeviceOwner ->
                    "当前 App 已经是设备管理者（Device Owner），这与工作资料模式互斥，无法再创建工作资料。"
                else -> null
            }
        }
    }

    fun adminComponent(): ComponentName = admin

    fun isProfileOwner(): Boolean {
        return runCatching { dpm.isProfileOwnerApp(context.packageName) }.getOrDefault(false)
    }

    fun compatibility(): Compatibility {
        val supports = context.packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)
        val allowed = runCatching {
            dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
        }.getOrDefault(false)
        val owner = isProfileOwner()
        val deviceOwner = runCatching { dpm.isDeviceOwnerApp(context.packageName) }.getOrDefault(false)
        val profileCount = runCatching {
            context.getSystemService(UserManager::class.java)?.userProfiles?.size ?: 1
        }.getOrDefault(1)
        return Compatibility(
            supportsManagedUsers = supports,
            provisioningAllowed = allowed,
            isProfileOwner = owner,
            sdk = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER ?: "unknown",
            model = Build.MODEL ?: "unknown",
            isDeviceOwner = deviceOwner,
            userProfileCount = profileCount
        )
    }

    fun createProvisioningIntent(): Intent {
        return Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true)
            putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE,
                CrossProfileAuth.provisioningExtras(context)
            )
        }
    }

    fun requestCreateManagedProfile(activity: Activity) {
        val compat = compatibility()
        if (compat.isProfileOwner) {
            throw IllegalStateException("当前已经位于工作资料管理空间，不需要重复创建。")
        }
        if (!compat.supportsManagedUsers) {
            throw IllegalStateException("这台设备或当前系统没有开放工作资料能力。")
        }
        if (!compat.provisioningAllowed) {
            throw IllegalStateException("系统当前不允许创建工作资料。常见原因：已有工作资料、系统被企业/家长管理占用、厂商 ROM 禁用了此能力，或当前不是主用户。")
        }
        activity.startActivity(createProvisioningIntent())
    }

    fun setPackageHidden(packageName: String, hidden: Boolean): Result<Boolean> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法冻结/恢复应用。请在隔离空间里的本 App 中操作。"))
        }
        if (hidden) {
            ProtectedPackages.reason(context, pkg)?.let {
                return Result.failure(SecurityException("已阻止冻结：$it。"))
            }
        }
        return runCatching {
            dpm.setApplicationHidden(admin, pkg, hidden)
        }.onSuccess {
            ProvisioningDiagnostics.record(context, "隐藏状态修改：$pkg hidden=$hidden result=$it")
        }.onFailure {
            ProvisioningDiagnostics.record(context, "隐藏状态修改失败：$pkg hidden=$hidden", it)
        }
    }

    fun isPackageHidden(packageName: String): Result<Boolean> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        if (!isProfileOwner()) return Result.success(false)
        return runCatching { dpm.isApplicationHidden(admin, pkg) }
    }

    fun protectedReason(packageName: String): String? = ProtectedPackages.reason(context, packageName)

    fun isInstalledInCurrentProfile(packageName: String): Boolean {
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS or PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        return runCatching {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(packageName, flags)
        }.isSuccess
    }

    fun prepareLaunchIntentInThisProfile(packageName: String): Result<Intent> {
        val pkg = packageName.trim()
        if (pkg.isBlank()) return Result.failure(IllegalArgumentException("包名不能为空。"))
        return runCatching {
            if (isProfileOwner()) {
                val hidden = runCatching { dpm.isApplicationHidden(admin, pkg) }.getOrDefault(false)
                if (hidden) {
                    val restored = dpm.setApplicationHidden(admin, pkg, false)
                    if (!restored) throw IllegalStateException("系统拒绝恢复该应用，无法启动。")
                }
            }
            context.packageManager.getLaunchIntentForPackage(pkg)
                ?: throw IllegalStateException("当前空间中没有找到该应用的启动入口。")
        }.onFailure {
            ProvisioningDiagnostics.record(context, "准备当前空间应用启动失败：$pkg", it)
        }
    }

    fun launchPackageInThisProfile(activity: Activity, packageName: String): Result<Unit> {
        val pkg = packageName.trim()
        return prepareLaunchIntentInThisProfile(pkg).mapCatching { launchIntent ->
            activity.startActivity(launchIntent)
            ProvisioningDiagnostics.record(context, "当前空间启动应用：$pkg")
        }.onFailure {
            ProvisioningDiagnostics.record(context, "当前空间启动应用失败：$pkg", it)
        }
    }

    fun openCloneRequestChooser(activity: Activity, descriptor: ApkSourceDescriptor): Result<Unit> {
        return openCrossProfileRequest(
            activity = activity,
            action = ProvisioningContract.ACTION_CLONE_PACKAGE,
            packageName = descriptor.packageName,
            label = descriptor.label,
            source = descriptor
        )
    }

    fun requestRemoteSnapshot(activity: Activity, force: Boolean = false): Result<Unit> {
        val compat = compatibility()
        if (!compat.hasRelatedProfile) return Result.failure(IllegalStateException("没有检测到关联工作资料。"))
        if (!CrossProfileAuth.hasKey(context)) return Result.failure(IllegalStateException("主空间与隔离空间尚未建立安全配对。"))
        if (!force && ProfileStateStore.isFresh(context)) return Result.success(Unit)

        val requestId = ProfileStateStore.beginRequest(context, expectedProfileOwner = !isProfileOwner())
        val action = if (isProfileOwner()) {
            ProvisioningContract.ACTION_QUERY_PARENT_PROFILE
        } else {
            ProvisioningContract.ACTION_QUERY_WORK_PROFILE
        }
        return openCrossProfileRequest(
            activity = activity,
            action = action,
            packageName = "",
            label = "",
            requestId = requestId
        ).onFailure { ProfileStateStore.cancelRequest(context, requestId) }
    }

    fun requestRemoteLaunch(activity: Activity, packageName: String, label: String): Result<Unit> {
        val action = if (isProfileOwner()) {
            ProvisioningContract.ACTION_LAUNCH_PARENT_PACKAGE
        } else {
            ProvisioningContract.ACTION_LAUNCH_PACKAGE
        }
        return openRemoteCommand(activity, action, packageName, label, null)
    }

    fun requestRemoteHidden(
        activity: Activity,
        packageName: String,
        label: String,
        hidden: Boolean
    ): Result<Unit> {
        if (isProfileOwner()) {
            return Result.failure(IllegalStateException("工作资料管理器不能冻结主空间应用。"))
        }
        return openRemoteCommand(
            activity,
            ProvisioningContract.ACTION_SET_PACKAGE_HIDDEN,
            packageName,
            label,
            hidden
        )
    }

    fun requestRemoteUninstall(activity: Activity, packageName: String, label: String): Result<Unit> {
        if (isProfileOwner()) {
            return Result.failure(IllegalStateException("工作资料管理器不能卸载主空间应用。"))
        }
        return openRemoteCommand(
            activity,
            ProvisioningContract.ACTION_UNINSTALL_PACKAGE,
            packageName,
            label,
            null
        )
    }

    private fun openRemoteCommand(
        activity: Activity,
        action: String,
        packageName: String,
        label: String,
        hidden: Boolean?
    ): Result<Unit> {
        val requestId = ProfileStateStore.beginRequest(context, expectedProfileOwner = !isProfileOwner())
        return openCrossProfileRequest(
            activity = activity,
            action = action,
            packageName = packageName,
            label = label,
            requestId = requestId,
            requestedHidden = hidden
        ).onFailure { ProfileStateStore.cancelRequest(context, requestId) }
    }

    fun sendProfileStateResult(activity: Activity, snapshot: ProfileStateSnapshot): Result<Unit> {
        val raw = snapshot.toJson()
        val hash = ProfileStateSnapshot.sha256Text(raw)
        return openCrossProfileRequest(
            activity = activity,
            action = ProvisioningContract.ACTION_PROFILE_STATE_RESULT,
            packageName = "",
            label = snapshot.profileLabel,
            requestId = snapshot.requestId,
            stateJson = raw,
            stateSha256 = hash
        )
    }

    private fun openCrossProfileRequest(
        activity: Activity,
        action: String,
        packageName: String,
        label: String,
        source: ApkSourceDescriptor? = null,
        requestId: String? = null,
        requestedHidden: Boolean? = null,
        stateJson: String? = null,
        stateSha256: String? = null
    ): Result<Unit> {
        val pkg = packageName.trim()
        val packageRequired = action in setOf(
            ProvisioningContract.ACTION_CLONE_PACKAGE,
            ProvisioningContract.ACTION_LAUNCH_PACKAGE,
            ProvisioningContract.ACTION_LAUNCH_PARENT_PACKAGE,
            ProvisioningContract.ACTION_SET_PACKAGE_HIDDEN,
            ProvisioningContract.ACTION_UNINSTALL_PACKAGE
        )
        if (packageRequired && pkg.isBlank()) {
            return Result.failure(IllegalArgumentException("包名不能为空。"))
        }

        return runCatching {
            val request = Intent(action).apply {
                addCategory(Intent.CATEGORY_DEFAULT)
                if (pkg.isNotBlank()) putExtra(ProvisioningContract.EXTRA_PACKAGE_NAME, pkg)
                if (label.isNotBlank()) putExtra(ProvisioningContract.EXTRA_APP_LABEL, label.trim())
                requestId?.let { putExtra(ProvisioningContract.EXTRA_STATE_REQUEST_ID, it) }
                requestedHidden?.let { putExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN, it) }
                stateJson?.let { putExtra(ProvisioningContract.EXTRA_PROFILE_STATE_JSON, it) }
                stateSha256?.let { putExtra(ProvisioningContract.EXTRA_PROFILE_STATE_SHA256, it) }
                if (source != null) {
                    require(source.packageName == pkg) { "APK 来源包名与请求不一致。" }
                    source.validationError()?.let { throw IllegalStateException(it) }
                    val manifest = source.toJson()
                    putExtra(ProvisioningContract.EXTRA_APK_SOURCE_SESSION_ID, source.sessionId)
                    putExtra(ProvisioningContract.EXTRA_APK_SOURCE_MANIFEST, manifest)
                    putExtra(
                        ProvisioningContract.EXTRA_APK_SOURCE_MANIFEST_SHA256,
                        ApkSourceDescriptor.sha256Text(manifest)
                    )
                    val first = source.files.first().uri
                    clipData = ClipData.newRawUri("APK source", first).apply {
                        source.files.drop(1).forEach { addItem(ClipData.Item(it.uri)) }
                    }
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (action in setOf(
                        ProvisioningContract.ACTION_QUERY_WORK_PROFILE,
                        ProvisioningContract.ACTION_QUERY_PARENT_PROFILE,
                        ProvisioningContract.ACTION_PROFILE_STATE_RESULT
                    )
                ) {
                    addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                }
            }
            CrossProfileAuth.sign(activity, request)

            val candidates = activity.packageManager.queryIntentActivities(request, PackageManager.MATCH_DEFAULT_ONLY)
            val forwarded = candidates.firstOrNull { isTrustedSystemForwarder(activity.packageManager, it) }
                ?: throw IllegalStateException("没有找到可信的跨资料转发入口。请确认工作资料由新版创建，并在两个空间分别打开一次本 App。")
            val forwarderInfo = forwarded.activityInfo
                ?: throw IllegalStateException("系统转发入口缺少组件信息。")
            request.component = ComponentName(forwarderInfo.packageName, forwarderInfo.name)
            source?.files?.forEach { file ->
                runCatching {
                    activity.grantUriPermission(
                        forwarderInfo.packageName,
                        file.uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }.onFailure {
                    ProvisioningDiagnostics.record(context, "预授权 APK 来源 URI 失败：${file.displayName}", it)
                }
            }
            activity.startActivity(request)
        }.onFailure {
            ProvisioningDiagnostics.record(context, "跨资料请求发送失败：action=$action package=$pkg", it)
        }
    }

    private fun isTrustedSystemForwarder(packageManager: PackageManager, candidate: ResolveInfo): Boolean {
        val info = candidate.activityInfo ?: return false
        if (info.packageName == context.packageName) return false
        if (info.applicationInfo.uid == Process.SYSTEM_UID) return true
        return packageManager.checkSignatures("android", info.packageName) == PackageManager.SIGNATURE_MATCH
    }
}
