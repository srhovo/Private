package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

class WorkProfileManager(private val context: Context) {
    private val dpm: DevicePolicyManager = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    data class Compatibility(
        val supportsManagedUsers: Boolean,
        val provisioningAllowed: Boolean,
        val isProfileOwner: Boolean,
        val sdk: Int,
        val manufacturer: String,
        val model: String
    ) {
        val canCreateProfile: Boolean get() = supportsManagedUsers && provisioningAllowed && !isProfileOwner
    }

    fun adminComponent(): ComponentName = admin

    fun isProfileOwner(): Boolean {
        return runCatching { dpm.isProfileOwnerApp(context.packageName) }.getOrDefault(false)
    }

    fun compatibility(): Compatibility {
        val supports = context.packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)
        val allowed = runCatching {
            dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
        }.getOrDefault(false)
        return Compatibility(
            supportsManagedUsers = supports,
            provisioningAllowed = allowed,
            isProfileOwner = isProfileOwner(),
            sdk = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER ?: "unknown",
            model = Build.MODEL ?: "unknown"
        )
    }

    fun requestCreateManagedProfile(activity: Activity) {
        val compat = compatibility()
        if (compat.isProfileOwner) {
            throw IllegalStateException("当前已经位于工作资料管理空间，不需要重复创建。")
        }
        if (!compat.supportsManagedUsers) {
            throw IllegalStateException("这台设备或当前系统没有开放工作资料能力。")
        }
        if (!compat.provisioningAllowed) {
            throw IllegalStateException("系统当前不允许创建工作资料。常见原因：已有工作资料、系统被企业/家长管理占用、厂商 ROM 禁用了此能力，或当前不是主用户。")
        }

        val intent = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin)
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, false)
        }
        activity.startActivity(intent)
    }

    fun cloneExistingPackageToThisProfile(packageName: String): Result<Boolean> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法执行安装/克隆管理。请先成功创建工作资料，并在工作资料里的本 App 中操作。"))
        }
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.installExistingPackage(admin, packageName)
            } else {
                throw UnsupportedOperationException("installExistingPackage 需要 Android 9 或更高版本。")
            }
        }
    }

    fun setPackageHidden(packageName: String, hidden: Boolean): Result<Unit> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法冻结/恢复应用。请在工作资料里的本 App 中操作。"))
        }
        return runCatching {
            dpm.setApplicationHidden(admin, packageName, hidden)
        }
    }
}
