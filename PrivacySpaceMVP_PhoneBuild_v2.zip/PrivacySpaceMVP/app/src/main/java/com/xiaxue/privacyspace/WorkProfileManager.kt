package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.UserManager

class WorkProfileManager(private val context: Context) {
    private val dpm: DevicePolicyManager = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

    data class Compatibility(
        val supportsManagedUsers: Boolean,
        val provisioningAllowed: Boolean,
        val isProfileOwner: Boolean,
        val sdk: Int,
        val manufacturer: String,
        val model: String,
        val isDeviceOwner: Boolean,
        val userProfileCount: Int
    ) {
        val canCreateProfile: Boolean get() = supportsManagedUsers && provisioningAllowed && !isProfileOwner && !isDeviceOwner
    }

    fun adminComponent(): ComponentName = admin

    fun isProfileOwner(): Boolean {
        return runCatching { dpm.isProfileOwnerApp(context.packageName) }.getOrDefault(false)
    }

    fun compatibility(): Compatibility {
        val supports = context.packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)
        val allowed = runCatching {
            dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
        }.getOrDefault(false)
        val owner = isProfileOwner()
        val deviceOwner = runCatching { dpm.isDeviceOwnerApp(context.packageName) }.getOrDefault(false)
        val profileCount = runCatching {
            context.getSystemService(UserManager::class.java).userProfiles.size
        }.getOrDefault(1)
        return Compatibility(
            supportsManagedUsers = supports,
            provisioningAllowed = allowed,
            isProfileOwner = owner,
            sdk = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER ?: "unknown",
            model = Build.MODEL ?: "unknown",
            isDeviceOwner = deviceOwner,
            userProfileCount = profileCount
        )
    }

    fun createProvisioningIntent(): Intent {
        return Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin)
            putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true)
        }
    }

    fun requestCreateManagedProfile(activity: Activity) {
        val compat = compatibility()
        if (compat.isProfileOwner) {
            throw IllegalStateException("当前已经位于工作资料管理空间，不需要重复创建。")
        }
        if (!compat.supportsManagedUsers) {
            throw IllegalStateException("这台设备或当前系统没有开放工作资料能力。")
        }
        if (!compat.provisioningAllowed) {
            throw IllegalStateException("系统当前不允许创建工作资料。常见原因：已有工作资料、系统被企业/家长管理占用、厂商 ROM 禁用了此能力，或当前不是主用户。")
        }
        activity.startActivity(createProvisioningIntent())
    }

    fun cloneExistingPackageToThisProfile(packageName: String): Result<Boolean> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法执行安装/克隆管理。请先成功创建工作资料，并在工作资料里的本 App 中操作。"))
        }
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.installExistingPackage(admin, packageName)
            } else {
                throw UnsupportedOperationException("installExistingPackage 需要 Android 9 或更高版本。")
            }
        }
    }

    fun setPackageHidden(packageName: String, hidden: Boolean): Result<Boolean> {
        if (!isProfileOwner()) {
            return Result.failure(IllegalStateException("当前实例不是工作资料的 Profile Owner，无法冻结/恢复应用。请在工作资料里的本 App 中操作。"))
        }
        return runCatching {
            dpm.setApplicationHidden(admin, packageName, hidden)
        }
    }
}
