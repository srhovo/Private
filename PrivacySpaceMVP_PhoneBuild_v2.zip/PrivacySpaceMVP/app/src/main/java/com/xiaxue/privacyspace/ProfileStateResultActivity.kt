package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import java.security.MessageDigest

class ProfileStateResultActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(source: Intent) {
        if (source.action != ProvisioningContract.ACTION_PROFILE_STATE_RESULT) {
            finishQuietly()
            return
        }
        val verification = CrossProfileAuth.verify(this, source)
        if (!verification.accepted) {
            ProvisioningDiagnostics.record(this, "拒绝跨资料状态结果：${verification.reason}")
            finishQuietly()
            return
        }
        val requestId = source.getStringExtra(ProvisioningContract.EXTRA_STATE_REQUEST_ID)?.trim().orEmpty()
        val raw = source.getStringExtra(ProvisioningContract.EXTRA_PROFILE_STATE_JSON).orEmpty()
        val suppliedHash = source.getStringExtra(ProvisioningContract.EXTRA_PROFILE_STATE_SHA256)?.trim().orEmpty()
        val actualHash = ProfileStateSnapshot.sha256Text(raw)
        if (requestId.isBlank() || suppliedHash.isBlank() || !MessageDigest.isEqual(
                suppliedHash.toByteArray(Charsets.UTF_8),
                actualHash.toByteArray(Charsets.UTF_8)
            )
        ) {
            ProvisioningDiagnostics.record(this, "拒绝跨资料状态结果：摘要或请求 ID 无效")
            finishQuietly()
            return
        }
        val snapshot = runCatching { ProfileStateSnapshot.fromJson(raw) }.getOrElse {
            ProvisioningDiagnostics.record(this, "跨资料状态结果解析失败", it)
            finishQuietly()
            return
        }
        if (snapshot.requestId != requestId || !ProfileStateStore.accept(this, snapshot)) {
            ProvisioningDiagnostics.record(this, "拒绝未知或过期的跨资料状态结果：request=$requestId")
            finishQuietly()
            return
        }
        ProvisioningDiagnostics.record(
            this,
            "已同步${snapshot.profileLabel}状态：${snapshot.packages.count { it.installed }} 个应用"
        )
        finishQuietly()
    }

    private fun finishQuietly() {
        finish()
        overridePendingTransition(0, 0)
    }
}
