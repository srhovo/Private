package com.xiaxue.privacyspace

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

class PrivacyDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "下雪应用隔离管理器已启用", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "下雪应用隔离管理器已停用", Toast.LENGTH_SHORT).show()
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        runCatching { dpm.setProfileName(admin, "下雪应用隔离") }
        runCatching { dpm.setProfileEnabled(admin) }
        Toast.makeText(context, "工作资料创建完成", Toast.LENGTH_LONG).show()
        context.startActivity(
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }
}
