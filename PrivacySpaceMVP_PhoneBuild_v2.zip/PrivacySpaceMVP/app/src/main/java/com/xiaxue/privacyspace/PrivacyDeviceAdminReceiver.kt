package com.xiaxue.privacyspace

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class PrivacyDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "下雪应用隔离管理器已启用", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "下雪应用隔离管理器已停用", Toast.LENGTH_SHORT).show()
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        ProvisioningDiagnostics.record(context, "收到 onProfileProvisioningComplete")
        ProfileSetup.complete(context)
        runCatching {
            context.startActivity(
                Intent(context, DummyActivity::class.java)
                    .setAction(ProvisioningContract.ACTION_FINALIZE_PROVISION)
                    .putExtra(ProvisioningContract.EXTRA_OPEN_MAIN, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }.onFailure { ProvisioningDiagnostics.record(context, "Receiver 启动 DummyActivity 收尾失败", it) }
    }
}
