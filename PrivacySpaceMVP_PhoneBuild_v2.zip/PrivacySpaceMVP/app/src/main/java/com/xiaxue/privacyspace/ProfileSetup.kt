package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

internal object ProfileSetup {
    fun complete(context: Context): Boolean {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

        val isOwner = runCatching { dpm.isProfileOwnerApp(context.packageName) }
            .onFailure { ProvisioningDiagnostics.record(context, "检查 Profile Owner 失败", it) }
            .getOrDefault(false)

        if (!isOwner) {
            ProvisioningDiagnostics.record(context, "收尾跳过：当前用户不是 Profile Owner")
            return false
        }

        runCatching { dpm.setProfileName(admin, context.getString(R.string.work_profile_name)) }
            .onFailure { ProvisioningDiagnostics.record(context, "设置工作资料名称失败", it) }

        val enabled = runCatching {
            dpm.setProfileEnabled(admin)
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "启用工作资料失败", it)
        }.getOrDefault(false)

        ProvisioningDiagnostics.record(context, "工作资料收尾完成：enabled=$enabled")
        return enabled
    }

    fun finishProvisioningActivity(activity: Activity, openMain: Boolean) {
        complete(activity)
        activity.setResult(Activity.RESULT_OK)
        if (openMain) {
            runCatching {
                activity.startActivity(
                    Intent(activity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }.onFailure { ProvisioningDiagnostics.record(activity, "打开首页失败", it) }
        }
        activity.finish()
    }
}
