package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager

internal object ProfileSetup {
    private const val PREF = "xiaxue_profile_setup"
    private const val KEY_CONFIG_VERSION = "config_version"
    private const val CURRENT_CONFIG_VERSION = 3

    fun complete(context: Context, force: Boolean = false): Boolean {
        val dpm = context.getSystemService(DevicePolicyManager::class.java) ?: run {
            ProvisioningDiagnostics.record(context, "收尾失败：系统缺少设备策略服务")
            configureCrossProfileReceiversForCurrentProfile(context)
            return false
        }
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)
        val isOwner = runCatching { dpm.isProfileOwnerApp(context.packageName) }
            .onFailure { ProvisioningDiagnostics.record(context, "检查 Profile Owner 失败", it) }
            .getOrDefault(false)

        if (!isOwner) {
            ProvisioningDiagnostics.record(context, "收尾跳过：当前用户不是 Profile Owner")
            configureCrossProfileReceiversForCurrentProfile(context)
            return false
        }

        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val configuredVersion = prefs.getInt(KEY_CONFIG_VERSION, 0)
        if (!force && configuredVersion == CURRENT_CONFIG_VERSION) {
            val receiverReady = configureCrossProfileReceiversForCurrentProfile(context)
            ProvisioningDiagnostics.record(context, "工作资料配置已是最新版本：$CURRENT_CONFIG_VERSION")
            return receiverReady
        }

        val profileNameOk = runCatching {
            dpm.setProfileName(admin, context.getString(R.string.work_profile_name))
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "设置工作资料名称失败", it)
        }.getOrDefault(false)

        val receiverOk = configureCrossProfileReceiversForCurrentProfile(context)
        val filtersOk = configureCrossProfileCommands(context, dpm, admin)
        val enabled = runCatching {
            dpm.setProfileEnabled(admin)
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "启用工作资料失败", it)
        }.getOrDefault(false)

        val success = receiverOk && filtersOk && enabled
        if (success) {
            prefs.edit().putInt(KEY_CONFIG_VERSION, CURRENT_CONFIG_VERSION).commit()
        }
        ProvisioningDiagnostics.record(
            context,
            "工作资料收尾：success=$success profileName=$profileNameOk receiver=$receiverOk filters=$filtersOk enabled=$enabled"
        )
        return success
    }

    private fun configureCrossProfileCommands(
        context: Context,
        dpm: DevicePolicyManager,
        admin: ComponentName
    ): Boolean {
        val clearOk = runCatching {
            dpm.clearCrossProfileIntentFilters(admin)
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "清理跨资料指令过滤器失败", it)
        }.getOrDefault(false)
        if (!clearOk) return false

        val parentToManaged = listOf(
            ProvisioningContract.ACTION_CLONE_PACKAGE,
            ProvisioningContract.ACTION_LAUNCH_PACKAGE,
            ProvisioningContract.ACTION_SET_PACKAGE_HIDDEN,
            ProvisioningContract.ACTION_UNINSTALL_PACKAGE,
            ProvisioningContract.ACTION_QUERY_WORK_PROFILE
        )
        val managedToParent = listOf(
            ProvisioningContract.ACTION_LAUNCH_PARENT_PACKAGE,
            ProvisioningContract.ACTION_QUERY_PARENT_PROFILE
        )
        val bidirectional = listOf(ProvisioningContract.ACTION_PROFILE_STATE_RESULT)

        val parentOk = parentToManaged.all { action ->
            addFilter(
                context,
                dpm,
                admin,
                action,
                DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT,
                "主空间到隔离空间"
            )
        }
        val managedOk = managedToParent.all { action ->
            addFilter(
                context,
                dpm,
                admin,
                action,
                DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED,
                "隔离空间到主空间"
            )
        }
        val resultOk = bidirectional.all { action ->
            addFilter(
                context,
                dpm,
                admin,
                action,
                DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT or
                    DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED,
                "双向状态回传"
            )
        }
        return parentOk && managedOk && resultOk
    }

    private fun addFilter(
        context: Context,
        dpm: DevicePolicyManager,
        admin: ComponentName,
        action: String,
        flags: Int,
        direction: String
    ): Boolean {
        val filter = IntentFilter(action).apply { addCategory(Intent.CATEGORY_DEFAULT) }
        return runCatching {
            dpm.addCrossProfileIntentFilter(admin, filter, flags)
            ProvisioningDiagnostics.record(context, "已配置${direction}指令：$action")
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "配置${direction}指令失败：$action", it)
        }.getOrDefault(false)
    }

    fun configureCrossProfileReceiversForCurrentProfile(context: Context): Boolean {
        val isOwner = runCatching {
            context.getSystemService(DevicePolicyManager::class.java)
                ?.isProfileOwnerApp(context.packageName) == true
        }.getOrDefault(false)
        return listOf(
            ComponentName(context, CloneRequestActivity::class.java) to isOwner,
            ComponentName(context, ParentRequestActivity::class.java) to !isOwner,
            ComponentName(context, ProfileStateResultActivity::class.java) to true
        ).all { (component, enabled) -> setComponentEnabled(context, component, enabled) }
    }

    fun configureCloneReceiverForCurrentProfile(context: Context, enabled: Boolean? = null): Boolean {
        if (enabled == null) return configureCrossProfileReceiversForCurrentProfile(context)
        val cloneOk = setComponentEnabled(
            context,
            ComponentName(context, CloneRequestActivity::class.java),
            enabled
        )
        val parentOk = setComponentEnabled(
            context,
            ComponentName(context, ParentRequestActivity::class.java),
            !enabled
        )
        val resultOk = setComponentEnabled(
            context,
            ComponentName(context, ProfileStateResultActivity::class.java),
            true
        )
        return cloneOk && parentOk && resultOk
    }

    private fun setComponentEnabled(context: Context, component: ComponentName, enabled: Boolean): Boolean {
        return runCatching {
            context.packageManager.setComponentEnabledSetting(
                component,
                if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            ProvisioningDiagnostics.record(context, "跨资料组件状态：${component.className} enabled=$enabled")
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "配置跨资料组件失败：${component.className}", it)
        }.getOrDefault(false)
    }

    fun finishProvisioningActivity(activity: Activity, openMain: Boolean) {
        complete(activity)
        activity.setResult(Activity.RESULT_OK)
        if (openMain) {
            runCatching {
                activity.startActivity(
                    Intent(activity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }.onFailure { ProvisioningDiagnostics.record(activity, "打开首页失败", it) }
        }
        activity.finish()
    }
}
