package com.xiaxue.privacyspace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

internal object ProfileSetup {
    fun complete(context: Context): Boolean {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, PrivacyDeviceAdminReceiver::class.java)

        val isOwner = runCatching { dpm.isProfileOwnerApp(context.packageName) }
            .onFailure { ProvisioningDiagnostics.record(context, "检查 Profile Owner 失败", it) }
            .getOrDefault(false)

        if (!isOwner) {
            ProvisioningDiagnostics.record(context, "收尾跳过：当前用户不是 Profile Owner")
            return false
        }

        runCatching { dpm.setProfileName(admin, context.getString(R.string.work_profile_name)) }
            .onFailure { ProvisioningDiagnostics.record(context, "设置工作资料名称失败", it) }

        configureCrossProfileCommands(context, dpm, admin)

        val enabled = runCatching {
            dpm.setProfileEnabled(admin)
            true
        }.onFailure {
            ProvisioningDiagnostics.record(context, "启用工作资料失败", it)
        }.getOrDefault(false)

        ProvisioningDiagnostics.record(context, "工作资料收尾完成：enabled=$enabled")
        return enabled
    }

    private fun configureCrossProfileCommands(context: Context, dpm: DevicePolicyManager, admin: ComponentName) {
        runCatching { dpm.clearCrossProfileIntentFilters(admin) }
            .onFailure { ProvisioningDiagnostics.record(context, "清理跨资料指令过滤器失败", it) }

        val flags = DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED or
            DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT

        listOf(
            ProvisioningContract.ACTION_CLONE_PACKAGE,
            ProvisioningContract.ACTION_LAUNCH_PACKAGE,
            ProvisioningContract.ACTION_START_SERVICE
        ).forEach { action ->
            val filter = IntentFilter(action).apply { addCategory(Intent.CATEGORY_DEFAULT) }
            runCatching { dpm.addCrossProfileIntentFilter(admin, filter, flags) }
                .onFailure { ProvisioningDiagnostics.record(context, "配置跨资料指令失败：$action", it) }
                .onSuccess { ProvisioningDiagnostics.record(context, "已配置跨资料指令：$action") }
        }
    }

    fun finishProvisioningActivity(activity: Activity, openMain: Boolean) {
        complete(activity)
        activity.setResult(Activity.RESULT_OK)
        if (openMain) {
            runCatching {
                activity.startActivity(
                    Intent(activity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }.onFailure { ProvisioningDiagnostics.record(activity, "打开首页失败", it) }
        }
        activity.finish()
    }
}
