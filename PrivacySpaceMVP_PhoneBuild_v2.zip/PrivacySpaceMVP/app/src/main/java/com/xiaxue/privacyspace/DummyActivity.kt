package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class DummyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == ProvisioningContract.ACTION_FINALIZE_PROVISION) {
            ProvisioningDiagnostics.record(this, "DummyActivity 执行工作资料收尾")
            val openMain = intent.getBooleanExtra(ProvisioningContract.EXTRA_OPEN_MAIN, true)
            ProfileSetup.finishProvisioningActivity(this, openMain)
        } else {
            ProvisioningDiagnostics.record(this, "DummyActivity 拒绝未知动作：${intent?.action}")
            finish()
        }
    }
}
