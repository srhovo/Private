package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class DummyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            ProvisioningContract.ACTION_FINALIZE_PROVISION -> {
                ProvisioningDiagnostics.record(this, "DummyActivity 执行工作资料收尾")
                val openMain = intent.getBooleanExtra(ProvisioningContract.EXTRA_OPEN_MAIN, true)
                ProfileSetup.finishProvisioningActivity(this, openMain)
            }
            ProvisioningContract.ACTION_START_SERVICE -> {
                ProvisioningDiagnostics.record(this, "收到 START_SERVICE 占位入口；第一阶段暂不启动跨空间服务")
                // 第一阶段只负责打通工作资料创建；服务链路放到第二阶段。
                setResult(RESULT_OK)
                finish()
            }
            else -> {
                finish()
            }
        }
    }
}
