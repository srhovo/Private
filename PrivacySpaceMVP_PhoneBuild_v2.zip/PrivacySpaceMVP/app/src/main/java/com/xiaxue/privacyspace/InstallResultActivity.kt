package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast

class InstallResultActivity : Activity() {
    private companion object {
        // Hidden @SystemApi constant; read by its stable platform key without linking hidden SDK APIs.
        const val EXTRA_LEGACY_STATUS = "android.content.pm.extra.LEGACY_STATUS"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "正在等待系统安装结果……"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        })
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(source: Intent) {
        if (source.action != PackageInstallCoordinator.ACTION_INSTALL_STATUS) {
            finish()
            return
        }
        val requestId = source.getStringExtra(PackageInstallCoordinator.EXTRA_INSTALL_REQUEST_ID)
            ?.trim()
            .orEmpty()
        val request = InstallRequestStore.read(this, requestId)
        if (request == null) {
            ProvisioningDiagnostics.record(this, "收到未知安装结果：request=$requestId")
            finish()
            return
        }
        val callbackSessionId = source.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1)
        val callbackPackage = source.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)?.trim().orEmpty()
        if ((callbackSessionId >= 0 && callbackSessionId != request.installerSessionId) ||
            (callbackPackage.isNotBlank() && callbackPackage != request.packageName)
        ) {
            ProvisioningDiagnostics.record(
                this,
                "拒绝不匹配的安装回调：request=$requestId session=$callbackSessionId package=$callbackPackage"
            )
            finish()
            return
        }
        val status = source.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val legacyStatus = source.getIntExtra(EXTRA_LEGACY_STATUS, Int.MIN_VALUE)
            .takeUnless { it == Int.MIN_VALUE }
        val statusMessage = source.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)?.trim()

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> handleUserAction(source, request, legacyStatus, statusMessage)
            PackageInstaller.STATUS_SUCCESS -> verifySuccess(request, status, legacyStatus, statusMessage)
            else -> showFailure(request, status, legacyStatus, statusMessage)
        }
    }

    private fun handleUserAction(
        source: Intent,
        request: InstallRequestStore.Record,
        legacyStatus: Int?,
        statusMessage: String?
    ) {
        InstallRequestStore.updateState(
            this,
            request.requestId,
            InstallRequestStore.STATE_AWAITING_USER,
            status = PackageInstaller.STATUS_PENDING_USER_ACTION,
            legacyStatus = legacyStatus,
            message = statusMessage ?: "等待用户确认安装。"
        )
        val confirmation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            source.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            source.getParcelableExtra(Intent.EXTRA_INTENT)
        }
        if (confirmation == null) {
            showFailure(
                request,
                PackageInstaller.STATUS_FAILURE,
                legacyStatus,
                "系统要求确认安装，但没有返回确认页面。"
            )
            return
        }
        ProvisioningDiagnostics.record(this, "安装等待系统确认：${request.packageName}")
        runCatching {
            confirmation.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(confirmation)
        }.onFailure {
            showFailure(request, PackageInstaller.STATUS_FAILURE, legacyStatus, "无法打开系统安装确认页面：${it.message}")
        }
    }

    private fun verifySuccess(
        request: InstallRequestStore.Record,
        status: Int,
        legacyStatus: Int?,
        statusMessage: String?
    ) {
        Thread {
            val verified = InstalledPackageVerifier.verify(this, request)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                verified.fold(
                    onSuccess = { summary ->
                        InstallRequestStore.updateState(
                            this,
                            request.requestId,
                            InstallRequestStore.STATE_SUCCESS,
                            status = status,
                            legacyStatus = legacyStatus,
                            message = statusMessage ?: "安装成功且版本、签名校验通过。"
                        )
                        ProvisioningDiagnostics.record(
                            this,
                            "正式克隆成功：${request.packageName} version=${summary.versionCode} launch=${summary.canLaunch}"
                        )
                        showSuccess(request, summary)
                    },
                    onFailure = { error ->
                        showFailure(
                            request,
                            PackageInstaller.STATUS_FAILURE_INVALID,
                            legacyStatus,
                            "系统报告安装成功，但安装后校验失败：${error.message}"
                        )
                    }
                )
            }
        }.start()
    }

    private fun showSuccess(request: InstallRequestStore.Record, summary: InstalledPackageVerifier.Summary) {
        val version = summary.versionName.ifBlank { summary.versionCode.toString() }
        val builder = AlertDialog.Builder(this)
            .setTitle("克隆完成")
            .setMessage(
                "${request.label}\n${request.packageName}\n\n" +
                    "版本：$version (${summary.versionCode})\n" +
                    "文件：${request.fileCount} 个\n\n" +
                    "应用已安装到隔离空间，版本与签名校验通过。"
            )
            .setNegativeButton("完成") { _, _ -> finish() }
            .setOnCancelListener { finish() }
        if (summary.canLaunch) {
            builder.setPositiveButton("启动应用") { _, _ ->
                WorkProfileManager(this).launchPackageInThisProfile(this, request.packageName).fold(
                    onSuccess = { finish() },
                    onFailure = {
                        Toast.makeText(this, it.message ?: "无法启动应用", Toast.LENGTH_LONG).show()
                        finish()
                    }
                )
            }
        } else {
            builder.setPositiveButton("知道了") { _, _ -> finish() }
        }
        builder.show()
    }

    private fun showFailure(
        request: InstallRequestStore.Record,
        status: Int,
        legacyStatus: Int?,
        statusMessage: String?
    ) {
        val reason = statusReason(status)
        val details = statusMessage?.takeIf { it.isNotBlank() }
        val combined = buildString {
            append(reason)
            if (details != null && details != reason) append("\n\n系统信息：").append(details)
            legacyStatus?.let { append("\n旧状态码：").append(it) }
        }
        InstallRequestStore.updateState(
            this,
            request.requestId,
            InstallRequestStore.STATE_FAILURE,
            status = status,
            legacyStatus = legacyStatus,
            message = combined
        )
        ProvisioningDiagnostics.record(
            this,
            "正式克隆失败：${request.packageName} status=$status legacy=$legacyStatus message=$combined"
        )
        val builder = AlertDialog.Builder(this)
            .setTitle("克隆失败")
            .setMessage("${request.label}\n${request.packageName}\n\n$combined")
            .setPositiveButton("知道了") { _, _ -> finish() }
            .setOnCancelListener { finish() }
        if (status == PackageInstaller.STATUS_FAILURE_BLOCKED) {
            builder.setNegativeButton("检查安装权限") { _, _ ->
                runCatching {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")
                        )
                    )
                }.onFailure {
                    Toast.makeText(this, "无法打开安装权限设置", Toast.LENGTH_LONG).show()
                }
            }
        }
        builder.show()
    }

    private fun statusReason(status: Int): String = when (status) {
        PackageInstaller.STATUS_FAILURE_BLOCKED -> "系统或设备策略阻止了安装。"
        PackageInstaller.STATUS_FAILURE_ABORTED -> "安装已被用户或系统取消。"
        PackageInstaller.STATUS_FAILURE_INVALID -> "APK 或 split APK 无效、不完整，或安装后校验失败。"
        PackageInstaller.STATUS_FAILURE_CONFLICT -> "与隔离空间中已有版本发生签名、版本或安装来源冲突。"
        PackageInstaller.STATUS_FAILURE_STORAGE -> "隔离空间存储空间不足。"
        PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "应用与当前设备、系统版本或 CPU 架构不兼容。"
        else -> "系统安装失败，状态码：$status。"
    }
}
