package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.xiaxue.privacyspace.AppUi.BG
import com.xiaxue.privacyspace.AppUi.BLUE
import com.xiaxue.privacyspace.AppUi.GREEN
import com.xiaxue.privacyspace.AppUi.ORANGE
import com.xiaxue.privacyspace.AppUi.RED
import com.xiaxue.privacyspace.AppUi.applySystemBars
import com.xiaxue.privacyspace.AppUi.body
import com.xiaxue.privacyspace.AppUi.button
import com.xiaxue.privacyspace.AppUi.card
import com.xiaxue.privacyspace.AppUi.chip
import com.xiaxue.privacyspace.AppUi.dp
import com.xiaxue.privacyspace.AppUi.lp
import com.xiaxue.privacyspace.AppUi.row
import com.xiaxue.privacyspace.AppUi.spacer
import com.xiaxue.privacyspace.AppUi.title

class SetupWizardActivity : Activity() {
    private lateinit var manager: WorkProfileManager
    private var launchedProvisioning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars(this)
        manager = WorkProfileManager(this)
        launchedProvisioning = savedInstanceState?.getBoolean(KEY_PROVISIONING_LAUNCHED, false) ?: false
        buildPage()
    }

    private fun buildPage() {
        val compat = manager.compatibility()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(32), dp(20), dp(34))
            setBackgroundColor(BG)
        }

        root.addView(title(this, "创建独立工作资料空间", 28f).apply { gravity = Gravity.CENTER })
        root.addView(spacer(this, 10))
        root.addView(body(this, "创建完成后，主空间与隔离空间会建立安全配对，用于保护后续克隆和启动指令。", 15f).apply { gravity = Gravity.CENTER })
        root.addView(spacer(this, 22))

        val statusCard = card(this).apply {
            val top = row(this@SetupWizardActivity)
            top.addView(title(this@SetupWizardActivity, "创建前检查", 20f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(chip(this@SetupWizardActivity, if (compat.canCreateProfile) "可以尝试" else "受限", if (compat.canCreateProfile) GREEN else ORANGE))
            addView(top)
            addView(spacer(this@SetupWizardActivity, 14))
            addView(body(this@SetupWizardActivity, "系统支持工作资料：${if (compat.supportsManagedUsers) "是" else "否"}", 14f).apply { setTextColor(if (compat.supportsManagedUsers) GREEN else RED) })
            addView(body(this@SetupWizardActivity, "系统允许创建：${if (compat.provisioningAllowed) "是" else "否"}", 14f).apply { setTextColor(if (compat.provisioningAllowed) GREEN else RED) })
            addView(body(this@SetupWizardActivity, "当前是否 Profile Owner：${if (compat.isProfileOwner) "是" else "否"}", 14f).apply { setTextColor(if (compat.isProfileOwner) ORANGE else GREEN) })
            addView(body(this@SetupWizardActivity, "当前是否 Device Owner：${if (compat.isDeviceOwner) "是" else "否"}", 14f).apply { setTextColor(if (compat.isDeviceOwner) ORANGE else GREEN) })
            addView(body(this@SetupWizardActivity, "关联用户数：${compat.userProfileCount}", 14f).apply { setTextColor(if (compat.userProfileCount > 1) ORANGE else BLUE) })
            addView(body(this@SetupWizardActivity, "最近记录：${ProvisioningDiagnostics.lastEvent(this@SetupWizardActivity)}", 14f).apply { setTextColor(BLUE) })
            addView(body(this@SetupWizardActivity, "设备：${compat.manufacturer} ${compat.model} / Android ${compat.sdk}", 14f).apply { setTextColor(BLUE) })
        }
        root.addView(statusCard, lp())
        root.addView(spacer(this, 16))

        compat.likelyBlockReason()?.let { reason ->
            root.addView(card(this).apply {
                addView(title(this@SetupWizardActivity, "为什么现在不能创建", 18f))
                addView(spacer(this@SetupWizardActivity, 8))
                addView(body(this@SetupWizardActivity, reason, 14f).apply { setTextColor(ORANGE) })
            }, lp())
            root.addView(spacer(this, 16))
        }

        val actionCard = card(this).apply {
            addView(title(this@SetupWizardActivity, "开始设置", 20f))
            addView(spacer(this@SetupWizardActivity, 8))
            addView(body(this@SetupWizardActivity, "点击后会进入 Android 系统设置设备页面。创建完成后，系统会回到本 App 的收尾入口并启用工作资料。", 14f))
            addView(spacer(this@SetupWizardActivity, 16))
            addView(button(this@SetupWizardActivity, "开始创建", true, compat.canCreateProfile) { startProvisioning() }, lp())
            addView(spacer(this@SetupWizardActivity, 10))
            addView(button(this@SetupWizardActivity, "返回首页", false, true) { finish() }, lp())
            addView(spacer(this@SetupWizardActivity, 10))
            addView(button(this@SetupWizardActivity, "打开系统设置", false, true) { openSystemSettings() }, lp())
            addView(spacer(this@SetupWizardActivity, 10))
            addView(button(this@SetupWizardActivity, "复制创建诊断", false, true) { copyDiagnostics() }, lp())
        }
        root.addView(actionCard, lp())

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }

    private fun startProvisioning() {
        if (launchedProvisioning) return
        launchedProvisioning = true
        val intent = manager.createProvisioningIntent()
        ProvisioningDiagnostics.record(this, "启动系统工作资料创建：${intent.action}")
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_PROVISION)
        } catch (e: ActivityNotFoundException) {
            launchedProvisioning = false
            ProvisioningDiagnostics.record(this, "系统没有提供工作资料创建页面", e)
            showError("系统没有提供工作资料创建页面。")
        } catch (e: Throwable) {
            launchedProvisioning = false
            ProvisioningDiagnostics.record(this, "启动工作资料创建失败", e)
            showError(e.message ?: e.javaClass.simpleName)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PROVISION) {
            launchedProvisioning = false
            ProvisioningDiagnostics.record(this, "系统创建页面返回：resultCode=$resultCode")
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "系统已完成创建请求，正在返回首页检查资料状态。", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
            } else {
                showError("系统未完成工作资料创建。可以复制诊断后核查具体原因。")
                buildPage()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(KEY_PROVISIONING_LAUNCHED, launchedProvisioning)
        super.onSaveInstanceState(outState)
    }

    private fun copyDiagnostics() {
        val ok = ProvisioningDiagnostics.copySnapshot(this, manager)
        Toast.makeText(this, if (ok) "已复制创建诊断" else "复制失败", Toast.LENGTH_LONG).show()
    }

    private fun showError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("无法开始创建")
            .setMessage(message)
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun openSystemSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开系统设置", Toast.LENGTH_LONG).show() }
    }

    companion object {
        private const val REQUEST_PROVISION = 201
        private const val KEY_PROVISIONING_LAUNCHED = "provisioning_launched"
    }
}
