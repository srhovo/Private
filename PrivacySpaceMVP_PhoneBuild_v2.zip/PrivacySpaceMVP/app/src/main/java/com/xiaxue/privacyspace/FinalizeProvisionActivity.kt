package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import com.xiaxue.privacyspace.AppUi.BG
import com.xiaxue.privacyspace.AppUi.applySystemBars
import com.xiaxue.privacyspace.AppUi.body
import com.xiaxue.privacyspace.AppUi.button
import com.xiaxue.privacyspace.AppUi.card
import com.xiaxue.privacyspace.AppUi.dp
import com.xiaxue.privacyspace.AppUi.eyebrow
import com.xiaxue.privacyspace.AppUi.lp
import com.xiaxue.privacyspace.AppUi.spacer
import com.xiaxue.privacyspace.AppUi.title

class FinalizeProvisionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(36), dp(20), dp(34))
            setBackgroundColor(BG)
        }
        root.addView(eyebrow(this, "❄️ XiaXue Space"))
        root.addView(spacer(this, 22))
        val done = card(this, 24).apply {
            addView(title(this@FinalizeProvisionActivity, "工作资料已创建", 26f))
            addView(spacer(this@FinalizeProvisionActivity, 12))
            addView(body(this@FinalizeProvisionActivity, "系统已经完成独立工作资料空间的创建。接下来请在工作资料空间中打开“下雪应用隔离”，继续管理工作空间应用。", 15f))
            addView(spacer(this@FinalizeProvisionActivity, 18))
            addView(button(this@FinalizeProvisionActivity, "进入下雪应用隔离", true, true) {
                startActivity(Intent(this@FinalizeProvisionActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                finish()
            }, lp())
        }
        root.addView(done, lp())
        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }
}
