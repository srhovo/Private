package com.xiaxue.privacyspace

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class FinalizeProvisionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val paired = CrossProfileAuth.importProvisioningExtras(this, intent)
        ProvisioningDiagnostics.record(this, "收到 PROVISIONING_SUCCESSFUL · 安全配对=$paired")

        val completed = ProfileSetup.complete(this)
        ProvisioningDiagnostics.record(this, "FinalizeActivity 直接收尾结果：$completed")

        runCatching {
            startActivity(
                Intent(this, DummyActivity::class.java)
                    .setAction(ProvisioningContract.ACTION_FINALIZE_PROVISION)
                    .putExtra(ProvisioningContract.EXTRA_OPEN_MAIN, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }.onFailure {
            ProvisioningDiagnostics.record(this, "启动 DummyActivity 收尾失败，改为直接结束", it)
        }

        setResult(RESULT_OK)
        finish()
    }
}
