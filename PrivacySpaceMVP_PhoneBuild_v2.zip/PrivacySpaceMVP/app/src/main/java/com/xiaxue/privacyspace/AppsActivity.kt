package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.xiaxue.privacyspace.AppUi.BG
import com.xiaxue.privacyspace.AppUi.CARD
import com.xiaxue.privacyspace.AppUi.FILL
import com.xiaxue.privacyspace.AppUi.FILL_2
import com.xiaxue.privacyspace.AppUi.LINE
import com.xiaxue.privacyspace.AppUi.LINE_STRONG
import com.xiaxue.privacyspace.AppUi.MUTED_2
import com.xiaxue.privacyspace.AppUi.PRIMARY
import com.xiaxue.privacyspace.AppUi.SUBTLE
import com.xiaxue.privacyspace.AppUi.TEXT
import com.xiaxue.privacyspace.AppUi.applySystemBars
import com.xiaxue.privacyspace.AppUi.dp
import com.xiaxue.privacyspace.AppUi.rounded

class AppsActivity : Activity() {
    private lateinit var manager: WorkProfileManager
    private lateinit var listView: ListView
    private lateinit var hintView: TextView
    private lateinit var searchBox: EditText
    private lateinit var adapter: AppListAdapter
    private var apps: List<AppEntry> = emptyList()
    private var visibleApps: List<AppEntry> = emptyList()

    data class AppEntry(
        val packageName: String,
        val label: String,
        val icon: Drawable?,
        val installedInCurrentProfile: Boolean,
        val canLaunchInCurrentProfile: Boolean,
        val isSystem: Boolean
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars(this)
        manager = WorkProfileManager(this)
        if (manager.isProfileOwner()) ProfileSetup.complete(this)
        buildPage()
        loadApps()
    }

    private fun buildPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        root.addView(buildSearchHeader(), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        hintView = TextView(this).apply {
            text = "正在读取应用……"
            textSize = 13f
            setTextColor(MUTED_2)
            setPadding(dp(20), dp(4), dp(20), dp(10))
        }
        root.addView(hintView)

        adapter = AppListAdapter()
        listView = ListView(this).apply {
            divider = null
            cacheColorHint = BG
            setBackgroundColor(BG)
            setPadding(0, dp(4), 0, dp(12))
            clipToPadding = false
            this.adapter = this@AppsActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
                val info = visibleApps.getOrNull(position) ?: return@OnItemClickListener
                showAppAction(info)
            }
        }
        root.addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(buildBottomTabs(), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    private fun buildSearchHeader(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(10))
            setBackgroundColor(BG)
        }

        val title = TextView(this).apply {
            text = "应用管理"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, 0, dp(10))
        }
        container.addView(title)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, dp(18), LINE)
            elevation = dp(1).toFloat()
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        top.addView(topIcon("‹", 28f) { finish() }, LinearLayout.LayoutParams(dp(40), dp(46)))

        searchBox = EditText(this).apply {
            hint = "搜索应用名称或包名"
            textSize = 16f
            setSingleLine(true)
            setTextColor(TEXT)
            setHintTextColor(MUTED_2)
            setPadding(dp(8), 0, dp(8), 0)
            background = null
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = filterApps(s?.toString().orEmpty())
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        top.addView(searchBox, LinearLayout.LayoutParams(0, dp(46), 1f))

        top.addView(topIcon("×", 24f) {
            searchBox.setText("")
            searchBox.requestFocus()
            showKeyboard()
        }, LinearLayout.LayoutParams(dp(38), dp(46)))

        top.addView(topIcon("＋", 20f) { showManualCloneDialog() }, LinearLayout.LayoutParams(dp(42), dp(46)))
        top.addView(topIcon("Zz", 14f) { freezeVisibleApps() }, LinearLayout.LayoutParams(dp(42), dp(46)))
        top.addView(topIcon("⋮", 24f) { showMoreMenu() }, LinearLayout.LayoutParams(dp(38), dp(46)))

        container.addView(top)
        return container
    }

    private fun topIcon(text: String, size: Float, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            isClickable = true
            background = rounded(FILL, dp(12))
            setOnClickListener { onClick() }
        }
    }

    private fun buildBottomTabs(): View {
        val profile = manager.isProfileOwner()
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(14))
            setBackgroundColor(BG)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(FILL, dp(18), LINE)
        }
        bar.addView(bottomTab("主空间", !profile) {
            if (profile) {
                Toast.makeText(this, "当前位于隔离空间。这里会尽量显示可克隆到隔离空间的包。", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "当前已在主空间，可搜索后发送克隆请求到隔离空间。", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, dp(46), 1f))

        bar.addView(bottomTab("隔离空间", profile) {
            if (profile) {
                Toast.makeText(this, "当前已在隔离空间。", Toast.LENGTH_SHORT).show()
            } else {
                showCloneGuide(null, null)
            }
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        outer.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return outer
    }

    private fun bottomTab(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(if (selected) android.graphics.Color.WHITE else SUBTLE)
            typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = if (selected) rounded(PRIMARY, dp(14)) else rounded(0x00FFFFFF, dp(14))
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    private fun loadApps() {
        val installed = loadInstalledForCurrentProfile().associateBy { it.packageName }
        val all = loadAllVisiblePackages()
        val source = if (all.size >= installed.size) all else installed.values.toList()

        apps = source.mapNotNull { app ->
            val pkg = app.packageName ?: return@mapNotNull null
            val label = runCatching { app.loadLabel(packageManager).toString() }.getOrDefault(pkg)
            val icon = runCatching { app.loadIcon(packageManager) }.getOrNull()
            val installedHere = installed.containsKey(pkg)
            val launchable = packageManager.getLaunchIntentForPackage(pkg) != null
            AppEntry(
                packageName = pkg,
                label = label,
                icon = icon,
                installedInCurrentProfile = installedHere,
                canLaunchInCurrentProfile = launchable,
                isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }
            .distinctBy { it.packageName }
            .filterNot { it.packageName == packageName && !manager.isProfileOwner() }
            .sortedWith(compareBy<AppEntry> { !it.installedInCurrentProfile }.thenBy { it.label.lowercase() })

        filterApps(searchBox.text?.toString().orEmpty())
    }

    private fun loadInstalledForCurrentProfile(): List<ApplicationInfo> {
        return runCatching { packageManager.getInstalledApplications(0) }.getOrDefault(emptyList())
    }

    private fun loadAllVisiblePackages(): List<ApplicationInfo> {
        val flags = PackageManager.MATCH_UNINSTALLED_PACKAGES or
            PackageManager.MATCH_DISABLED_COMPONENTS or
            PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        return runCatching { packageManager.getInstalledApplications(flags) }
            .onFailure { ProvisioningDiagnostics.record(this, "读取可克隆包列表失败", it) }
            .getOrDefault(emptyList())
    }

    private fun filterApps(query: String) {
        val q = query.trim().lowercase()
        visibleApps = if (q.isEmpty()) {
            apps
        } else {
            apps.filter { info ->
                info.label.lowercase().contains(q) || info.packageName.lowercase().contains(q)
            }
        }
        adapter.notifyDataSetChanged()
        val mode = if (manager.isProfileOwner()) "隔离空间" else "主空间"
        val notInstalled = visibleApps.count { !it.installedInCurrentProfile }
        hintView.text = if (visibleApps.isEmpty()) {
            "没有匹配的应用 · 当前：$mode"
        } else {
            "当前：$mode · 已显示 ${visibleApps.size} / ${apps.size} 个应用 · 可克隆 $notInstalled 个"
        }
    }

    private fun showAppAction(app: AppEntry) {
        val profile = manager.isProfileOwner()
        val cloneText = if (profile) "安装/克隆到隔离空间" else "发送克隆请求到隔离空间"
        val actions = if (profile) {
            arrayOf(cloneText, "启动应用", "冻结/隐藏", "恢复/显示", "卸载", "重置隔离资料", "应用信息")
        } else {
            arrayOf(cloneText, "启动应用", "重置隔离资料", "应用信息")
        }
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setMessage("${app.packageName}\n\n状态：${statusText(app)}\n\n选择要执行的操作：")
            .setItems(actions) { _, which ->
                when (actions[which]) {
                    cloneText -> cloneApp(app.packageName, app.label)
                    "启动应用" -> launchPackage(app.packageName)
                    "冻结/隐藏" -> manager.setPackageHidden(app.packageName, true).reportBoolean("已请求冻结/隐藏") { loadApps() }
                    "恢复/显示" -> manager.setPackageHidden(app.packageName, false).reportBoolean("已请求恢复/显示") { loadApps() }
                    "卸载" -> confirmUninstall(app.packageName, app.label)
                    "重置隔离资料" -> showResetGuide()
                    "应用信息" -> openAppInfo(app.packageName)
                }
            }
            .show()
    }

    private fun statusText(app: AppEntry): String {
        return when {
            app.installedInCurrentProfile && app.canLaunchInCurrentProfile -> "当前空间已安装，可启动"
            app.installedInCurrentProfile -> "当前空间已安装，但未发现启动入口"
            manager.isProfileOwner() -> "未安装到隔离空间，可尝试克隆"
            else -> "主空间应用，可发送到隔离空间克隆"
        }
    }

    private fun cloneApp(packageName: String, label: String) {
        if (manager.isProfileOwner()) {
            manager.cloneExistingPackageToThisProfile(packageName).reportBoolean("已安装/启用到隔离空间") { loadApps() }
        } else {
            manager.openCloneRequestChooser(this, packageName, label).fold(
                onSuccess = { Toast.makeText(this, "请选择带工作资料角标的下雪应用隔离完成克隆。", Toast.LENGTH_LONG).show() },
                onFailure = { showCloneGuide(packageName, label, it.message) }
            )
        }
    }

    private fun showManualCloneDialog() {
        val input = EditText(this).apply {
            hint = "输入包名，例如 com.example.app"
            setSingleLine(true)
            setTextColor(TEXT)
            setHintTextColor(MUTED_2)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("按包名克隆")
            .setMessage("搜索列表没有目标 App 时，可直接输入主空间 App 包名。")
            .setView(input)
            .setPositiveButton("克隆") { _, _ ->
                val pkg = input.text?.toString()?.trim().orEmpty()
                if (pkg.isBlank()) {
                    Toast.makeText(this, "包名不能为空", Toast.LENGTH_LONG).show()
                } else {
                    cloneApp(pkg, pkg)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showCloneGuide(packageName: String?, label: String?, error: String? = null) {
        val target = if (!label.isNullOrBlank() && !packageName.isNullOrBlank()) "\n\n当前选择：$label\n$packageName" else ""
        val err = if (!error.isNullOrBlank()) "\n\n当前错误：$error" else ""
        AlertDialog.Builder(this)
            .setTitle("创建隔离分身")
            .setMessage(
                "隔离分身由工作资料里的本 App 执行安装。\n\n" +
                    "推荐流程：在主空间搜索 App → 选择“发送克隆请求到隔离空间” → 在选择器中点带工作资料角标的“下雪应用隔离”。\n\n" +
                    "如果选择器没有隔离空间入口，请到隔离空间中打开本 App，再用右上角“＋”输入包名克隆。" + target + err
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("回到首页") { _, _ -> startActivity(Intent(this, MainActivity::class.java)) }
            .show()
    }

    private fun showResetGuide() {
        AlertDialog.Builder(this)
            .setTitle("重置隔离资料")
            .setMessage(
                "重置分身资料需要在手机系统设置里手动移除工作资料/分身资料。\n\n" +
                    "推荐路径：\n" +
                    "手机设置 → 用户与账号 / 账号与同步 / 多用户 → 工作资料 / 工作空间 / 分身资料 → 移除工作资料或移除分身资料。\n\n" +
                    "不同手机品牌的名称可能不完全一样。移除后，隔离空间里的应用和数据会被清空；需要重新回到本 App 创建独立工作资料空间。"
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("打开系统设置") { _, _ -> openSystemSettings() }
            .show()
    }

    private fun confirmUninstall(packageName: String, label: String) {
        AlertDialog.Builder(this)
            .setTitle("卸载 $label")
            .setMessage("将从当前空间卸载此应用：\n$packageName")
            .setPositiveButton("卸载") { _, _ ->
                runCatching { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))) }
                    .onFailure { Toast.makeText(this, it.message ?: "无法打开卸载页面", Toast.LENGTH_LONG).show() }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun freezeVisibleApps() {
        if (!manager.isProfileOwner()) {
            Toast.makeText(this, "当前不是隔离空间管理者，不能批量冻结。", Toast.LENGTH_LONG).show()
            return
        }
        val packages = visibleApps
            .filter { it.installedInCurrentProfile && it.packageName != packageName && !isCorePackage(it.packageName) }
            .map { it.packageName }
            .distinct()
        if (packages.isEmpty()) {
            Toast.makeText(this, "当前没有可冻结的应用。", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("批量冻结当前列表")
            .setMessage("将尝试冻结当前搜索结果中的 ${packages.size} 个应用。不会冻结本管理器和核心系统组件。")
            .setPositiveButton("冻结") { _, _ ->
                var ok = 0
                packages.forEach { pkg -> if (manager.setPackageHidden(pkg, true).isSuccess) ok++ }
                Toast.makeText(this, "已请求冻结 $ok / ${packages.size} 个应用", Toast.LENGTH_LONG).show()
                loadApps()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun isCorePackage(packageName: String): Boolean {
        return packageName == this.packageName ||
            packageName == "android" ||
            packageName.startsWith("com.android.systemui") ||
            packageName.startsWith("com.google.android.gms") ||
            packageName.startsWith("com.google.android.webview") ||
            packageName.startsWith("com.android.webview")
    }

    private fun showMoreMenu() {
        val actions = arrayOf("刷新应用列表", "按包名克隆", "重置隔离资料说明", "打开系统设置", "功能限制说明")
        AlertDialog.Builder(this)
            .setTitle("更多")
            .setItems(actions) { _, which ->
                when (actions[which]) {
                    "刷新应用列表" -> loadApps()
                    "按包名克隆" -> showManualCloneDialog()
                    "重置隔离资料说明" -> showResetGuide()
                    "打开系统设置" -> openSystemSettings()
                    "功能限制说明" -> showLimitHelp()
                }
            }
            .show()
    }

    private fun showLimitHelp() {
        AlertDialog.Builder(this)
            .setTitle("功能限制说明")
            .setMessage(
                "当前版本已接入核心克隆链路：主空间搜索目标 App，发送到隔离空间；隔离空间作为 Profile Owner 执行安装/启用。\n\n" +
                    "如果搜索不到目标 App，可使用右上角“＋”按包名克隆。若系统返回未完成安装，通常是包名不存在、主空间未安装，或厂商 ROM 限制跨用户安装。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun launchPackage(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent == null) {
            Toast.makeText(this, "当前空间无法直接启动此应用。", Toast.LENGTH_LONG).show()
        } else {
            startActivity(launchIntent)
        }
    }

    private fun openAppInfo(packageName: String) {
        runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开应用信息", Toast.LENGTH_LONG).show() }
    }

    private fun openSystemSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开系统设置", Toast.LENGTH_LONG).show() }
    }

    private fun showKeyboard() {
        searchBox.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }, 100)
    }

    private fun Result<Boolean>.reportBoolean(successText: String, afterSuccess: () -> Unit = {}) {
        fold(
            onSuccess = { ok ->
                Toast.makeText(this@AppsActivity, if (ok) successText else "系统返回未完成操作", Toast.LENGTH_LONG).show()
                afterSuccess()
            },
            onFailure = { Toast.makeText(this@AppsActivity, it.message ?: it.javaClass.simpleName, Toast.LENGTH_LONG).show() }
        )
    }

    private inner class AppListAdapter : BaseAdapter() {
        override fun getCount(): Int = visibleApps.size
        override fun getItem(position: Int): Any = visibleApps[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val info = visibleApps[position]
            val outer = LinearLayout(this@AppsActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(5), dp(14), dp(5))
                setBackgroundColor(BG)
            }
            val root = LinearLayout(this@AppsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(CARD, dp(18), LINE)
                elevation = dp(1).toFloat()
            }
            val icon = ImageView(this@AppsActivity).apply {
                info.icon?.let { setImageDrawable(it) }
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(FILL_2, dp(14), LINE_STRONG)
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            root.addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))

            val texts = LinearLayout(this@AppsActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, dp(8), 0)
            }
            texts.addView(TextView(this@AppsActivity).apply {
                text = info.label
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(TEXT)
                maxLines = 1
            })
            texts.addView(TextView(this@AppsActivity).apply {
                text = info.packageName
                textSize = 13f
                setTextColor(SUBTLE)
                maxLines = 1
                setPadding(0, dp(3), 0, 0)
            })
            texts.addView(TextView(this@AppsActivity).apply {
                text = statusText(info)
                textSize = 12f
                setTextColor(if (info.installedInCurrentProfile) PRIMARY else MUTED_2)
                maxLines = 1
                setPadding(0, dp(3), 0, 0)
            })
            root.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            root.addView(TextView(this@AppsActivity).apply {
                text = "›"
                textSize = 28f
                setTextColor(MUTED_2)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(24), dp(56)))
            outer.addView(root, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            return outer
        }
    }
}
