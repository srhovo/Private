package com.xiaxue.privacyspace

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.xiaxue.privacyspace.AppUi.BG
import com.xiaxue.privacyspace.AppUi.CARD
import com.xiaxue.privacyspace.AppUi.FILL
import com.xiaxue.privacyspace.AppUi.FILL_2
import com.xiaxue.privacyspace.AppUi.LINE
import com.xiaxue.privacyspace.AppUi.LINE_STRONG
import com.xiaxue.privacyspace.AppUi.MUTED_2
import com.xiaxue.privacyspace.AppUi.PRIMARY
import com.xiaxue.privacyspace.AppUi.SUBTLE
import com.xiaxue.privacyspace.AppUi.TEXT
import com.xiaxue.privacyspace.AppUi.applySystemBars
import com.xiaxue.privacyspace.AppUi.dp
import com.xiaxue.privacyspace.AppUi.rounded

class AppsActivity : Activity() {
    private enum class Space { MAIN, WORK }

    private lateinit var manager: WorkProfileManager
    private lateinit var sourceRepository: ApkSourceRepository
    private lateinit var listView: ListView
    private lateinit var hintView: TextView
    private lateinit var searchBox: EditText
    private lateinit var adapter: AppListAdapter
    private lateinit var mainTab: TextView
    private lateinit var workTab: TextView

    private var currentSpace = Space.MAIN
    private var selectedSpace = Space.MAIN
    private var localApps: List<AppEntry> = emptyList()
    private var remoteApps: List<AppEntry> = emptyList()
    private var visibleApps: List<AppEntry> = emptyList()
    private var remoteSnapshot: ProfileStateSnapshot? = null
    private var firstResume = true
    private val iconCache = LruCache<String, Drawable>(96)

    private data class AppEntry(
        val packageName: String,
        val label: String,
        val icon: Drawable?,
        val space: Space,
        val installed: Boolean,
        val hidden: Boolean,
        val canLaunch: Boolean,
        val isSystem: Boolean,
        val versionName: String,
        val versionCode: Long,
        val splitCount: Int,
        val sourceBytes: Long,
        val sourceReady: Boolean,
        val sourceIssue: String?,
        val otherSpaceState: ProfilePackageState?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars(this)
        manager = WorkProfileManager(this)
        sourceRepository = ApkSourceRepository(this)
        currentSpace = if (manager.isProfileOwner()) Space.WORK else Space.MAIN
        selectedSpace = currentSpace
        ProfileSetup.configureCrossProfileReceiversForCurrentProfile(this)
        if (manager.isProfileOwner()) ProfileSetup.complete(this)
        buildPage()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        if (firstResume) {
            firstResume = false
        } else {
            loadApps()
        }
    }

    private fun buildPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        root.addView(
            buildSearchHeader(),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        hintView = TextView(this).apply {
            text = "正在读取应用……"
            textSize = 13f
            setTextColor(MUTED_2)
            setPadding(dp(20), dp(4), dp(20), dp(10))
        }
        root.addView(hintView)

        adapter = AppListAdapter()
        listView = ListView(this).apply {
            divider = null
            cacheColorHint = BG
            setBackgroundColor(BG)
            setPadding(0, dp(4), 0, dp(12))
            clipToPadding = false
            this.adapter = this@AppsActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
                val info = visibleApps.getOrNull(position) ?: return@OnItemClickListener
                showAppAction(info)
            }
        }
        root.addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(
            buildBottomTabs(),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        setContentView(root)
    }

    private fun buildSearchHeader(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(10))
            setBackgroundColor(BG)
        }

        val title = TextView(this).apply {
            text = "应用管理"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, 0, dp(10))
        }
        container.addView(title)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, dp(18), LINE)
            elevation = dp(1).toFloat()
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        top.addView(topIcon("‹", 28f) { finish() }, LinearLayout.LayoutParams(dp(40), dp(46)))

        searchBox = EditText(this).apply {
            hint = "搜索应用名称或包名"
            textSize = 16f
            setSingleLine(true)
            setTextColor(TEXT)
            setHintTextColor(MUTED_2)
            setPadding(dp(8), 0, dp(8), 0)
            background = null
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                    filterApps(s?.toString().orEmpty())
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        top.addView(searchBox, LinearLayout.LayoutParams(0, dp(46), 1f))

        top.addView(topIcon("×", 24f) {
            searchBox.setText("")
            searchBox.requestFocus()
            showKeyboard()
        }, LinearLayout.LayoutParams(dp(38), dp(46)))

        top.addView(topIcon("＋", 20f) { showManualCloneDialog() }, LinearLayout.LayoutParams(dp(42), dp(46)))
        top.addView(topIcon("Zz", 14f) { freezeVisibleApps() }, LinearLayout.LayoutParams(dp(42), dp(46)))
        top.addView(topIcon("⋮", 24f) { showMoreMenu() }, LinearLayout.LayoutParams(dp(38), dp(46)))

        container.addView(top)
        return container
    }

    private fun topIcon(text: String, size: Float, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
            gravity = Gravity.CENTER
            isClickable = true
            background = rounded(FILL, dp(12))
            setOnClickListener { onClick() }
        }
    }

    private fun buildBottomTabs(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(14))
            setBackgroundColor(BG)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(FILL, dp(18), LINE)
        }
        mainTab = bottomTab("主空间") { selectSpace(Space.MAIN) }
        workTab = bottomTab("隔离空间") { selectSpace(Space.WORK) }
        bar.addView(mainTab, LinearLayout.LayoutParams(0, dp(46), 1f))
        bar.addView(workTab, LinearLayout.LayoutParams(0, dp(46), 1f))
        outer.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        updateTabs()
        return outer
    }

    private fun bottomTab(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    private fun updateTabs() {
        if (!::mainTab.isInitialized || !::workTab.isInitialized) return
        styleTab(mainTab, selectedSpace == Space.MAIN)
        styleTab(workTab, selectedSpace == Space.WORK)
    }

    private fun styleTab(tab: TextView, selected: Boolean) {
        tab.setTextColor(if (selected) android.graphics.Color.WHITE else SUBTLE)
        tab.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tab.background = if (selected) rounded(PRIMARY, dp(14)) else rounded(0x00FFFFFF, dp(14))
    }

    private fun selectSpace(space: Space) {
        selectedSpace = space
        updateTabs()
        filterApps(searchBox.text?.toString().orEmpty())
        if (space != currentSpace && remoteSnapshot == null) {
            requestRemoteSync(force = true)
        }
    }

    private fun loadApps(forceRemoteSync: Boolean = false) {
        hintView.text = "正在读取主空间与隔离空间状态……"
        Thread {
            val result = runCatching {
                PackageInstallCoordinator.reconcileStale(this)
                val localStateSnapshot = ProfileStateRepository(this).capture("local-state")
                val localStateMap = localStateSnapshot.packages.associateBy { it.packageName }
                val inventory = sourceRepository.loadInventory()
                    .distinctBy { it.packageName }
                    .filterNot { it.packageName == packageName && currentSpace == Space.MAIN }
                val inventoryMap = inventory.associateBy { it.packageName }

                val local = buildList {
                    inventory.forEach { item ->
                        val state = localStateMap[item.packageName]
                        val app = item.applicationInfo
                        add(
                            AppEntry(
                                packageName = item.packageName,
                                label = item.label,
                                icon = loadIcon(currentSpace, item.packageName) { app.loadIcon(packageManager) },
                                space = currentSpace,
                                installed = true,
                                hidden = state?.hidden ?: false,
                                canLaunch = state?.launchable
                                    ?: (packageManager.getLaunchIntentForPackage(item.packageName) != null),
                                isSystem = state?.system ?: false,
                                versionName = item.versionName,
                                versionCode = item.versionCode,
                                splitCount = item.splitCount,
                                sourceBytes = item.sourceBytes,
                                sourceReady = item.sourceReady,
                                sourceIssue = item.sourceIssue,
                                otherSpaceState = null
                            )
                        )
                    }
                    localStateSnapshot.packages
                        .filter { it.installed && it.packageName !in inventoryMap }
                        .forEach { state ->
                            add(
                                AppEntry(
                                    packageName = state.packageName,
                                    label = state.label,
                                    icon = loadIcon(currentSpace, state.packageName) {
                                        @Suppress("DEPRECATION")
                                        packageManager.getApplicationInfo(state.packageName, 0).loadIcon(packageManager)
                                    },
                                    space = currentSpace,
                                    installed = true,
                                    hidden = state.hidden,
                                    canLaunch = state.launchable,
                                    isSystem = state.system,
                                    versionName = state.versionName,
                                    versionCode = state.versionCode,
                                    splitCount = 0,
                                    sourceBytes = 0L,
                                    sourceReady = false,
                                    sourceIssue = "当前空间无法读取 APK 来源",
                                    otherSpaceState = null
                                )
                            )
                        }
                }.distinctBy { it.packageName }

                val remote = ProfileStateStore.read(this)
                    ?.takeIf { it.profileOwner != manager.isProfileOwner() }
                val remoteMap = remote?.packages?.associateBy { it.packageName }.orEmpty()
                val localMap = local.associateBy { it.packageName }
                val localWithOther = local.map { entry ->
                    entry.copy(otherSpaceState = remoteMap[entry.packageName])
                }.sortedWith(compareBy<AppEntry> { it.hidden }.thenBy { it.label.lowercase() })
                val remoteSpace = if (currentSpace == Space.MAIN) Space.WORK else Space.MAIN
                val remoteEntries = remote?.packages.orEmpty()
                    .filter { it.installed }
                    .map { state ->
                        val localMatch = localMap[state.packageName]
                        AppEntry(
                            packageName = state.packageName,
                            label = state.label,
                            icon = localMatch?.icon,
                            space = remoteSpace,
                            installed = state.installed,
                            hidden = state.hidden,
                            canLaunch = state.launchable,
                            isSystem = state.system,
                            versionName = state.versionName,
                            versionCode = state.versionCode,
                            splitCount = 0,
                            sourceBytes = 0L,
                            sourceReady = false,
                            sourceIssue = null,
                            otherSpaceState = localStateMap[state.packageName]
                        )
                    }
                    .sortedWith(compareBy<AppEntry> { it.hidden }.thenBy { it.label.lowercase() })
                Triple(localWithOther, remoteEntries, remote)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                result.fold(
                    onSuccess = { (local, remote, snapshot) ->
                        localApps = local
                        remoteApps = remote
                        remoteSnapshot = snapshot
                        filterApps(searchBox.text?.toString().orEmpty())
                        requestRemoteSync(forceRemoteSync)
                    },
                    onFailure = { error ->
                        localApps = emptyList()
                        remoteApps = emptyList()
                        visibleApps = emptyList()
                        adapter.notifyDataSetChanged()
                        hintView.text = "读取应用失败：${error.message ?: error.javaClass.simpleName}"
                        ProvisioningDiagnostics.record(this, "读取双侧应用状态失败", error)
                    }
                )
            }
        }.start()
    }

    private fun requestRemoteSync(force: Boolean) {
        val compat = manager.compatibility()
        if (!compat.hasRelatedProfile || !CrossProfileAuth.hasKey(this)) return
        manager.requestRemoteSnapshot(this, force).onFailure { error ->
            if (selectedSpace != currentSpace) {
                hintView.text = "远端状态同步失败：${error.message ?: error.javaClass.simpleName}"
            }
        }
    }

    private fun loadIcon(space: Space, packageName: String, loader: () -> Drawable): Drawable? {
        val key = "${space.name}:$packageName"
        iconCache.get(key)?.let { return it }
        return runCatching { loader() }.getOrNull()?.also { iconCache.put(key, it) }
    }

    private fun filterApps(query: String) {
        val q = query.trim().lowercase()
        val source = if (selectedSpace == currentSpace) localApps else remoteApps
        visibleApps = if (q.isEmpty()) {
            source
        } else {
            source.filter { info ->
                info.label.lowercase().contains(q) || info.packageName.lowercase().contains(q)
            }
        }
        adapter.notifyDataSetChanged()
        updateHint(source.size)
    }

    private fun updateHint(total: Int) {
        val selectedName = if (selectedSpace == Space.MAIN) "主空间" else "隔离空间"
        hintView.text = when {
            selectedSpace != currentSpace && remoteSnapshot == null ->
                "正在同步${selectedName}真实状态……"
            visibleApps.isEmpty() ->
                "没有匹配的应用 · 当前查看：$selectedName"
            selectedSpace == currentSpace && currentSpace == Space.MAIN -> {
                val sourceReady = visibleApps.count { it.sourceReady }
                "当前查看：$selectedName · 已显示 ${visibleApps.size} / $total 个 · APK 来源可用 $sourceReady 个"
            }
            selectedSpace != currentSpace -> {
                val age = ((System.currentTimeMillis() - ProfileStateStore.receivedAt(this)) / 1000L).coerceAtLeast(0L)
                "当前查看：$selectedName · 已显示 ${visibleApps.size} / $total 个 · 远端状态 ${age} 秒前同步"
            }
            else -> "当前查看：$selectedName · 已显示 ${visibleApps.size} / $total 个"
        }
    }

    private fun showAppAction(app: AppEntry) {
        hideKeyboard()
        searchBox.clearFocus()

        val selectedIsLocal = selectedSpace == currentSpace
        val actions = when {
            selectedSpace == Space.MAIN && selectedIsLocal ->
                listOf("发送到隔离空间克隆", "启动主空间应用", "重置隔离资料", "应用信息")
            selectedSpace == Space.WORK && selectedIsLocal -> buildList {
                add("启动隔离应用")
                add(if (app.hidden) "恢复/显示" else "冻结/隐藏")
                add("卸载隔离应用")
                add("重置隔离资料")
                add("应用信息")
            }
            selectedSpace == Space.WORK -> buildList {
                add("在隔离空间启动")
                add(if (app.hidden) "恢复隔离分身" else "冻结隔离分身")
                add("卸载隔离分身")
                add("同步双侧状态")
            }
            else -> listOf("在主空间启动", "同步双侧状态")
        }

        val dialog = AlertDialog.Builder(this).create()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(16))
        }
        root.addView(TextView(this).apply {
            text = app.label
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(TEXT)
        })
        root.addView(TextView(this).apply {
            text = app.packageName
            textSize = 15f
            setTextColor(SUBTLE)
            setPadding(0, dp(8), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "状态：${statusText(app)}"
            textSize = 15f
            setTextColor(TEXT)
            setPadding(0, dp(14), 0, dp(10))
        })
        actions.forEach { action ->
            root.addView(actionButton(action) {
                dialog.dismiss()
                when (action) {
                    "发送到隔离空间克隆" -> cloneApp(app.packageName, app.label)
                    "启动主空间应用", "启动隔离应用" -> launchLocalPackage(app.packageName)
                    "在隔离空间启动", "在主空间启动" -> remoteLaunch(app)
                    "冻结/隐藏" -> localHidden(app, true)
                    "恢复/显示" -> localHidden(app, false)
                    "冻结隔离分身" -> remoteHidden(app, true)
                    "恢复隔离分身" -> remoteHidden(app, false)
                    "卸载隔离应用" -> confirmLocalUninstall(app)
                    "卸载隔离分身" -> confirmRemoteUninstall(app)
                    "同步双侧状态" -> loadApps(forceRemoteSync = true)
                    "重置隔离资料" -> showResetGuide()
                    "应用信息" -> openAppInfo(app.packageName)
                }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
                topMargin = dp(8)
            })
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(root, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        dialog.setView(scroll)
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        dialog.show()
    }

    private fun actionButton(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val primary = text.contains("克隆") || text.contains("启动")
            setTextColor(if (primary) android.graphics.Color.WHITE else TEXT)
            background = rounded(if (primary) PRIMARY else FILL, dp(14), LINE)
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    private fun statusText(app: AppEntry): String {
        val version = app.versionName.ifBlank { app.versionCode.takeIf { it > 0L }?.toString().orEmpty() }
        val versionText = if (version.isBlank()) "" else " · v$version"
        val current = when {
            !app.installed -> "未安装"
            app.hidden -> "已冻结"
            app.canLaunch -> "已安装，可启动"
            else -> "已安装，无启动入口"
        }
        val otherName = if (app.space == Space.MAIN) "隔离" else "主空间"
        val other = app.otherSpaceState?.let { state ->
            when {
                !state.installed -> "未安装"
                state.hidden -> "已冻结"
                state.launchable -> "已安装"
                else -> "已安装无入口"
            }
        } ?: "待同步"
        val source = if (app.space == Space.MAIN && currentSpace == Space.MAIN && selectedSpace == currentSpace) {
            if (app.sourceReady) {
                val split = if (app.splitCount > 0) " · ${app.splitCount} 个 split" else " · 单 APK"
                "$split · ${formatBytes(app.sourceBytes)}"
            } else " · APK 来源不可用"
        } else ""
        return "$current$versionText$source · $otherName：$other"
    }

    private fun cloneApp(packageName: String, label: String) {
        if (currentSpace != Space.MAIN) {
            Toast.makeText(this, "请切换到主空间中的本 App 发起克隆。", Toast.LENGTH_LONG).show()
            return
        }
        val compat = manager.compatibility()
        if (compat.hasRelatedProfile && !CrossProfileAuth.hasKey(this)) {
            showLegacyProfileMigration()
            return
        }
        val progress = AlertDialog.Builder(this)
            .setTitle("正在准备 APK 来源")
            .setMessage("正在校验 base APK、split APK、版本、签名与文件摘要，请勿关闭页面。")
            .setCancelable(false)
            .create()
        progress.show()
        Thread {
            val prepared = sourceRepository.prepare(packageName, label)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                progress.dismiss()
                prepared.fold(
                    onSuccess = { descriptor ->
                        ProfileSetup.configureCrossProfileReceiversForCurrentProfile(this)
                        ProvisioningDiagnostics.record(
                            this,
                            "主空间发起 APK 来源请求：${descriptor.packageName} files=${descriptor.files.size} bytes=${descriptor.totalBytes}"
                        )
                        manager.openCloneRequestChooser(this, descriptor).fold(
                            onSuccess = {
                                Toast.makeText(this, "已发送到隔离空间，请按系统提示完成安装。", Toast.LENGTH_LONG).show()
                            },
                            onFailure = { showCloneGuide(packageName, label, it.message) }
                        )
                    },
                    onFailure = { showCloneGuide(packageName, label, it.message) }
                )
            }
        }.start()
    }

    private fun localHidden(app: AppEntry, hidden: Boolean) {
        manager.setPackageHidden(app.packageName, hidden).reportBoolean(
            if (hidden) "已冻结/隐藏" else "已恢复/显示"
        ) { loadApps(forceRemoteSync = true) }
    }

    private fun remoteHidden(app: AppEntry, hidden: Boolean) {
        manager.requestRemoteHidden(this, app.packageName, app.label, hidden).fold(
            onSuccess = {
                Toast.makeText(this, if (hidden) "已发送冻结请求" else "已发送恢复请求", Toast.LENGTH_LONG).show()
            },
            onFailure = { Toast.makeText(this, it.message ?: "远程状态修改失败", Toast.LENGTH_LONG).show() }
        )
    }

    private fun remoteLaunch(app: AppEntry) {
        manager.requestRemoteLaunch(this, app.packageName, app.label).fold(
            onSuccess = { Toast.makeText(this, "正在切换到目标空间启动应用", Toast.LENGTH_SHORT).show() },
            onFailure = { Toast.makeText(this, it.message ?: "无法启动远端应用", Toast.LENGTH_LONG).show() }
        )
    }

    private fun launchLocalPackage(packageName: String) {
        manager.launchPackageInThisProfile(this, packageName).onFailure {
            Toast.makeText(this, it.message ?: "当前空间无法启动此应用", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmLocalUninstall(app: AppEntry) {
        val packageName = app.packageName
        manager.protectedReason(packageName)?.let { reason ->
            showProtectedDialog(app, reason)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("卸载 ${app.label}")
            .setMessage("将从隔离空间卸载此应用：\n${app.packageName}")
            .setPositiveButton("卸载") { _, _ ->
                PackageUninstallCoordinator.submit(this, app.packageName, app.label).fold(
                    onSuccess = { Toast.makeText(this, "已提交卸载，请按系统提示确认。", Toast.LENGTH_LONG).show() },
                    onFailure = { Toast.makeText(this, it.message ?: "无法提交卸载", Toast.LENGTH_LONG).show() }
                )
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmRemoteUninstall(app: AppEntry) {
        AlertDialog.Builder(this)
            .setTitle("卸载隔离分身")
            .setMessage("将从隔离空间卸载：\n${app.label}\n${app.packageName}")
            .setPositiveButton("卸载") { _, _ ->
                manager.requestRemoteUninstall(this, app.packageName, app.label).fold(
                    onSuccess = { Toast.makeText(this, "已发送卸载请求", Toast.LENGTH_LONG).show() },
                    onFailure = { Toast.makeText(this, it.message ?: "无法发送卸载请求", Toast.LENGTH_LONG).show() }
                )
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showProtectedDialog(app: AppEntry, reason: String) {
        AlertDialog.Builder(this)
            .setTitle("已阻止操作")
            .setMessage("${app.label}\n${app.packageName}\n\n$reason。为避免损坏工作资料，不能操作此组件。")
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return "%.1f MB".format(mb)
        return "%.2f GB".format(mb / 1024.0)
    }

    private fun showLegacyProfileMigration() {
        AlertDialog.Builder(this)
            .setTitle("需要重新创建隔离资料")
            .setMessage(
                "检测到设备中已有旧版本创建的工作资料，但主空间与隔离空间尚未建立新版安全配对。为避免克隆指令被伪造或发送到错误目标，本版本不会自动降级绕过认证。\n\n" +
                    "请先在系统设置中移除旧工作资料/分身资料，再回到首页使用当前版本重新创建。移除旧资料会清空其中的应用和数据，请先确认没有需要保留的内容。"
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("打开系统设置") { _, _ -> openSystemSettings() }
            .show()
    }

    private fun showManualCloneDialog() {
        if (currentSpace != Space.MAIN) {
            Toast.makeText(this, "按包名克隆需要在主空间中的本 App 操作。", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            hint = "输入包名，例如 com.example.app"
            setSingleLine(true)
            setTextColor(TEXT)
            setHintTextColor(MUTED_2)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("按包名克隆")
            .setMessage("搜索列表没有目标 App 时，可直接输入主空间 App 包名。")
            .setView(input)
            .setPositiveButton("克隆") { _, _ ->
                val pkg = input.text?.toString()?.trim().orEmpty()
                if (pkg.isBlank()) {
                    Toast.makeText(this, "包名不能为空", Toast.LENGTH_LONG).show()
                } else {
                    cloneApp(pkg, pkg)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showCloneGuide(packageName: String?, label: String?, error: String? = null) {
        val target = if (!label.isNullOrBlank() && !packageName.isNullOrBlank()) {
            if (label == packageName) "\n\n当前选择：$label" else "\n\n当前选择：$label\n$packageName"
        } else ""
        val err = if (!error.isNullOrBlank()) "\n\n当前错误：$error" else ""
        AlertDialog.Builder(this)
            .setTitle("创建隔离分身")
            .setMessage(
                "当前版本会从主空间读取 base/split APK、版本和签名，在隔离空间边写入 PackageInstaller Session 边核对大小与 SHA-256。\n\n" +
                    "推荐流程：在主空间搜索 App → 选择“发送到隔离空间克隆” → 根据系统提示确认安装。\n\n" +
                    "如果没有隔离空间入口，请先在两个空间分别打开一次本 App。" + target + err
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("回到首页") { _, _ -> startActivity(Intent(this, MainActivity::class.java)) }
            .show()
    }

    private fun showResetGuide() {
        AlertDialog.Builder(this)
            .setTitle("重置隔离资料")
            .setMessage(
                "重置分身资料需要在手机系统设置里手动移除工作资料/分身资料。\n\n" +
                    "推荐路径：\n" +
                    "手机设置 → 用户与账号 / 账号与同步 / 多用户 → 工作资料 / 工作空间 / 分身资料 → 移除工作资料或移除分身资料。\n\n" +
                    "不同手机品牌的名称可能不完全一样。移除后，隔离空间里的应用和数据会被清空。"
            )
            .setPositiveButton("知道了", null)
            .setNegativeButton("打开系统设置") { _, _ -> openSystemSettings() }
            .show()
    }

    private fun freezeVisibleApps() {
        if (currentSpace != Space.WORK || selectedSpace != Space.WORK) {
            Toast.makeText(this, "批量冻结需要在隔离空间中的本 App 操作。", Toast.LENGTH_LONG).show()
            return
        }
        val packages = visibleApps
            .filter { it.installed && !it.hidden && manager.protectedReason(it.packageName) == null }
            .map { it.packageName }
            .distinct()
        if (packages.isEmpty()) {
            Toast.makeText(this, "当前没有可冻结的应用。", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("批量冻结当前列表")
            .setMessage("将尝试冻结当前搜索结果中的 ${packages.size} 个应用。不会冻结本管理器和核心系统组件。")
            .setPositiveButton("冻结") { _, _ ->
                Thread {
                    var ok = 0
                    var refused = 0
                    var failed = 0
                    packages.forEach { pkg ->
                        val result = manager.setPackageHidden(pkg, true)
                        when {
                            result.getOrNull() == true -> ok++
                            result.isSuccess -> refused++
                            else -> failed++
                        }
                    }
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            "冻结完成：成功 $ok，系统拒绝 $refused，失败 $failed，共 ${packages.size} 个",
                            Toast.LENGTH_LONG
                        ).show()
                        loadApps(forceRemoteSync = true)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showMoreMenu() {
        val actions = arrayOf("刷新当前列表", "同步双侧状态", "按包名克隆", "重置隔离资料说明", "打开系统设置", "功能限制说明")
        AlertDialog.Builder(this)
            .setTitle("更多")
            .setItems(actions) { _, which ->
                when (actions[which]) {
                    "刷新当前列表" -> loadApps()
                    "同步双侧状态" -> loadApps(forceRemoteSync = true)
                    "按包名克隆" -> showManualCloneDialog()
                    "重置隔离资料说明" -> showResetGuide()
                    "打开系统设置" -> openSystemSettings()
                    "功能限制说明" -> showLimitHelp()
                }
            }
            .show()
    }

    private fun showLimitHelp() {
        AlertDialog.Builder(this)
            .setTitle("功能限制说明")
            .setMessage(
                "当前版本已完成 Android 11+ 创建基线、跨资料指令认证、base/split APK 正式安装，以及主空间/隔离空间双侧状态同步。\n\n" +
                    "主空间可查看并启动、冻结、恢复或卸载隔离分身；工作资料可查看主空间状态并启动主空间副本。部分厂商系统仍可能要求手动确认安装或卸载。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun openAppInfo(packageName: String) {
        runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开应用信息", Toast.LENGTH_LONG).show() }
    }

    private fun openSystemSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .onFailure { Toast.makeText(this, it.message ?: "无法打开系统设置", Toast.LENGTH_LONG).show() }
    }

    private fun hideKeyboard() {
        runCatching {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        }
    }

    private fun showKeyboard() {
        searchBox.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }, 100)
    }

    private fun Result<Boolean>.reportBoolean(successText: String, afterSuccess: () -> Unit = {}) {
        fold(
            onSuccess = { ok ->
                Toast.makeText(this@AppsActivity, if (ok) successText else "系统返回未完成操作", Toast.LENGTH_LONG).show()
                if (ok) afterSuccess()
            },
            onFailure = { Toast.makeText(this@AppsActivity, it.message ?: it.javaClass.simpleName, Toast.LENGTH_LONG).show() }
        )
    }

    private data class AppRowHolder(
        val icon: ImageView,
        val label: TextView,
        val packageName: TextView,
        val status: TextView
    )

    private inner class AppListAdapter : BaseAdapter() {
        override fun getCount(): Int = visibleApps.size
        override fun getItem(position: Int): Any = visibleApps[position]
        override fun getItemId(position: Int): Long = visibleApps[position].packageName.hashCode().toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val info = visibleApps[position]
            val root: View
            val holder: AppRowHolder
            if (convertView == null) {
                val outer = LinearLayout(this@AppsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(5), dp(14), dp(5))
                    setBackgroundColor(BG)
                }
                val row = LinearLayout(this@AppsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = rounded(CARD, dp(18), LINE)
                    elevation = dp(1).toFloat()
                }
                val icon = ImageView(this@AppsActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rounded(FILL_2, dp(14), LINE_STRONG)
                    setPadding(dp(6), dp(6), dp(6), dp(6))
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))

                val texts = LinearLayout(this@AppsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), 0, dp(8), 0)
                }
                val label = TextView(this@AppsActivity).apply {
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(TEXT)
                    maxLines = 1
                }
                val packageName = TextView(this@AppsActivity).apply {
                    textSize = 13f
                    setTextColor(SUBTLE)
                    maxLines = 1
                    setPadding(0, dp(3), 0, 0)
                }
                val status = TextView(this@AppsActivity).apply {
                    textSize = 13f
                    setTextColor(MUTED_2)
                    maxLines = 2
                    setPadding(0, dp(4), 0, 0)
                }
                texts.addView(label)
                texts.addView(packageName)
                texts.addView(status)
                row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(TextView(this@AppsActivity).apply {
                    text = "›"
                    textSize = 24f
                    setTextColor(MUTED_2)
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(28), dp(56)))
                outer.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                holder = AppRowHolder(icon, label, packageName, status)
                outer.tag = holder
                root = outer
            } else {
                root = convertView
                holder = convertView.tag as AppRowHolder
            }
            holder.icon.setImageDrawable(info.icon)
            holder.label.text = info.label
            holder.packageName.text = info.packageName
            holder.status.text = statusText(info)
            holder.label.alpha = if (info.hidden) 0.58f else 1f
            holder.icon.alpha = if (info.hidden) 0.45f else 1f
            return root
        }
    }
}
