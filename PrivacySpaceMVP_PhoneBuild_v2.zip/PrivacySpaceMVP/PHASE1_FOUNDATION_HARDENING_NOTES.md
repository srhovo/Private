# 阶段 1：基础边界与安全加固完成记录

版本：`0.7.0-foundation-hardening`  
阶段状态：源码修改完成，静态回归通过；Android 实际编译与真机回归待 GitHub Actions/设备执行。

## 一、修改前链路风险

1. 跨资料克隆入口导出，但声明的签名权限没有真正绑定到组件。
2. 请求没有来源认证、时间窗或防重放，第三方可能构造相同 action。
3. 转发器仅按“不是自己包名”筛选，可能选择第三方伪造入口。
4. `LAUNCH_PACKAGE` 会落入克隆逻辑。
5. 未实现的 `START_SERVICE` 被公开注册，服务本身仅为空 Binder。
6. 首页/应用页反复执行收尾，可能反复清空并重建跨资料过滤器。
7. 冻结和卸载缺少完整核心包保护。
8. 批量冻结会把 DevicePolicyManager 返回 `false` 计为成功。
9. 旧工作资料升级后双方没有共同密钥，容易出现静默失败或不安全降级。

## 二、本阶段完成

- `minSdk 24 → 30`，停止 Android 7/8 兼容。
- 版本升级为 `0.7.0-foundation-hardening (16)`。
- 新增 `CrossProfileAuth.kt`：
  - 创建资料时通过 admin extras 下发 256-bit 随机密钥；
  - HMAC-SHA256 指令签名；
  - 两分钟有效时间窗；
  - nonce 防重放与有限缓存；
  - 已存在密钥不允许被不同值覆盖。
- 新增 `ProtectedPackages.kt`：
  - 静态保护常见系统核心包；
  - 动态保护 Profile Owner、Device Owner、桌面、设置、安装器、权限控制器和常驻系统 App。
- `WorkProfileManager.kt`：
  - 创建 Intent 注入安全配对信息；
  - 发出跨资料请求前签名；
  - 只选择系统 UID / 平台签名转发器；
  - 克隆与启动使用独立方法；
  - 冻结统一走保护策略。
- `CloneRequestActivity.kt`：
  - 先验证 Profile Owner 和 HMAC；
  - 严格 action 分流；
  - 未签名、过期、篡改、重放和未知请求全部拒绝。
- `ProfileSetup.kt`：
  - 配置版本化；
  - 收尾幂等；
  - 只注册真实存在的克隆/启动过滤器；
  - 组合校验接收入口、过滤器和资料启用结果。
- 删除未使用 `IsolationService`、`START_SERVICE` action 和 `FOREGROUND_SERVICE` 权限。
- 首页显示“安全配对”状态。
- 发现旧版未配对工作资料时阻止克隆并给出重建提示。
- 单个与批量冻结/卸载均接入核心包保护。
- GitHub Actions 在 Android 构建前执行静态回归。

## 三、验收结果

`tools/phase1_static_regression.py`：121 项通过，0 项失败。

覆盖：

- Gradle 系统边界；
- Manifest 组件和导出状态；
- 死权限/死 action 清理；
- HMAC、时间戳、nonce、防重放；
- 系统转发器筛选；
- action 分流；
- 收尾幂等；
- 核心包保护；
- 旧资料迁移阻断；
- Kotlin 轻量分隔符检查；
- Manifest 类引用完整性；
- CI 静态回归接入。

## 四、未完成与诚实边界

- 当前环境没有 Android SDK 和 Gradle，未能在本地真实执行 `assembleDebug`。
- GitHub Actions 已具备完整 Android 35 构建配置，上传后会先跑静态回归，再执行编译。
- `installExistingPackage()` 仍只是旧兼容路径；普通第三方 App 的 base/split APK 正式安装尚未完成。
- 旧工作资料必须移除并用新版重建，才能建立安全配对。不会自动绕过认证。

## 五、下一阶段

阶段 2 只推进一个主项目：**主空间应用清单与 APK 来源层**。

验收重点：

- 主空间真实应用可稳定枚举；
- base APK 与所有 split APK 均可定位；
- 包名、版本、签名摘要、文件数量和大小一致；
- 文件资源在成功、失败和取消路径都正确释放；
- 不提前宣称安装完成。
