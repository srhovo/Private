# Phase 5：对照 Shelter 真实源码，找到路由这一步的真正原因

## 结论先行

第 4 阶段的两个防御性加固（发起前重新禁用、误触发时自我修复）方向没错，但没有打到根上。根上的问题是：**克隆请求发出去之后，"该由谁来接住"这一步，代码里赌的是系统会自动选对，而不是明确指定。** Shelter（`net.typeblog.shelter`，也就是那个"防检测"apk 的真身）从源头上就没有赌这件事。

## 对照方法

用户上传的原 apk 早前已确认就是开源项目 Shelter（PeterCxy/Shelter，GitHub 上公开源码）。这次直接把它的 `Utility.java` 和 `DummyActivity.java` 源码拉出来对照，而不是靠反编译猜。

## 关键差异

我们的 `openCloneRequestChooser()`（改之前）：
```kotlin
val request = Intent(ACTION_CLONE_PACKAGE).apply { ... }
activity.startActivity(request)   // 裸的隐式 Intent，赌系统解析到隔离空间
```

Shelter 的 `Utility.transferIntentToProfileUnsigned()`（真实源码，一字不差）：
```java
public static void transferIntentToProfileUnsigned(Context context, Intent intent) {
    PackageManager pm = context.getPackageManager();
    List<ResolveInfo> info = pm.queryIntentActivities(intent, 0);
    Optional<ResolveInfo> i = info.stream()
        .filter((r) -> !r.activityInfo.packageName.equals(context.getPackageName()))
        .findFirst();
    if (i.isPresent()) {
        intent.setComponent(new ComponentName(i.get().activityInfo.packageName, i.get().activityInfo.name));
    } else {
        throw new IllegalStateException("Cannot find an intent in other profile");
    }
}
```

Shelter **主动查询**所有能处理这个 Intent 的候选者，**明确剔除跟自己同包名的本地候选**，把剩下的候选（系统提供的跨资料转发入口）**显式设成 Intent 的目标组件**，然后才调用 `startActivity()`。它完全不依赖"本地接收组件有没有被禁用成功"这件事——查出来的候选只要不是自己的包名，就必然是转发入口。

我们的做法完全反过来：丢一个裸隐式 Intent，指望"只要本地接收方被禁用了，系统自然会转发过去"。这在部分设备/系统版本上不稳定——你这台 vivo 上，Profile Owner 已经确认是 true 了，但克隆请求还是会直接命中主空间自己那一份，而不是被转发。这也是为什么前几轮"重新申请禁用"之类的加固始终没能根治：问题根本不在禁用状态对不对，而在于路由这一步从设计上就没有把"选中谁"这件事握在自己手里。

## 本次修复

`WorkProfileManager.openCloneRequestChooser()` 改成跟 Shelter 完全一致的做法：查询候选 → 剔除同包名 → 显式 `setComponent` → 再 `startActivity`。查不到任何跨资料候选时，直接抛出清晰的错误（对应"没有找到隔离空间接收入口"），不再依赖捕获 `ActivityNotFoundException` 去猜。

第 4 阶段加的"发起前重新禁用本地接收组件""误触发时自我修复"予以保留——不冲突，属于良性的额外保险，但不再是路由是否正确的决定性因素。

## 还没验证、需要如实说明的一点

Shelter 真正把 App"安装进"隔离空间那一步（`DummyActivity.actionInstallPackage()`），做法比我们复杂很多：它没有用 `DevicePolicyManager.installExistingPackage()`，而是通过 `FileProviderProxy` 把主空间那份 APK 的文件描述符转发过去，在隔离空间里用 `PackageInstaller` 重新走一遍安装流程。

我们现在用的 `dpm.installExistingPackage(admin, pkg)` 是一个更简单的公开 API，语义上更适合"这个包在系统里已经存在、只是没在当前用户装"的场景（比如预置系统应用），对于"主空间用户自己装的普通第三方 App，隔离空间从没见过"这种情况，是否总能生效没有把握——如果本次路由修好之后，克隆请求能正确送到隔离空间了，但 `installExistingPackage` 本身返回失败或没反应，那大概率就是需要改成参照 Shelter 那套"转发文件描述符 + PackageInstaller 重装"的方案，那是一次更大的改动，等确认这一步真的卡住了再做，不提前猜。

## 验证方法

装上这版后重新测一次搜索克隆。如果这次卡在"克隆请求完成"或"克隆请求失败"（复制诊断里能看到，因为 `cloneExistingPackageToThisProfile` 每次都会记录），说明路由已经修好，问题转移到了安装这一步本身——把那条记录发我，再针对性处理。

## 版本

`0.6.5-shelter-routing-fix` (15)。ZIP 根目录仍为 `PrivacySpaceMVP/`，workflow 路径不变。
