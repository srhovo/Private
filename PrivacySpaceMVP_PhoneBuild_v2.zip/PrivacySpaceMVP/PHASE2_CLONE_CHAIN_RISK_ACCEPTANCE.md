# Phase 2 Clone Core

## 链路
主空间应用列表 -> 选择目标包 -> 发送跨资料克隆 Intent -> 隔离空间 CloneRequestActivity -> Profile Owner 调用 installExistingPackage -> 刷新/打开隔离 App。

## 风险
1. 厂商 ROM 可能限制跨资料 Intent，保留隔离空间内按包名克隆兜底。
2. 工作资料内可能不能枚举主空间全部包，新增 QUERY_ALL_PACKAGES 和 MATCH_UNINSTALLED_PACKAGES，同时保留手动包名入口。
3. 批量冻结可能误伤核心组件，加入核心包保护。
4. 自定义跨资料指令有被外部调用风险，使用 signature 级自定义权限限制。

## 验收点
1. 已创建工作资料后，主空间能搜索目标 App 并发起克隆请求。
2. 选择带工作资料角标的下雪应用隔离后，隔离空间执行 installExistingPackage。
3. 隔离空间能通过搜索或手动包名克隆主空间已有 App。
4. 克隆成功后目标 App 在隔离空间可启动。


## v0.6.1 compile-fix

链路：应用列表读取需要同时列出当前空间已安装包和系统可见包，供主空间搜索后发送到隔离空间克隆。

风险：`PackageManager` 常量未导入会导致 Kotlin 编译失败；只修导入和版本号，不改变克隆业务链路。

验收：`AppsActivity.kt` 包含 `android.content.pm.PackageManager` 导入；版本号为 `0.6.1-clone-compile-fix`；ZIP 根目录仍为 `PrivacySpaceMVP/`；workflow 路径不变。
