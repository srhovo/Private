# 下雪应用隔离 v0.5.0 深度核查报告

核查时间：自动静态核查

## 结论

当前工程是 v0.5.0 最新版，核心 UI 与功能源码存在。原压缩包存在一个严重结构问题：`app/`、`settings.gradle.kts`、`build.gradle.kts` 被放进了 `PrivacySpaceMVP/PrivacySpaceMVP_compilefix/` 子目录，而外部 GitHub Actions 通常会在 `PrivacySpaceMVP/` 目录执行构建，因此可能继续失败。已在本修复包中改为正确结构：`PrivacySpaceMVP/app/`、`PrivacySpaceMVP/settings.gradle.kts`、`PrivacySpaceMVP/build.gradle.kts`。

## 已修复

1. 修复 ZIP 目录结构，避免工作流找不到正确 Gradle 根目录。
2. 保留稳定 Gradle 配置，不再使用 `VariantOutputImpl` 修改 APK 文件名。
3. 保留 `setPackageHidden(...): Result<Boolean>`，修复 Kotlin 返回类型不匹配。
4. 保留去除 `LIGHT_NAVIGATION_BAR` 的版本，降低系统 UI flag 的编译兼容风险。
5. 检查 Manifest 中声明的 Activity/Receiver 类均存在。
6. 检查 Manifest 引用的 string 资源均存在。
7. 检查 Kotlin 文件包名一致，基础大括号匹配。

## 仍需真机验证

1. 工作资料创建是否被手机 ROM 允许。
2. 工作资料创建完成后，Profile Owner 状态是否成功生效。
3. `installExistingPackage` 是否能在目标机型上完成隔离空间内安装。
4. 冻结/恢复接口是否受系统限制。
5. 卸载流程目前是系统确认式卸载，不是静默卸载。
6. 应用列表目前显示可启动应用，不是完整系统包列表。

## 功能边界

当前版本保留合法的应用隔离、工作资料管理、搜索、应用操作弹窗、冻结/恢复、卸载和重置隔离资料说明。不包含设备伪装、规避检测或反作弊绕过逻辑。
