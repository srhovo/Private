# Phase 5：Android 公共 SDK 编译修复

## 触发证据

GitHub Actions 在 `:app:compileDebugKotlin` 阶段报告：

- `InstallResultActivity.kt`：`EXTRA_LEGACY_STATUS` 无法解析。
- `ProtectedPackages.kt`：`permissionControllerPackageName` 无法解析。

这两项都存在于完整 Android 平台实现类型中，但不属于普通应用可链接的 Android 35 公共 SDK，因此此前基于 `android-all` 的独立类型编译未能发现。

## 修复

1. 安装 legacy status 继续作为可选诊断字段读取，但使用 AOSP 稳定 extra key：`android.content.pm.extra.LEGACY_STATUS`。
2. 权限控制器保护逻辑改用公开 `PackageManager.checkPermission`，检查 `GRANT_RUNTIME_PERMISSIONS` 与 `REVOKE_RUNTIME_PERMISSIONS` 特权。
3. 阶段 5 发布门禁加入隐藏 API 回归检查。
4. 版本升级为 `0.7.5-lifecycle-state-public-sdk-fix`（21）。

## 验收

- 阶段 1–5 静态门禁全部通过。
- 两个修改文件完成 Kotlin 定向类型编译。
- 下一证据等级：GitHub Actions Android 35 公共 SDK 完整 `assembleDebug`。
