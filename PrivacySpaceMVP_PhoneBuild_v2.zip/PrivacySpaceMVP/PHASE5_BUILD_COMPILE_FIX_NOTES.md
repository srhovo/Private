# Phase 5：构建编译热修与发布产物加固

## 本轮目标

不扩展业务功能，不调整 UI，只处理阶段 5 的确定性发布阻断和 CI 产物可靠性。

## 已发现的真实编译阻断

使用 Android 15 完整 API 类型包对全部 Kotlin 源码进行独立类型编译时，确认多处 `Context.getSystemService(Class)` 返回值被直接当作非空对象使用。Kotlin 按 Android API 的可空声明拒绝编译，涉及：

- `DevicePolicyManager`
- `UserManager`
- `ClipboardManager`

资源生成类 `R` 在独立编译环境中缺失属于预期现象，不是工程源码错误。

## 已修复

- `ProfileSetup`：设备策略服务缺失时记录诊断并安全退出；接收组件角色判断改为空安全。
- `ProfileStateRepository`：隐藏状态查询改为空安全。
- `ProtectedPackages`：Profile Owner / Device Owner 检查改为空安全。
- `ProvisioningDiagnostics`：用户资料数量与剪贴板调用增加明确空安全处理。
- `WorkProfileManager`：构造时明确校验设备策略服务；用户资料数量查询增加回退值。

## CI 加固

- 新增 `tools/phase5_release_regression.py`。
- 阶段 1–5 门禁全部在 `assembleDebug` 前执行。
- Gradle 构建改为 `--no-daemon`，降低一次性 CI 残留风险。
- 构建后必须且只能存在一个 debug APK。
- APK 必须为非空文件。
- 统一复制为 `PrivacySpaceMVP-debug.apk`。
- 同步生成 `SHA256SUMS.txt`。
- 上传阶段缺少文件时直接失败，不再产生空产物。

## 验证证据

- 修改前全量 Android 15 API 类型编译：确认 14 处系统服务空安全编译错误。
- 修改后核心数据/认证层独立类型编译：通过。
- 修改后 APK 来源、生命周期、安装/卸载、跨资料管理服务层独立类型编译：通过。
- 修改后 `ProfileSetup` 独立类型编译：通过。
- 阶段 5 发布门禁：69 项通过。
- 阶段 1–4 旧门禁需继续保持全部通过。

## 尚未完成

- 当前容器没有 Android SDK/Gradle 构建环境，不能在本地生成真实 APK。
- 必须由 GitHub Actions 实际运行 `assembleDebug`，以确认 Android Gradle Plugin、资源生成和 Manifest 合并全部通过。
- Android 13–16 及 vivo/OriginOS 的创建、克隆、启动、冻结、恢复、卸载仍需真机验证。

## 版本

`0.7.5-lifecycle-state-public-sdk-fix`（21）


## GitHub Actions 首次真实编译反馈修复

GitHub Actions 的 Android 35 公共 SDK 编译进一步发现两处 `android-all` 完整平台类型包无法暴露的隐藏 API 误用：

- `PackageInstaller.EXTRA_LEGACY_STATUS`：属于隐藏 `@SystemApi`。保留诊断能力，但改为读取平台稳定 extra key 字符串，不再链接隐藏符号。
- `PackageManager.permissionControllerPackageName`：不在应用可用的公共 SDK 中。改为通过公开的 `PackageManager.checkPermission` 判断运行时权限授予/撤销特权，继续保护 OEM 权限控制器。

阶段 5 门禁新增对应防回归检查，禁止上述隐藏符号重新进入源码。
