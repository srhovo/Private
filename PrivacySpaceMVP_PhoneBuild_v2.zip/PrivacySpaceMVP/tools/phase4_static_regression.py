#!/usr/bin/env python3
"""PrivacySpaceMVP 0.7.3 phase-4 lifecycle/state static regression."""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SRC = APP / "src/main/java/com/xiaxue/privacyspace"
MANIFEST = APP / "src/main/AndroidManifest.xml"
GRADLE = APP / "build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"
ANDROID = "{http://schemas.android.com/apk/res/android}"
passes: list[str] = []
failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    (passes if condition else failures).append(name if condition or not detail else f"{name}: {detail}")


def read(path: Path) -> str:
    check(f"file exists: {path.relative_to(ROOT)}", path.is_file())
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def balanced(path: Path) -> None:
    source = read(path)
    cleaned = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    cleaned = re.sub(r"//.*", "", cleaned)
    cleaned = re.sub(r'"(?:\\.|[^"\\])*"', '""', cleaned)
    for opening, closing, label in [("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")]:
        depth = 0
        valid = True
        for char in cleaned:
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth < 0:
                    valid = False
                    break
        check(f"Kotlin {label}: {path.name}", valid and depth == 0, f"depth={depth}")


gradle = read(GRADLE)
version_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
check("phase-4 versionCode is at least 19", bool(version_match and int(version_match.group(1)) >= 19))
check("phase-4 lifecycle versionName is present", "lifecycle-state" in gradle)
check("minSdk remains API 30", "minSdk = 30" in gradle)
check("targetSdk remains API 35", "targetSdk = 35" in gradle)

manifest_text = read(MANIFEST)
try:
    root = ET.fromstring(manifest_text)
    check("manifest XML parses", True)
except Exception as exc:
    root = None
    check("manifest XML parses", False, str(exc))

if root is not None:
    activities = {node.get(ANDROID + "name"): node for node in root.findall("application/activity")}
    for name in [".CloneRequestActivity", ".ParentRequestActivity", ".ProfileStateResultActivity", ".UninstallResultActivity"]:
        check(f"manifest declares {name}", name in activities)
    clone = activities.get(".CloneRequestActivity")
    parent = activities.get(".ParentRequestActivity")
    result = activities.get(".ProfileStateResultActivity")
    uninstall = activities.get(".UninstallResultActivity")
    if clone is not None:
        actions = {a.get(ANDROID + "name") for a in clone.findall("intent-filter/action")}
        for action in [
            "com.xiaxue.privacyspace.action.LAUNCH_PACKAGE",
            "com.xiaxue.privacyspace.action.SET_PACKAGE_HIDDEN",
            "com.xiaxue.privacyspace.action.UNINSTALL_PACKAGE",
            "com.xiaxue.privacyspace.action.QUERY_WORK_PROFILE",
        ]:
            check(f"work receiver handles {action.rsplit('.', 1)[-1]}", action in actions)
        check("work receiver starts disabled until role detection", clone.get(ANDROID + "enabled") == "false")
    if parent is not None:
        actions = {a.get(ANDROID + "name") for a in parent.findall("intent-filter/action")}
        check("parent receiver handles parent query", "com.xiaxue.privacyspace.action.QUERY_PARENT_PROFILE" in actions)
        check("parent receiver handles parent launch", "com.xiaxue.privacyspace.action.LAUNCH_PARENT_PACKAGE" in actions)
        check("parent receiver starts disabled until role detection", parent.get(ANDROID + "enabled") == "false")
        check("parent receiver is transparent", parent.get(ANDROID + "theme") == "@style/TransparentActivityTheme")
    if result is not None:
        actions = {a.get(ANDROID + "name") for a in result.findall("intent-filter/action")}
        check("profile-state result action declared", "com.xiaxue.privacyspace.action.PROFILE_STATE_RESULT" in actions)
        check("profile-state result is transparent", result.get(ANDROID + "theme") == "@style/TransparentActivityTheme")
        check("profile-state result has no history", result.get(ANDROID + "noHistory") == "true")
    if uninstall is not None:
        check("uninstall callback is not exported", uninstall.get(ANDROID + "exported") == "false")
        check("uninstall callback is singleTop", uninstall.get(ANDROID + "launchMode") == "singleTop")

contract = read(SRC / "ProvisioningContract.kt")
for token in [
    "ACTION_LAUNCH_PARENT_PACKAGE", "ACTION_SET_PACKAGE_HIDDEN", "ACTION_UNINSTALL_PACKAGE",
    "ACTION_QUERY_WORK_PROFILE", "ACTION_QUERY_PARENT_PROFILE", "ACTION_PROFILE_STATE_RESULT",
    "EXTRA_STATE_REQUEST_ID", "EXTRA_REQUESTED_HIDDEN", "EXTRA_PROFILE_STATE_JSON", "EXTRA_PROFILE_STATE_SHA256",
]:
    check(f"contract contains {token}", token in contract)

auth = read(SRC / "CrossProfileAuth.kt")
for token in ["EXTRA_STATE_REQUEST_ID", "EXTRA_REQUESTED_HIDDEN", "EXTRA_PROFILE_STATE_SHA256", "hasExtra"]:
    check(f"HMAC covers lifecycle field {token}", token in auth)
check("HMAC does not sign raw state instead of digest", "EXTRA_PROFILE_STATE_JSON" not in auth)

setup = read(SRC / "ProfileSetup.kt")
check("profile setup config version advanced", "CURRENT_CONFIG_VERSION = 3" in setup)
for token in [
    "ACTION_SET_PACKAGE_HIDDEN", "ACTION_UNINSTALL_PACKAGE", "ACTION_QUERY_WORK_PROFILE",
    "ACTION_LAUNCH_PARENT_PACKAGE", "ACTION_QUERY_PARENT_PROFILE", "ACTION_PROFILE_STATE_RESULT",
    "FLAG_MANAGED_CAN_ACCESS_PARENT", "FLAG_PARENT_CAN_ACCESS_MANAGED",
    "configureCrossProfileReceiversForCurrentProfile",
]:
    check(f"profile setup contains {token}", token in setup)
check("state result filter is bidirectional", "FLAG_MANAGED_CAN_ACCESS_PARENT or" in setup and "FLAG_PARENT_CAN_ACCESS_MANAGED" in setup)
check("work command receiver enabled only for owner", "CloneRequestActivity::class.java) to isOwner" in setup)
check("parent command receiver enabled only outside owner", "ParentRequestActivity::class.java) to !isOwner" in setup)
check("state result receiver enabled in both profiles", "ProfileStateResultActivity::class.java) to true" in setup)

models = read(SRC / "ProfileStateModels.kt")
for token in [
    "ProfilePackageState", "ProfileStateSnapshot", "schemaVersion", "fullInventory", "MAX_PACKAGES",
    "validationError", "installed", "hidden", "launchable", "versionCode", "sha256Text",
]:
    check(f"profile state models contain {token}", token in models)
check("profile state rejects impossible missing state", "!state.installed && (state.hidden || state.launchable)" in models)
check("profile state rejects duplicate packages", "状态列表包含重复包名" in models)
check("profile state raw size is bounded", "700_000" in models)

repository = read(SRC / "ProfileStateRepository.kt")
for token in [
    "getInstalledApplications", "FLAG_INSTALLED", "MATCH_DISABLED_COMPONENTS", "isApplicationHidden",
    "getLaunchIntentForPackage", "fullInventory", "ProvisioningDiagnostics.history",
]:
    check(f"state repository contains {token}", token in repository)
check("state repository excludes manager itself", "filterNot { it.packageName == context.packageName }" in repository)
check("missing selected package is reported not installed", "installed = false" in repository)

store = read(SRC / "ProfileStateStore.kt")
for token in [
    "beginRequest", "expectedProfileOwner", "PENDING_TTL_MS", "SNAPSHOT_FRESH_MS", "accept",
    "snapshot.profileOwner != expectedProfileOwner", "fullInventory", "cancelRequest", "purgePending",
]:
    check(f"state store contains {token}", token in store)
check("partial snapshots merge by package", "updates = snapshot.packages.associateBy" in store and "retained + snapshot.packages" in store)
check("accepted result consumes pending request", ".remove(KEY_PENDING_PREFIX + snapshot.requestId)" in store)

result = read(SRC / "ProfileStateResultActivity.kt")
for token in [
    "CrossProfileAuth.verify", "MessageDigest.isEqual", "sha256Text", "ProfileStateSnapshot.fromJson",
    "snapshot.requestId != requestId", "ProfileStateStore.accept", "finishQuietly",
]:
    check(f"state result receiver contains {token}", token in result)

manager = read(SRC / "WorkProfileManager.kt")
for token in [
    "launchPackageInThisProfile", "requestRemoteSnapshot", "requestRemoteLaunch", "requestRemoteHidden",
    "requestRemoteUninstall", "sendProfileStateResult", "ProfileStateStore.beginRequest",
    "ACTION_QUERY_PARENT_PROFILE", "ACTION_QUERY_WORK_PROFILE", "ACTION_PROFILE_STATE_RESULT",
    "isTrustedSystemForwarder", "CrossProfileAuth.sign",
]:
    check(f"manager contains {token}", token in manager)
check("remote lifecycle command creates tracked result request", "openRemoteCommand" in manager and "ProfileStateStore.beginRequest" in manager)
check("remote launch is also state-tracked", "return openRemoteCommand(activity, action, packageName, label, null)" in manager)
check("launch preparation is separated from foreground switch", "prepareLaunchIntentInThisProfile" in manager)
check("failed remote request cancels pending result", "ProfileStateStore.cancelRequest" in manager)
check("launch restores hidden work app before launch", "isApplicationHidden" in manager and "setApplicationHidden(admin, pkg, false)" in manager)
check("work profile cannot modify parent lifecycle", "工作资料管理器不能冻结主空间应用" in manager and "工作资料管理器不能卸载主空间应用" in manager)

parent = read(SRC / "ParentRequestActivity.kt")
check("parent request verifies HMAC", "CrossProfileAuth.verify" in parent)
check("parent request refuses work-profile role", "manager.isProfileOwner()" in parent)
check("parent request handles state query", "ACTION_QUERY_PARENT_PROFILE" in parent and "sendSnapshot" in parent)
check("parent request handles launch", "ACTION_LAUNCH_PARENT_PACKAGE" in parent and "prepareLaunchIntentInThisProfile" in parent)
check("parent launch returns state before target switch", "sendSnapshot(requestId, setOf(packageName)) {\n                                startActivity(launchIntent)" in parent)
check("parent snapshot work runs off UI thread", "Thread {" in parent and "runOnUiThread" in parent)

clone = read(SRC / "CloneRequestActivity.kt")
for token in [
    "ACTION_QUERY_WORK_PROFILE", "ACTION_SET_PACKAGE_HIDDEN", "ACTION_UNINSTALL_PACKAGE",
    "handleHidden", "handleUninstall", "sendStateResult", "PackageUninstallCoordinator.submit",
    "ProfileStateRepository", "CrossProfileAuth.verify",
]:
    check(f"work request receiver contains {token}", token in clone)
check("hidden command requires explicit boolean", "hasExtra(ProvisioningContract.EXTRA_REQUESTED_HIDDEN)" in clone)
check("hidden command responds on success and failure", clone.count("sendStateResult(requestId, setOf(packageName))") >= 3)
check("non-clone commands use transparent theme", "setTheme(R.style.TransparentActivityTheme)" in clone)
check("work launch returns restored state before target switch", "sendStateResult(requestId, setOf(packageName)) {\n                        startActivity(launchIntent)" in clone)

lifecycle_store = read(SRC / "LifecycleRequestStore.kt")
for token in ["SecureRandom", "callbackToken", "remoteStateRequestId", "RETENTION_MS", "MAX_RECORDS", "updateState", "purge", "trim"]:
    check(f"lifecycle store contains {token}", token in lifecycle_store)

uninstall = read(SRC / "PackageUninstallCoordinator.kt")
for token in [
    "packageInstaller", "uninstall", "PendingIntent.FLAG_MUTABLE", "UninstallResultActivity::class.java",
    "protectedReason", "callbackToken", "remoteStateRequestId",
]:
    check(f"uninstall coordinator contains {token}", token in uninstall)
check("uninstall requires work-profile owner", "!manager.isProfileOwner()" in uninstall)
check("uninstall does not use untracked ACTION_DELETE", "Intent.ACTION_DELETE" not in uninstall)
check("uninstall PendingIntent mutability is Android-11 guarded", "Build.VERSION.SDK_INT >= Build.VERSION_CODES.S" in uninstall and "mutabilityFlag" in uninstall)

uninstall_result = read(SRC / "UninstallResultActivity.kt")
for token in [
    "MessageDigest.isEqual", "EXTRA_PACKAGE_NAME", "STATUS_PENDING_USER_ACTION", "STATUS_SUCCESS",
    "STATUS_FAILURE_ABORTED", "STATUS_FAILURE_BLOCKED", "STATUS_FAILURE_CONFLICT",
    "finishAfterRemoteState", "ProfileStateRepository", "sendProfileStateResult", "completing",
]:
    check(f"uninstall result contains {token}", token in uninstall_result)
check("uninstall record remains until remote response attempt", uninstall_result.index("finishAfterRemoteState(record)") < uninstall_result.index("LifecycleRequestStore.remove(this, record.operationId)"))
check("remote response continuation returns to UI thread", "runOnUiThread" in uninstall_result and "continuation()" in uninstall_result)

apps = read(SRC / "AppsActivity.kt")
for token in [
    "enum class Space", "selectSpace", "currentSpace", "selectedSpace", "remoteSnapshot", "ProfileStateStore.read",
    "requestRemoteSnapshot", "requestRemoteLaunch", "requestRemoteHidden", "requestRemoteUninstall",
    "主空间", "隔离空间", "LruCache", "convertView", "Holder", "Thread {", "runOnUiThread",
]:
    check(f"apps UI contains {token}", token in apps)
check("bottom tabs invoke real selection", "bottomTab(\"主空间\") { selectSpace(Space.MAIN) }" in apps and "bottomTab(\"隔离空间\") { selectSpace(Space.WORK) }" in apps)
check("old fake tab toast removed", "已经在主空间页面" not in apps and "工作资料列表" not in apps)
check("local and remote lists are distinct", "localApps" in apps and "remoteApps" in apps)
check("icon cache is keyed by profile and package", '"${space.name}:$packageName"' in apps)
check("adapter reuses convertView", "convertView ?:" in apps or "if (convertView == null)" in apps)
check("batch freeze is restricted to local work profile", "currentSpace != Space.WORK || selectedSpace != Space.WORK" in apps)
check("main-to-work clone remains available", "发送到隔离空间克隆" in apps and "openCloneRequestChooser" in apps)

# diagnostics must merge remote history rather than only local state
diagnostics = read(SRC / "ProvisioningDiagnostics.kt")
check("diagnostics includes remote snapshot history", "ProfileStateStore.read(context)" in diagnostics and "远端同步" in diagnostics)

workflow = read(WORKFLOW)
check("workflow runs phase-4 regression", "phase4_static_regression.py" in workflow)
check("phase-4 regression runs before assembleDebug", workflow.find("phase4_static_regression.py") < workflow.find(":app:assembleDebug"))

# Kotlin permits Unicode identifiers; `$name中文` is parsed as one identifier and can break compilation.
for kotlin_file in SRC.glob("*.kt"):
    for line_no, line in enumerate(kotlin_file.read_text(encoding="utf-8").splitlines(), 1):
        if "$" not in line:
            continue
        risky = re.search(r"\$[A-Za-z_][A-Za-z0-9_]*[\u3400-\u9fff]", line)
        check(f"safe string interpolation: {kotlin_file.name}:{line_no}", risky is None, line.strip())

changed_files = [
    "AppsActivity.kt", "CloneRequestActivity.kt", "CrossProfileAuth.kt", "LifecycleRequestStore.kt",
    "PackageUninstallCoordinator.kt", "ParentRequestActivity.kt", "ProfileSetup.kt", "ProfileStateModels.kt",
    "ProfileStateRepository.kt", "ProfileStateResultActivity.kt", "ProfileStateStore.kt", "ProvisioningContract.kt",
    "ProvisioningDiagnostics.kt", "UninstallResultActivity.kt", "WorkProfileManager.kt",
]
for name in changed_files:
    balanced(SRC / name)

if root is not None:
    for tag in ["activity", "receiver", "provider"]:
        for node in root.findall(f"application/{tag}"):
            name = node.get(ANDROID + "name")
            if not name or not name.startswith("."):
                continue
            check(f"manifest class exists: {name}", (SRC / f"{name[1:]}.kt").is_file())

for line in passes:
    print(f"  [OK] {line}")
print(f"PASS: {len(passes)}")
if failures:
    print(f"FAIL: {len(failures)}")
    for line in failures:
        print(f"  [FAIL] {line}")
    sys.exit(1)
print("RESULT: ALL PHASE-4 STATIC REGRESSION CHECKS PASSED")
