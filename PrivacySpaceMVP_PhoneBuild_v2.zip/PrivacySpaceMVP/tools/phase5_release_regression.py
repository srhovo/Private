#!/usr/bin/env python3
"""PrivacySpaceMVP phase-5 build/release static regression.

Stdlib-only release gate. It does not replace AGP compilation or device testing.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java/com/xiaxue/privacyspace"
GRADLE = ROOT / "app/build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"

passes: list[str] = []
failures: list[str] = []


def read(path: Path) -> str:
    if not path.is_file():
        failures.append(f"file missing: {path.relative_to(ROOT)}")
        return ""
    passes.append(f"file exists: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        passes.append(name)
    else:
        failures.append(f"{name}: {detail}" if detail else name)


gradle = read(GRADLE)
workflow = read(WORKFLOW)
profile_setup = read(SRC / "ProfileSetup.kt")
profile_state = read(SRC / "ProfileStateRepository.kt")
protected = read(SRC / "ProtectedPackages.kt")
diagnostics = read(SRC / "ProvisioningDiagnostics.kt")
manager = read(SRC / "WorkProfileManager.kt")

version_code = re.search(r"versionCode\s*=\s*(\d+)", gradle)
check("phase-5 versionCode is at least 21", bool(version_code and int(version_code.group(1)) >= 21))
check("public-SDK fix versionName is present", "public-sdk-fix" in gradle)
check("minimum SDK remains API 30", "minSdk = 30" in gradle)
check("target SDK remains API 35", "targetSdk = 35" in gradle)

check(
    "ProfileSetup handles missing DevicePolicyManager",
    "系统缺少设备策略服务" in profile_setup
    and "getSystemService(DevicePolicyManager::class.java) ?: run" in profile_setup,
)
check(
    "profile receiver role check is null-safe",
    "?.isProfileOwnerApp(context.packageName) == true" in profile_setup,
)
check(
    "profile state hidden query is null-safe",
    "dpm?.isApplicationHidden(admin, packageName) == true" in profile_state,
)
check(
    "protected package owner checks are null-safe",
    "dpm?.isProfileOwnerApp(pkg) == true" in protected
    and "dpm?.isDeviceOwnerApp(pkg) == true" in protected,
)
check(
    "hidden PackageManager permission-controller API is not linked",
    "permissionControllerPackageName" not in protected
    and "GRANT_RUNTIME_PERMISSIONS" in protected
    and "REVOKE_RUNTIME_PERMISSIONS" in protected,
)
install_result = read(SRC / "InstallResultActivity.kt")
check(
    "hidden PackageInstaller legacy-status API is not linked",
    "PackageInstaller.EXTRA_LEGACY_STATUS" not in install_result
    and '"android.content.pm.extra.LEGACY_STATUS"' in install_result,
)
check(
    "diagnostic user service is null-safe",
    "?.userProfiles?.size ?: -1" in diagnostics,
)
check(
    "diagnostic clipboard service has explicit failure",
    "系统剪贴板服务不可用" in diagnostics,
)
check(
    "manager requires DevicePolicyManager explicitly",
    "requireNotNull(" in manager and "系统缺少设备策略服务" in manager,
)
check(
    "manager user service is null-safe",
    "?.userProfiles?.size ?: 1" in manager,
)

phase_steps = [
    "phase1_static_regression.py",
    "phase2_static_regression.py",
    "phase3_static_regression.py",
    "phase4_static_regression.py",
    "phase5_release_regression.py",
]
for step in phase_steps:
    check(f"workflow runs {step}", step in workflow)

build_pos = workflow.find(":app:assembleDebug")
check("assembleDebug remains configured", build_pos >= 0)
for step in phase_steps:
    step_pos = workflow.find(step)
    check(f"{step} runs before assembleDebug", 0 <= step_pos < build_pos)

for token in [
    "--no-daemon",
    "Expected exactly one debug APK",
    "test -s",
    "PrivacySpaceMVP-debug.apk",
    "sha256sum",
    "SHA256SUMS.txt",
    "if-no-files-found: error",
]:
    check(f"release workflow contains {token}", token in workflow)

# Prevent the exact nullable service regression from returning.
unsafe_service_call = re.compile(
    r"getSystemService\([^\n]+::class\.java\)\s*\.\s*[A-Za-z_]"
)
for source in sorted(SRC.glob("*.kt")):
    text = source.read_text(encoding="utf-8")
    check(
        f"no direct nullable service dereference: {source.name}",
        unsafe_service_call.search(text) is None,
    )

print(f"PASS: {len(passes)}")
for item in passes:
    print(f"  [OK] {item}")
if failures:
    print(f"FAIL: {len(failures)}")
    for item in failures:
        print(f"  [FAIL] {item}")
    sys.exit(1)
print("RESULT: ALL PHASE-5 RELEASE REGRESSION CHECKS PASSED")
