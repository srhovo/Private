#!/usr/bin/env python3
"""PrivacySpaceMVP 0.7.2 phase-3 PackageInstaller static regression."""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SRC = APP / "src/main/java/com/xiaxue/privacyspace"
MANIFEST = APP / "src/main/AndroidManifest.xml"
GRADLE = APP / "build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"
ANDROID = "{http://schemas.android.com/apk/res/android}"
passes: list[str] = []
failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    (passes if condition else failures).append(name if condition or not detail else f"{name}: {detail}")


def read(path: Path) -> str:
    check(f"file exists: {path.relative_to(ROOT)}", path.is_file())
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def balanced(path: Path) -> None:
    source = read(path)
    cleaned = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    cleaned = re.sub(r"//.*", "", cleaned)
    cleaned = re.sub(r'"(?:\\.|[^"\\])*"', '""', cleaned)
    for opening, closing, label in [("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")]:
        depth = 0
        valid = True
        for char in cleaned:
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth < 0:
                    valid = False
                    break
        check(f"Kotlin {label}: {path.name}", valid and depth == 0, f"depth={depth}")


gradle = read(GRADLE)
version_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
check("versionCode remains at or above phase-3 baseline", bool(version_match and int(version_match.group(1)) >= 18))
check("versionName remains phase-3 or later", "versionName" in gradle and ("package-installer" in gradle or "lifecycle-state" in gradle))
check("minSdk remains API 30", "minSdk = 30" in gradle)
check("targetSdk remains API 35", "targetSdk = 35" in gradle)

manifest_text = read(MANIFEST)
try:
    root = ET.fromstring(manifest_text)
    check("manifest XML parses", True)
except Exception as exc:
    root = None
    check("manifest XML parses", False, str(exc))

if root is not None:
    activities = {node.get(ANDROID + "name"): node for node in root.findall("application/activity")}
    result = activities.get(".InstallResultActivity")
    check("InstallResultActivity declared", result is not None)
    if result is not None:
        check("install result activity is not exported", result.get(ANDROID + "exported") == "false")
        check("install result activity is singleTop", result.get(ANDROID + "launchMode") == "singleTop")
        check("install result activity excluded from recents", result.get(ANDROID + "excludeFromRecents") == "true")

models = read(SRC / "ApkSourceModels.kt")
check("base APK must be first", 'displayName != "base.apk"' in models)
check("install names are constrained", "APK_NAME_PATTERN" in models)
check("case-insensitive duplicate names rejected", "lowercase" in models and "APK 文件名重复" in models)

coordinator = read(SRC / "PackageInstallCoordinator.kt")
for token in [
    "PackageInstaller.SessionParams",
    "MODE_FULL_INSTALL",
    "setAppPackageName",
    "setSize",
    "createSession",
    "openSession",
    "openWrite",
    "session.fsync",
    "session.commit",
    "PendingIntent.FLAG_MUTABLE",
    "InstallResultActivity::class.java",
    "ApkSourceVerifier.descriptorFromIntent",
    "MessageDigest.getInstance",
    "source.sizeBytes",
    "source.sha256",
    "abandonSession",
    "reconcileStale",
]:
    check(f"coordinator contains {token}", token in coordinator)
check("full install mode used", "SessionParams.MODE_FULL_INSTALL" in coordinator)
check("write and hash happen in one pass", coordinator.index("output.write") < coordinator.index("digest.update") < coordinator.index("actualDigest"))
check("all files written before commit", coordinator.index("descriptor.files.sortedBy") < coordinator.index("session.commit"))
check("state marked committed before commit", coordinator.index("STATE_COMMITTED") < coordinator.index("session.commit"))
check("session is abandoned only before successful commit", "!committed" in coordinator)
check("no nonexistent timeout status constant", "STATUS_FAILURE_TIMEOUT" not in coordinator)
check("API 31 user-action optimization guarded", "Build.VERSION_CODES.S" in coordinator and "setRequireUserAction" in coordinator)
check("mutable PendingIntent flag is API-31 guarded", "if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0" in coordinator)
check("API 33 package source guarded", "Build.VERSION_CODES.TIRAMISU" in coordinator and "setPackageSource" in coordinator)

store = read(SRC / "InstallRequestStore.kt")
for token in ["STATE_PREPARING", "STATE_WRITING", "STATE_COMMITTED", "STATE_AWAITING_USER", "STATE_SUCCESS", "STATE_FAILURE", "installerSessionId", "signingSha256", "pending"]:
    check(f"install request store contains {token}", token in store)
check("install requests are retained for recovery", "RETENTION_MS" in store and "MAX_RECORDS" in store)

receiver = read(SRC / "CloneRequestActivity.kt")
check("clone receiver uses formal installer", "PackageInstallCoordinator.install" in receiver)
check("formal install runs off UI thread", "Thread {" in receiver)
check("keep-screen-on used during large APK copy", "FLAG_KEEP_SCREEN_ON" in receiver)
check("real byte progress shown", "completedBytes" in receiver and "totalBytes" in receiver)
check("legacy verify-only success removed", "APK 来源校验通过" not in receiver and "下一阶段接入" not in receiver)

result = read(SRC / "InstallResultActivity.kt")
for token in [
    "STATUS_PENDING_USER_ACTION",
    "Intent.EXTRA_INTENT",
    "STATUS_SUCCESS",
    "InstalledPackageVerifier.verify",
    "STATUS_FAILURE_BLOCKED",
    "STATUS_FAILURE_ABORTED",
    "STATUS_FAILURE_INVALID",
    "STATUS_FAILURE_CONFLICT",
    "STATUS_FAILURE_STORAGE",
    "STATUS_FAILURE_INCOMPATIBLE",
]:
    check(f"install result activity contains {token}", token in result)
check("unknown request IDs are rejected", "收到未知安装结果" in result)
check("callback session and package identity are validated", "EXTRA_SESSION_ID" in result and "EXTRA_PACKAGE_NAME" in result and "拒绝不匹配的安装回调" in result)
check("post-install success is verified off UI thread", "Thread {" in result)
check("no nonexistent timeout status constant in result", "STATUS_FAILURE_TIMEOUT" not in result)

installed = read(SRC / "InstalledPackageVerifier.kt")
check("installed package version is verified", "longVersionCode == request.versionCode" in installed)
check("installed package signature is verified", "actualSigners == request.signingSha256.sorted()" in installed)
check("launchability is recorded", "getLaunchIntentForPackage" in installed)

apps = read(SRC / "AppsActivity.kt")
check("stale install state reconciliation runs during refresh", "PackageInstallCoordinator.reconcileStale" in apps)
check("app list refreshes when returning to foreground", "override fun onResume" in apps and "loadApps()" in apps)

receiver_update = read(SRC / "PackageUpdateReceiver.kt")
check("package-added callback recovery is implemented", "ACTION_PACKAGE_ADDED" in receiver_update and "reconcilePackage" in receiver_update and "goAsync" in receiver_update)
check("package-changed callback recovery is implemented", "ACTION_PACKAGE_CHANGED" in receiver_update)
check("coordinator supports immediate package reconciliation", "fun reconcilePackage" in coordinator)

all_kotlin = "\n".join(read(path) for path in sorted(SRC.glob("*.kt")))
check("no legacy installExistingPackage call remains", "installExistingPackage" not in all_kotlin)
check("no old cloneExistingPackageToThisProfile call remains", "cloneExistingPackageToThisProfile" not in all_kotlin)

workflow = read(WORKFLOW)
check("workflow runs phase-3 regression", "python3 tools/phase3_static_regression.py" in workflow)
check("phase-3 regression runs before assembleDebug", workflow.index("phase3_static_regression.py") < workflow.index("assembleDebug") if "phase3_static_regression.py" in workflow else False)

for kt in sorted(SRC.glob("*.kt")):
    balanced(kt)

if root is not None:
    for tag in ("activity", "service", "receiver", "provider"):
        for node in root.findall(f"application/{tag}"):
            name = node.get(ANDROID + "name", "")
            if name.startswith("."):
                check(f"manifest class exists: {name}", (SRC / f"{name[1:]}.kt").is_file())

print(f"PASS: {len(passes)}")
for item in passes:
    print(f"  [OK] {item}")
if failures:
    print(f"FAIL: {len(failures)}")
    for item in failures:
        print(f"  [FAIL] {item}")
    sys.exit(1)
print("RESULT: ALL PHASE-3 STATIC REGRESSION CHECKS PASSED")
