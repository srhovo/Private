#!/usr/bin/env python3
"""PrivacySpaceMVP 0.7 phase-1 static regression checks.

Runs with Python stdlib only; intended for AI/local/GitHub pre-build validation.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SRC = APP / "src/main/java/com/xiaxue/privacyspace"
MANIFEST = APP / "src/main/AndroidManifest.xml"
GRADLE = APP / "build.gradle.kts"
ANDROID = "{http://schemas.android.com/apk/res/android}"

failures: list[str] = []
passes: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        passes.append(name)
    else:
        failures.append(f"{name}: {detail}" if detail else name)


def text(path: Path) -> str:
    check(f"file exists: {path.relative_to(ROOT)}", path.is_file())
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def kotlin_balance(path: Path) -> None:
    source = text(path)
    # Remove comments and string literals before a lightweight delimiter check.
    cleaned = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    cleaned = re.sub(r"//.*", "", cleaned)
    cleaned = re.sub(r'"(?:\\.|[^"\\])*"', '""', cleaned)
    for opening, closing, label in [("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")]:
        depth = 0
        ok = True
        for char in cleaned:
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth < 0:
                    ok = False
                    break
        check(f"Kotlin {label}: {path.name}", ok and depth == 0, f"depth={depth}")


gradle = text(GRADLE)
check("minSdk is Android 11 / API 30", "minSdk = 30" in gradle)
check("targetSdk is API 35", "targetSdk = 35" in gradle)
version_match = re.search(r'versionCode\s*=\s*(\d+)', gradle)
check("version preserves phase-1 baseline", bool(version_match) and int(version_match.group(1)) >= 16)

try:
    root = ET.parse(MANIFEST).getroot()
    check("manifest XML parses", True)
except Exception as exc:  # pragma: no cover - diagnostic path
    root = None
    check("manifest XML parses", False, str(exc))

if root is not None:
    app = root.find("application")
    check("application exists", app is not None)
    components = [] if app is None else list(app)

    def component(tag: str, name: str):
        return next((node for node in components if node.tag == tag and node.get(ANDROID + "name") == name), None)

    clone = component("activity", ".CloneRequestActivity")
    check("CloneRequestActivity exists", clone is not None)
    if clone is not None:
        actions = {
            action.get(ANDROID + "name")
            for filt in clone.findall("intent-filter")
            for action in filt.findall("action")
        }
        check("clone action declared", "com.xiaxue.privacyspace.action.CLONE_PACKAGE" in actions)
        check("launch action declared", "com.xiaxue.privacyspace.action.LAUNCH_PACKAGE" in actions)
        check("no placeholder service action on clone receiver", not any("START_SERVICE" in (a or "") for a in actions))

    dummy = component("activity", ".DummyActivity")
    if dummy is not None:
        actions = {
            action.get(ANDROID + "name")
            for filt in dummy.findall("intent-filter")
            for action in filt.findall("action")
        }
        check("DummyActivity only exposes finalize", actions == {"com.xiaxue.privacyspace.action.FINALIZE_PROVISION"}, str(actions))

    service = component("service", ".IsolationService")
    check("unused IsolationService removed", service is None)

manifest_text = text(MANIFEST)
check("dead PROFILE_COMMAND permission removed", "PROFILE_COMMAND" not in manifest_text)
check("dead START_SERVICE action removed", "START_SERVICE" not in manifest_text)
check("unused foreground-service permission removed", "FOREGROUND_SERVICE" not in manifest_text)

auth = text(SRC / "CrossProfileAuth.kt")
for token in ["HmacSHA256", "EXTRA_TIMESTAMP", "EXTRA_NONCE", "EXTRA_SIGNATURE", "consumeNonce", "MAX_AGE_MS"]:
    check(f"auth contains {token}", token in auth)
check("auth key is provisioned", "EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE" in auth)

manager = text(SRC / "WorkProfileManager.kt")
check("provisioning includes auth extras", "CrossProfileAuth.provisioningExtras" in manager)
check("outgoing commands are signed", "CrossProfileAuth.sign" in manager)
check("forwarder validates system uid", "Process.SYSTEM_UID" in manager)
check("forwarder validates platform signature", 'checkSignatures("android"' in manager)
check("launch has dedicated implementation", "launchPackageInThisProfile" in manager)

receiver = text(SRC / "CloneRequestActivity.kt")
check("incoming commands verify signature", "CrossProfileAuth.verify" in receiver)
check("clone and launch actions are separated", "when (source.action)" in receiver)
check("launch action does not call clone branch", "ACTION_LAUNCH_PACKAGE -> handleLaunch(packageName" in receiver)

setup = text(SRC / "ProfileSetup.kt")
check("profile setup is versioned", "CURRENT_CONFIG_VERSION" in setup and "KEY_CONFIG_VERSION" in setup)
check("profile filters exclude placeholder service", "ACTION_START_SERVICE" not in setup)
check("profile setup reports combined success", "receiverOk && filtersOk && enabled" in setup)

protected = text(SRC / "ProtectedPackages.kt")
for token in ["com.android.systemui", "com.android.settings", "com.android.managedprovisioning", "CATEGORY_HOME", "isProfileOwnerApp"]:
    check(f"protected packages contains {token}", token in protected)

apps = text(SRC / "AppsActivity.kt")
check("single uninstall uses protection policy", "manager.protectedReason(packageName)" in apps)
check("batch freeze requires true result", "result.getOrNull() == true" in apps)
check("false operation does not trigger success refresh", "if (ok) afterSuccess()" in apps)
check("legacy unpaired profile is blocked", "showLegacyProfileMigration()" in apps and "compat.hasRelatedProfile" in apps)

main = text(SRC / "MainActivity.kt")
check("home page shows security pairing state", '"安全配对"' in main and "CrossProfileAuth.hasKey" in main)

workflow = text(ROOT / ".github/workflows/android-build.yml")
check("CI runs static regression before build", "python3 tools/phase1_static_regression.py" in workflow)

for kt in sorted(SRC.glob("*.kt")):
    kotlin_balance(kt)

# Manifest class references must exist.
if root is not None:
    for tag in ("activity", "service", "receiver", "provider"):
        for node in root.findall(f"application/{tag}"):
            name = node.get(ANDROID + "name", "")
            if name.startswith("."):
                check(f"manifest class exists: {name}", (SRC / f"{name[1:]}.kt").is_file())

print(f"PASS: {len(passes)}")
for item in passes:
    print(f"  [OK] {item}")
if failures:
    print(f"FAIL: {len(failures)}")
    for item in failures:
        print(f"  [FAIL] {item}")
    sys.exit(1)
print("RESULT: ALL STATIC REGRESSION CHECKS PASSED")
