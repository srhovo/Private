#!/usr/bin/env python3
"""PrivacySpaceMVP phase-2 APK source layer static regression.

Stdlib-only checks for local/AI/GitHub pre-build validation.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SRC = APP / "src/main/java/com/xiaxue/privacyspace"
MANIFEST = APP / "src/main/AndroidManifest.xml"
GRADLE = APP / "build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"
ANDROID = "{http://schemas.android.com/apk/res/android}"

passes: list[str] = []
failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        passes.append(name)
    else:
        failures.append(f"{name}: {detail}" if detail else name)


def read(path: Path) -> str:
    check(f"file exists: {path.relative_to(ROOT)}", path.is_file())
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def balanced(path: Path) -> None:
    source = read(path)
    cleaned = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    cleaned = re.sub(r"//.*", "", cleaned)
    cleaned = re.sub(r'"(?:\\.|[^"\\])*"', '""', cleaned)
    for opening, closing, label in [("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")]:
        depth = 0
        valid = True
        for char in cleaned:
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth < 0:
                    valid = False
                    break
        check(f"Kotlin {label}: {path.name}", valid and depth == 0, f"depth={depth}")


gradle = read(GRADLE)
version_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
check("versionCode remains at or above phase-2 baseline", bool(version_match and int(version_match.group(1)) >= 17))
check("versionName remains phase-2 or later", "versionName" in gradle and ("apk-source-layer" in gradle or "package-installer" in gradle or "lifecycle-state" in gradle))
check("minSdk remains API 30", "minSdk = 30" in gradle)
check("targetSdk remains API 35", "targetSdk = 35" in gradle)

manifest_text = read(MANIFEST)
try:
    root = ET.fromstring(manifest_text)
    check("manifest XML parses", True)
except Exception as exc:
    root = None
    check("manifest XML parses", False, str(exc))

if root is not None:
    permissions = {
        node.get(ANDROID + "name"): node.get(ANDROID + "protectionLevel")
        for node in root.findall("permission")
    }
    uses_permissions = {node.get(ANDROID + "name") for node in root.findall("uses-permission")}
    check(
        "APK source permission is signature-level",
        permissions.get("com.xiaxue.privacyspace.permission.READ_APK_SOURCE") == "signature",
        str(permissions),
    )
    check(
        "same-signed profile app requests APK source permission",
        "com.xiaxue.privacyspace.permission.READ_APK_SOURCE" in uses_permissions,
    )
    app = root.find("application")
    providers = [] if app is None else app.findall("provider")
    provider = next((p for p in providers if p.get(ANDROID + "name") == ".ApkSourceProvider"), None)
    check("ApkSourceProvider declared", provider is not None)
    if provider is not None:
        check("provider authority uses applicationId", provider.get(ANDROID + "authorities") == "${applicationId}.apk_source")
        check("provider is exported for cross-profile access", provider.get(ANDROID + "exported") == "true")
        check("provider grants temporary URI permissions", provider.get(ANDROID + "grantUriPermissions") == "true")
        check(
            "provider requires signature read permission",
            provider.get(ANDROID + "readPermission") == "com.xiaxue.privacyspace.permission.READ_APK_SOURCE",
        )

models = read(SRC / "ApkSourceModels.kt")
for token in ["sessionId", "versionCode", "signingSha256", "expiresAt", "sizeBytes", "sha256", "MAX_FILES", "MAX_TOTAL_BYTES"]:
    check(f"descriptor contains {token}", token in models)
check("descriptor validates expiry", "APK 来源会话已过期" in models)
check("descriptor hashes exact manifest text", 'MessageDigest.getInstance("SHA-256")' in models)

store = read(SRC / "ApkSourceSessionStore.kt")
for token in ["SESSION_TTL_MS", "MAX_SESSIONS", "lastModified", "currentVersionCode", "currentSourcePaths", "file.length()", "file.canRead()"]:
    check(f"session store contains {token}", token in store)
check("source sessions expire in 15 minutes", "15 * 60 * 1000L" in store)
check("source session provider path is revalidated", "APK 来源路径已不属于当前安装包" in store)
check("source session version is revalidated", "应用版本已变化" in store)

repository = read(SRC / "ApkSourceRepository.kt")
for token in [
    "getInstalledPackages",
    "GET_SIGNING_CERTIFICATES",
    "publicSourceDir",
    "sourceDir",
    "splitPublicSourceDirs",
    "splitSourceDirs",
    "longVersionCode",
    "signingInfo",
    "apkContentsSigners",
    "FileInputStream",
    'MessageDigest.getInstance("SHA-256")',
    "ApkSourceSessionStore.save",
]:
    check(f"repository contains {token}", token in repository)
check("repository excludes uninstall remnants", "MATCH_UNINSTALLED_PACKAGES" not in repository)
check("repository prevents cloning manager itself", "无需克隆自身" in repository)
check("hashing completes before expiry starts", repository.index("val storedFiles") < repository.index("val expiresAt"))

provider = read(SRC / "ApkSourceProvider.kt")
for token in ["MODE_READ_ONLY", 'mode != "r"', "UnsupportedOperationException", "substringAfter('@')", "fileForRead"]:
    check(f"provider contains {token}", token in provider)
check("provider does not expose write mode", "MODE_READ_WRITE" not in provider and "MODE_WRITE_ONLY" not in provider)
check("provider URI shape includes opaque display-name segment", "segments.size != 5" in provider and "segments[3].toIntOrNull()" in provider)

contract = read(SRC / "ProvisioningContract.kt")
for token in ["EXTRA_APK_SOURCE_SESSION_ID", "EXTRA_APK_SOURCE_MANIFEST", "EXTRA_APK_SOURCE_MANIFEST_SHA256"]:
    check(f"contract contains {token}", token in contract)

auth = read(SRC / "CrossProfileAuth.kt")
check("HMAC signs APK source session", "EXTRA_APK_SOURCE_SESSION_ID" in auth)
check("HMAC signs APK manifest digest", "EXTRA_APK_SOURCE_MANIFEST_SHA256" in auth)

manager = read(SRC / "WorkProfileManager.kt")
for token in ["ClipData.newRawUri", "FLAG_GRANT_READ_URI_PERMISSION", "EXTRA_APK_SOURCE_MANIFEST", "ApkSourceDescriptor.sha256Text", "openCloneRequestChooser"]:
    check(f"cross-profile sender contains {token}", token in manager)
check("source extras are added before HMAC signing", manager.index("EXTRA_APK_SOURCE_MANIFEST_SHA256") < manager.index("CrossProfileAuth.sign"))
check("trusted system forwarder check remains", "Process.SYSTEM_UID" in manager and 'checkSignatures("android"' in manager)
check("legacy installExistingPackage removed from manager", "installExistingPackage" not in manager)
check("work profile manager does not expose internal descriptor publicly", "internal class WorkProfileManager" in manager)
check("system forwarder component is null-checked", "系统转发入口缺少组件信息" in manager and "val forwarderInfo" in manager)

verifier = read(SRC / "ApkSourceVerifier.kt")
for token in ["descriptorFromIntent", "clipData", "sameTransferredUri", "substringAfter('@')", "openInputStream", "sizeBytes", "source.sha256", "totalBytes"]:
    check(f"receiver verifier contains {token}", token in verifier)
check("receiver uses transferred ClipData URI", "file.copy(uri = clipUris[index])" in verifier)

receiver = read(SRC / "CloneRequestActivity.kt")
coordinator = read(SRC / "PackageInstallCoordinator.kt")
check("formal install path parses authenticated source descriptor", "ApkSourceVerifier.descriptorFromIntent" in coordinator)
check("source integrity is verified while writing install session", "source.sizeBytes" in coordinator and "source.sha256" in coordinator)
check("source processing runs off UI thread", "Thread {" in receiver)
check("clone receiver delegates to formal install coordinator", "PackageInstallCoordinator.install" in receiver)
check("clone receiver does not call legacy installer", "cloneExistingPackageToThisProfile" not in receiver and "installExistingPackage" not in receiver)

apps = read(SRC / "AppsActivity.kt")
check("app inventory runs off UI thread", "sourceRepository.loadInventory" in apps and "Thread {" in apps)
check("APK preparation runs off UI thread", "sourceRepository.prepare" in apps and "正在准备 APK 来源" in apps)
check("app UI exposes source readiness", "sourceReady" in apps and "APK 来源可用" in apps)
check("app UI no longer invokes legacy installer", "cloneExistingPackageToThisProfile" not in apps)
check("app source excludes uninstall remnants", "MATCH_UNINSTALLED_PACKAGES" not in apps)

all_kotlin = "\n".join(read(path) for path in sorted(SRC.glob("*.kt")))
check("no Kotlin source invokes installExistingPackage", "installExistingPackage" not in all_kotlin)

workflow = read(WORKFLOW)
check("workflow runs phase-1 regression", "python3 tools/phase1_static_regression.py" in workflow)
check("workflow runs phase-2 regression", "python3 tools/phase2_static_regression.py" in workflow)
check("regressions run before assembleDebug", workflow.index("phase2_static_regression.py") < workflow.index("assembleDebug") if "phase2_static_regression.py" in workflow else False)

for kt in sorted(SRC.glob("*.kt")):
    balanced(kt)

if root is not None:
    for tag in ("activity", "service", "receiver", "provider"):
        for node in root.findall(f"application/{tag}"):
            name = node.get(ANDROID + "name", "")
            if name.startswith("."):
                check(f"manifest class exists: {name}", (SRC / f"{name[1:]}.kt").is_file())

print(f"PASS: {len(passes)}")
for item in passes:
    print(f"  [OK] {item}")
if failures:
    print(f"FAIL: {len(failures)}")
    for item in failures:
        print(f"  [FAIL] {item}")
    sys.exit(1)
print("RESULT: ALL PHASE-2 STATIC REGRESSION CHECKS PASSED")
