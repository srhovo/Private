# PrivacySpaceMVP v0.7.1 阶段 2 完成记录

## 一、阶段目标

建立可靠的“主空间应用 → APK 来源清单 → 隔离空间读取校验”链路，为下一阶段 `PackageInstaller.Session` 安装提供可信输入。

本阶段不执行正式安装，不把来源校验成功宣称为克隆成功。

## 二、链路

1. 主空间后台枚举当前用户真实已安装的包。
2. 读取目标包的 `publicSourceDir/sourceDir` 与全部 `splitPublicSourceDirs/splitSourceDirs`。
3. 从 `PackageInfo` 提取包名、长版本号、版本名和当前签名证书摘要。
4. 对 base APK 和每个 split APK 计算 SHA-256。
5. 建立 15 分钟有效的随机来源会话，私有保存路径、大小、修改时间和摘要。
6. 通过签名级只读 `ApkSourceProvider` 暴露会话文件。
7. 克隆 Intent 使用 `ClipData` 携带全部 URI，并授予临时只读权限。
8. 来源清单 JSON 的 SHA-256、会话 ID 与包名进入 HMAC-SHA256 指令签名。
9. 系统跨资料转发后，隔离空间验证 HMAC、有效期、防重放、清单摘要和 URI 路径。
10. 隔离空间逐文件读取，重新核对大小与 SHA-256。

## 三、安全边界

- Provider 只允许显式申请该签名级权限、且签名相同的应用读取；主空间与工作资料实例均声明该权限。
- Provider 仅支持只读 `openFile("r")`，拒绝写入、删除和更新。
- 每次来源使用 128 位随机会话 ID。
- 会话默认 15 分钟过期，最多保留 8 个。
- 打开文件前再次验证路径仍属于目标包当前 APK 来源。
- 打开文件前验证应用版本、文件长度和最后修改时间均未变化。
- 接收端使用系统转发后的实际 `ClipData` URI，兼容跨用户 URI 的 user-id 前缀。
- 清单最多接受 256 个 APK 文件，总大小上限 20 GiB。
- 正式链路已不再调用 `DevicePolicyManager.installExistingPackage()`。

## 四、风险

1. 不同厂商对跨资料 URI 授权的实现可能存在差异，仍需 Android 13–16 真机验证。
2. 大型游戏 APK 哈希耗时较长，但已在后台线程执行。
3. 来源会话只保存路径和摘要，不复制 APK，可避免额外占用同等存储；安装阶段必须在授权有效期内完成读取。
4. 目前只验证来源和传输，尚未处理安装用户确认、安装状态码和回滚。

## 五、验收

静态验收：

- Manifest 存在签名级 Provider 权限。
- Provider 导出但仅签名读取，并启用 URI grant。
- 应用枚举不使用 `MATCH_UNINSTALLED_PACKAGES`。
- base/split、版本、签名、大小和 SHA-256 均进入来源层。
- Intent 使用 ClipData 和只读 URI grant。
- HMAC 覆盖会话 ID 与清单摘要。
- 隔离空间重新读取并验证所有文件。
- 源码中不存在 `installExistingPackage()` 调用。
- 阶段 1 静态回归 142 项、阶段 2 静态回归 213 项全部通过。
- APK 来源模块与跨资料发送管理器通过最小 Android API 类型桩的 Kotlin 独立编译。

真机验收留给阶段 2.1/阶段 3 开始前执行：

- 单 APK 应用来源校验通过。
- 多 split 应用来源校验通过。
- 篡改清单、缺少 URI、过期会话、文件更新均被拒绝。

## 六、下一阶段

阶段 3：在隔离空间创建 `PackageInstaller.Session`，按顺序写入 base APK 与全部 split APK，接入唯一安装回调并处理用户确认、成功、失败、取消与超时。
