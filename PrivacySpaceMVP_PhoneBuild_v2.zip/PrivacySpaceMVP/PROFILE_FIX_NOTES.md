# v2 第一阶段修复说明

本包仍保持文件名 `PrivacySpaceMVP_PhoneBuild_v2.zip`。

本次目标不是做完整克隆/冻结，而是先把“创建独立工作资料空间”打通。

主要改动：

1. 恢复 Shelter 类似的创建链路：`SetupWizardActivity` → 系统 ManagedProvisioning → `FinalizeProvisionActivity` → `DummyActivity`。
2. 创建 Intent 只保留原 APK 同类链路中的核心参数：
   - `ACTION_PROVISION_MANAGED_PROFILE`
   - `EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME`
   - `EXTRA_PROVISIONING_SKIP_ENCRYPTION`
3. Manifest 对齐原 APK 的关键结构，移除上一版额外猜测的 `GET_PROVISIONING_MODE` / `ADMIN_POLICY_COMPLIANCE` 入口，降低 ROM 兼容变量。
4. `ProfileSetup` 第一阶段只执行必要收尾：确认 Profile Owner、设置工作资料名称、`setProfileEnabled()`。
5. 首页创建按钮不再直接启动系统设置，而是进入单独创建向导，方便确认创建前状态。

测试前请先移除原 Shelter APK 创建的工作资料，再卸载旧版本 App 并重启。
